-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: voice_saas
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `project_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'task',
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('running','done','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `started_at` timestamp NOT NULL,
  `ended_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_logs_user_id_started_at_index` (`user_id`,`started_at`),
  KEY `activity_logs_user_id_project_id_index` (`user_id`,`project_id`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,1,'iidthvnj','synthesis','Synthesising \"News Report\"','Audio ready','done','2026-06-14 13:30:04','2026-06-14 13:30:15','2026-06-14 13:30:04','2026-06-14 13:30:15'),(2,1,'qo5ajmvm','synthesis','Synthesising \"YouTube Outro\"','Audio ready','done','2026-06-14 13:30:52','2026-06-14 13:31:09','2026-06-14 13:30:53','2026-06-14 13:31:09'),(3,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','F5','failed','2026-06-14 13:32:34','2026-06-14 14:13:25','2026-06-14 13:32:34','2026-06-14 14:13:25'),(4,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','1 scripts processed','done','2026-06-14 13:34:17','2026-06-14 13:34:20','2026-06-14 13:34:17','2026-06-14 13:34:21'),(5,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','Engine returned HTTP 500 — the model may have crashed or run out of memory.','failed','2026-06-14 13:34:38','2026-06-14 13:34:42','2026-06-14 13:34:39','2026-06-14 13:34:42'),(6,1,'qo5ajmvm','synthesis','Bulk synthesis complete: 1/1 succeeded',NULL,'done','2026-06-14 14:15:31','2026-06-14 14:15:34','2026-06-14 14:15:31','2026-06-14 14:15:34'),(7,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','1 scripts processed','done','2026-06-14 14:18:41','2026-06-14 14:18:46','2026-06-14 14:18:42','2026-06-14 14:18:46'),(10,1,'wcy0cecq','synthesis','Bulk synthesis: 3 scripts','Marked failed automatically — the task was interrupted (e.g. the page was closed) and never reported completion.','failed','2026-06-15 08:01:31','2026-06-15 09:15:01','2026-06-15 08:01:32','2026-06-15 09:15:01'),(11,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:98|scripts:3','done','2026-06-15 08:01:33','2026-06-15 08:01:53','2026-06-15 08:01:33','2026-06-15 08:01:53'),(12,1,'wcy0cecq','delete','Deleted script \"Podcast Intro\"','generated audio removed','done','2026-06-15 09:43:39','2026-06-15 09:43:40','2026-06-15 09:43:40','2026-06-15 09:43:41'),(13,1,'wcy0cecq','delete','Deleted script \"News Report\"','generated audio removed','done','2026-06-15 09:44:03','2026-06-15 09:44:04','2026-06-15 09:44:04','2026-06-15 09:44:04'),(14,1,'wcy0cecq','delete','Deleted script \"YouTube Outro\"','generated audio removed','done','2026-06-15 09:44:07','2026-06-15 09:44:08','2026-06-15 09:44:08','2026-06-15 09:44:09'),(15,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:94|scripts:3','done','2026-06-15 09:44:28','2026-06-15 09:44:48','2026-06-15 09:44:28','2026-06-15 09:44:48'),(16,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:38|scripts:1','done','2026-06-15 09:45:30','2026-06-15 09:45:38','2026-06-15 09:45:30','2026-06-15 09:45:38'),(17,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:94|scripts:3','done','2026-06-15 11:26:26','2026-06-15 11:26:44','2026-06-15 11:26:26','2026-06-15 11:26:44'),(18,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:38|scripts:1','done','2026-06-15 11:28:30','2026-06-15 11:28:40','2026-06-15 11:28:30','2026-06-15 11:28:40'),(19,1,'wcy0cecq','synthesis','Bulk synthesis complete: 2/2 succeeded','model:f5|words:56|scripts:2','done','2026-06-15 11:48:21','2026-06-15 11:48:33','2026-06-15 11:48:21','2026-06-15 11:48:33');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint unsigned DEFAULT NULL,
  `target_user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `after_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `admin_audit_log_actor_id_created_at_index` (`actor_id`,`created_at`),
  KEY `admin_audit_log_target_user_id_index` (`target_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,1,NULL,'setting.changed (gemini_api_key)','(empty)','(updated)','172.19.0.1',NULL,'2026-06-12 05:05:12');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `is_secret` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES (1,'gemini_api_key','eyJpdiI6ImRWZzZBR3htWTVQYXdsRkdFVGFZbUE9PSIsInZhbHVlIjoiMlBzUTZ2TitBNzNvdmxIMWFjejlkVkE5aUJQTHMxSldXd2V5dkxEamQ4elpoOTdWMFpTYWZUVlBGd3JEMzFjNCIsIm1hYyI6IjNkYzUyNTYwZTEwODU0YTRiNmFiMWU2N2NkZjMwMTdlYmExMDcwNmM3ZTEzMDhiMWUwN2FmNGU4MDUxMjNjNTQiLCJ0YWciOiIifQ==',1,'2026-06-12 05:05:12','2026-06-12 05:05:12');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('voxora-cache-356a192b7913b04c54574d18c28d46e6395428ab','i:1;',1781524161),('voxora-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer','i:1781524161;',1781524161),('voxora-cache-a7865b871c474506e0726a495e3cbe56b929c154','i:1;',1782110046),('voxora-cache-a7865b871c474506e0726a495e3cbe56b929c154:timer','i:1782110046;',1782110046),('voxora-cache-app_setting:discord_webhook_url','N;',1782270325),('voxora-cache-app_setting:gemini_api_key','s:39:\"AIzaSyDiZcExZumUpFukZHo5nhqJNkzHcU9gcRI\";',1781524543),('voxora-cache-app_setting:moderation_keywords','N;',1781505648),('voxora-cache-app_setting:paypal_plan_pro','N;',1781524544),('voxora-cache-app_setting:paypal_plan_starter','N;',1781524544),('voxora-cache-app_setting:slack_webhook_url','N;',1782270325),('voxora-cache-da4b9237bacccdf19c0760cab7aec4a8359010b0','i:7;',1781255849),('voxora-cache-da4b9237bacccdf19c0760cab7aec4a8359010b0:timer','i:1781255849;',1781255849),('voxora-cache-engine:active_url','s:25:\"http://34.59.245.242:8000\";',1782270611),('voxora-cache-guest_limits','a:6:{s:11:\"synth_limit\";i:5;s:13:\"preview_limit\";i:5;s:12:\"script_limit\";i:5;s:12:\"session_days\";i:7;s:10:\"word_limit\";i:500;s:13:\"profile_limit\";i:1;}',1782274180),('voxora-cache-heartbeat:queue','s:25:\"2026-06-24T03:10:29+00:00\";',1782357029),('voxora-cache-heartbeat:scheduler','s:25:\"2026-06-24T03:14:29+00:00\";',1782357269),('voxora-cache-synth_batch:1:19b4ab2b-8510-40ca-b1c9-e201aaa07c32','b:1;',1781174975),('voxora-cache-synth_batch:1:1d54d19f-9f32-4c31-a1f2-fe373bdae904','b:1;',1781447555),('voxora-cache-synth_batch:1:4de93186-0e4c-487f-9b55-6a0850674272','b:1;',1781447679),('voxora-cache-synth_batch:1:6820e42b-98db-40da-8c24-5f634893fe24','b:1;',1781338573),('voxora-cache-synth_batch:1:68dff763-9831-414c-8643-34f6ea9631fb','b:1;',1781447563),('voxora-cache-synth_batch:1:6f118756-65d1-4b8c-9f0f-d4dd3d9a3c7c','b:1;',1781447453),('voxora-cache-synth_batch:1:7eed9cbe-0960-4fa2-9348-0b6ba3ec1c51','b:1;',1781160913),('voxora-cache-synth_batch:1:81536a9d-48d9-4072-a8e5-517b89bc8372','b:1;',1781164766),('voxora-cache-synth_batch:1:aa4f3ce1-e537-4bf6-a1f3-15e38e18680d','b:1;',1781164739),('voxora-cache-synth_batch:1:b9463c72-11e7-41fc-b4fa-ebb3e43a95a9','b:1;',1781450323),('voxora-cache-synth_batch:1:dbfd552c-4466-4d93-a131-ae4815da925f','b:1;',1781338658),('voxora-cache-synth_batch:1:eeb626fe-ead1-49c5-8c8a-3bd0eb0b8c93','b:1;',1781446713),('voxora-cache-synth_batch:1:f21d5822-f253-4c6e-8ef5-ed8cc9240658','b:1;',1781447405),('voxora-cache-synth_batch:1:fede0ee5-b46d-4641-b819-367d4de3276a','b:1;',1781447658),('voxora-cache-synth_batch:2:6a6be2a5-d38d-4298-b5e8-27ffe9004ccf','b:1;',1781259389),('voxora-cache-synth_batch:2:d9cbf454-63b7-40ff-84e4-738c47b91b28','b:1;',1781259442),('voxora-cache-synth_job_owner:120d6e1f7839444ba3e9ff28bff73f7e','s:1:\"1\";',1781447679),('voxora-cache-synth_job_owner:172aac6866c04c9ab06204de1eb88e06','s:1:\"1\";',1781447564),('voxora-cache-synth_job_owner:227f98ce6b24471483ff866f67d3a9e9','s:1:\"1\";',1781164766),('voxora-cache-synth_job_owner:351766b61e9e48f2975874da51aa4de1','s:1:\"2\";',1781259389),('voxora-cache-synth_job_owner:35cec168c0b648528544a83b2189616c','s:1:\"1\";',1781450323),('voxora-cache-synth_job_owner:37c2f68f735f40839bccb0a28931db4a','s:1:\"1\";',1781160914),('voxora-cache-synth_job_owner:46b873633bd843f193ece4bace6dc8dd','s:1:\"1\";',1781174975),('voxora-cache-synth_job_owner:5aa06e9cc7c945b8b3568c87c1a29017','s:1:\"1\";',1781338574),('voxora-cache-synth_job_owner:5c949dc7a5b8446498bb82f9fbed920f','s:1:\"1\";',1781447453),('voxora-cache-synth_job_owner:6c93e4e4c9d046649478584f7a7afc0b','s:1:\"1\";',1781160881),('voxora-cache-synth_job_owner:7fb5ceeb310848f690adf16f61eb5139','s:1:\"2\";',1781259442),('voxora-cache-synth_job_owner:83582e0631d24ccea0d09337dbeaa60c','s:1:\"1\";',1781447405),('voxora-cache-synth_job_owner:8b509470a014458a8bcea2393fec5e0b','s:1:\"1\";',1781164739),('voxora-cache-synth_job_owner:957e5baf14a849b4b9fe1d7838223c81','s:1:\"2\";',1781259322),('voxora-cache-synth_job_owner:ca53db007a364e26b52f2977d30205cc','s:1:\"1\";',1781160827),('voxora-cache-synth_job_owner:cab0fd7b1f974a809cdfbccfbea15aa9','s:1:\"1\";',1781446713),('voxora-cache-synth_job_owner:d3039abfd53748fb963daa1b53469503','s:1:\"1\";',1781447658),('voxora-cache-synth_job_owner:ea60702620a84ad0a83c870cd388bc4b','s:1:\"1\";',1781338658),('voxora-cache-synth_job_owner:ecdc050bfd2748ebbcc7ea840ec21b83','s:1:\"1\";',1781160898),('voxora-cache-synth_job_owner:f3c5975ed5794715b500ea7bd718f173','s:1:\"1\";',1781447555);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine_configs`
--

DROP TABLE IF EXISTS `engine_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `engine_configs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `latency_ms` int DEFAULT NULL,
  `last_tested_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine_configs`
--

LOCK TABLES `engine_configs` WRITE;
/*!40000 ALTER TABLE `engine_configs` DISABLE KEYS */;
INSERT INTO `engine_configs` VALUES (1,'Local Server','http://ai-engine:8000',0,'online',3,'2026-06-13 07:15:49','2026-06-09 05:50:48','2026-06-13 07:15:49'),(2,'GCP Server','http://34.59.245.242:8000',1,'online',56,'2026-06-13 07:15:53','2026-06-09 16:30:54','2026-06-13 07:15:53');
/*!40000 ALTER TABLE `engine_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=3990 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_05_12_012958_create_projects_table',1),(5,'2026_05_12_012959_create_scripts_table',1),(6,'2026_05_12_013000_create_voice_profiles_table',1),(7,'2026_05_12_044441_create_personal_access_tokens_table',1),(8,'2026_05_12_100000_add_duration_to_voice_profiles_table',1),(9,'2026_05_22_000001_add_tone_to_scripts_table',1),(10,'2026_05_25_000001_add_bio_to_users_table',2),(11,'2026_05_26_000001_add_engine_key_to_voice_profiles',3),(12,'2026_05_26_000002_create_subscriptions_table',3),(13,'2026_05_26_000003_create_guest_limits_table',4),(14,'2026_06_05_000001_add_lane_config_to_projects_table',5),(15,'2026_06_06_000001_create_plan_limits_table',6),(16,'2026_06_06_000002_merge_guest_limits_into_plan_limits',6),(17,'2026_06_06_000003_guest_inherits_free_limits',6),(18,'2026_06_06_000004_add_synth_limit_to_plan_limits',6),(19,'2026_06_06_000005_create_synthesis_usage_table',6),(20,'2026_06_06_000006_add_advanced_params_to_scripts',6),(21,'2026_06_07_000001_add_translation_limits',7),(22,'2026_06_07_000002_create_translation_usage_table',7),(23,'2026_06_07_000003_add_engine_to_scripts',8),(24,'2026_06_09_000001_create_engine_configs_table',9),(25,'2026_06_11_000001_create_activity_logs_table',10),(26,'2026_06_11_100001_add_role_to_users_table',11),(27,'2026_06_11_100002_create_admin_audit_log_table',11),(28,'2026_06_11_200001_add_suspension_and_plan_override_to_users',12),(29,'2026_06_12_000001_create_app_settings_table',13),(30,'2026_06_12_000002_add_admin_note_to_users',13);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_limits`
--

DROP TABLE IF EXISTS `plan_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_limits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_limit` int unsigned DEFAULT '1',
  `profile_limit` int unsigned DEFAULT '1',
  `word_limit` int unsigned DEFAULT '500',
  `synth_limit` int unsigned DEFAULT NULL,
  `synth_period` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translate_limit` int unsigned DEFAULT NULL,
  `translate_period` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_limit` int unsigned DEFAULT NULL,
  `script_limit` int unsigned DEFAULT NULL,
  `session_days` int unsigned DEFAULT NULL,
  `multi_voice` tinyint(1) NOT NULL DEFAULT '0',
  `data_export` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_limits_plan_unique` (`plan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_limits`
--

LOCK TABLES `plan_limits` WRITE;
/*!40000 ALTER TABLE `plan_limits` DISABLE KEYS */;
INSERT INTO `plan_limits` VALUES (1,'free',1,1,500,3,'day',10,'month',NULL,NULL,NULL,0,0,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(2,'starter',10,5,5000,100,'month',50,'month',NULL,NULL,NULL,1,0,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(3,'pro',0,0,0,0,'month',0,'month',NULL,NULL,NULL,1,1,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(4,'guest',NULL,NULL,NULL,5,NULL,NULL,NULL,5,5,7,0,0,'2026-06-06 15:06:44','2026-06-06 15:06:45');
/*!40000 ALTER TABLE `plan_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emoji` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `timeline_clips` json DEFAULT NULL,
  `lane_config` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `projects_user_id_foreign` (`user_id`),
  CONSTRAINT `projects_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES ('bww8kv5w',2,'My Guest Project','🎬',NULL,'[]',NULL,'2026-05-27 14:14:17','2026-05-27 14:14:34'),('iidthvnj',1,'News','🎬',NULL,'[{\"ci\": 0, \"id\": \"tc_g50vztos\", \"dur\": 11.5, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 11.5, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"1j4xkyfr\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_1sg75nyr\", \"dur\": 16.2, \"lane\": 1, \"isGap\": false, \"start\": 0, \"title\": \"Podcast Intro\", \"rawDur\": 16.2, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"9j38a4p2\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-09 16:31:45','2026-06-11 15:52:33'),('qo5ajmvm',1,'Project 1','📹',NULL,'[{\"ci\": 0, \"id\": \"tc_cyq2jeil\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_2y0vm8au\", \"dur\": 17.4, \"lane\": 1, \"isGap\": false, \"start\": 10.1, \"title\": \"Podcast Intro\", \"rawDur\": 17.4, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"0whm6v9q\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_b02711em\", \"dur\": 13.9, \"lane\": 2, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 13.9, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"ixaifltr\", \"trimStart\": 0}, {\"ci\": 1, \"id\": \"tc_3nw3uqjd\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 15, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 2, \"id\": \"tc_yfhyuao6\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 30, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 3, \"id\": \"tc_bs79rsif\", \"dur\": 17.4, \"lane\": 0, \"isGap\": false, \"start\": 45, \"title\": \"Podcast Intro\", \"rawDur\": 17.4, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"0whm6v9q\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-05 05:45:53','2026-06-09 03:01:46'),('wcy0cecq',1,'Smple','📹',NULL,'[{\"ci\": 0, \"id\": \"tc_ijrj25u2\", \"dur\": 11.95, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"Product Demo\", \"rawDur\": 11.95, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"n0afspme\", \"trimStart\": 0}, {\"ci\": 1, \"id\": \"tc_b3ib802z\", \"dur\": 11.95, \"lane\": 1, \"isGap\": false, \"start\": 0, \"title\": \"Product Demo\", \"rawDur\": 11.95, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"n0afspme\", \"trimStart\": 0}, {\"ci\": 2, \"id\": \"tc_xj2e2or2\", \"dur\": 11.76, \"lane\": 2, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 11.76, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"xu7ibp0n\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-15 06:37:04','2026-06-15 11:49:06');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scripts`
--

DROP TABLE IF EXISTS `scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scripts` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `has_audio` tinyint(1) NOT NULL DEFAULT '0',
  `profile_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `duration` double DEFAULT NULL,
  `speed` double NOT NULL DEFAULT '1',
  `tone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'natural',
  `engine` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'xtts',
  `speaker_map` json DEFAULT NULL,
  `waveform_peaks` json DEFAULT NULL,
  `advanced_params` json DEFAULT NULL,
  `order_index` int NOT NULL DEFAULT '0',
  `audio_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scripts_project_id_foreign` (`project_id`),
  CONSTRAINT `scripts_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scripts`
--

LOCK TABLES `scripts` WRITE;
/*!40000 ALTER TABLE `scripts` DISABLE KEYS */;
INSERT INTO `scripts` VALUES ('0whm6v9q','qo5ajmvm','Podcast Intro','Welcome back to Voxora I\'m your host  voxora agent, and today we\'re diving into voice cloning. Whether you\'re a longtime listener or just joining us for the first time — you\'re in the right place. Let\'s get started.',1,'builtin:Claribel Dervla','en',15.3,1,'natural','xtts',NULL,'[1, 0.7649498033711534, 0.8000682807243477, 0.6057946042973764, 0.6429616940560209, 0.6889571802062933, 0.4658570160446355, 0.01326659431582514, 0, 0.8084577908907107, 0.8253341508206986, 0.819432282291315, 0.26338090547943754, 0, 0.7648522730988724, 0.6792788975856825, 0.6497902908470938, 0.3713296608053483, 0.008486977128579124, 0, 0.46946644648786623, 0.6764499953332289, 0.6126720138933446, 0.6004780604079435, 0.5975514848769445, 0.5685787017338365, 0.5136572412509006, 0.2886060187904511, 0.4163496773921682, 0.31460346126641964, 0.038239008109503904, 0, 0.8539395032019579, 0.8323091383577027, 0.7362208935775029, 0.6277436824360946, 0.6946152230549741, 0.46990538038188584, 0.22880694831210183, 0, 0.6336455509654781, 0.7380743977696361, 0.8419179199338434, 0.7802653929321156, 0.46263780202803856, 0.4614672004168919, 0.5127304653204565, 0.4983416516899384, 0, 0.4218125166900228, 0.7481709260446917, 0.6352357329562036, 0.4625261618043425, 0.27602187271279355, 0.12832894749010182, 0, 0.6269632972515816, 0.9110819463076308, 0.8377231648506619, 0.385523390056927]',NULL,0,'1/0whm6v9q.mp3','2026-06-05 05:46:00','2026-06-09 11:25:19'),('1j4xkyfr','iidthvnj','News Report','Breaking News. According to the Source details.This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'my-voice-2','en',11.5,1,'natural','f5',NULL,'[0.4284027863645301, 0.8100867368967286, 0.5919964486318516, 0.6322855749993412, 0.34891338168491337, 0.036660616806971386, 0, 0, 0.8522944027437968, 0.9539765390782252, 0.613670638982752, 0.44105473809673423, 0.7736346894883962, 0.43852732749411655, 0.3827326886005542, 0.1332082693972201, 0.10614143318583263, 0, 0.026600982023225785, 0.13606014521690304, 0.7958517202446228, 0.9939546673531564, 1, 0.6507129594531866, 0.571877806178813, 0.550410981673562, 0.22043040068432757, 0.03479388394911327, 0, 0.7856643916559065, 0.8992724965591053, 0.6566761971171485, 0.6998703710085116, 0.5970779760444813, 0.5679370442968311, 0.2633572591221715, 0.6636764160371029, 0.852709235786926, 0.655152423018217, 0.6156598206883411, 0.7691470331278594, 0.5995668729514261, 0.6608244768725258, 0.5251589703464814, 0.7963183947491643, 0.1827326886005542, 0.07715605749486652, 0.16696405405295836, 0.02473424916536767, 0, 0, 0.18863826974181636, 0.994058350275981, 0.9507907469832628, 0.7674642380065311, 0.6290189041434655, 0.8380088115281626, 0.22503851369567288, 0.14980554384378844, 0.1457565001996631]',NULL,0,'1/1j4xkyfr.mp3','2026-06-09 16:31:51','2026-06-14 13:30:15'),('68rfbvzf','qo5ajmvm','YouTube Outro','Thanks for watching! If you found this video helpful, please hit that like button and subscribe for more content like this. Drop your questions in the comments — I read every single one. See you in the next video!',1,'builtin:Claribel Dervla','en',13.3,1,'dramatic','f5',NULL,'[0.8135851824899027, 0.9043972501660572, 0.693772595890775, 0.887492642619719, 0, 0, 0, 0.5245175180792008, 0.6108576819410227, 0.9086743339343976, 0.687692219957256, 0.7852502365209907, 0.22409490537866547, 0, 0, 0, 0, 0.1879366158578641, 0.4510275152586643, 0.7527139452537258, 0.7463492266017393, 0.8117011756083511, 0.7251675352870608, 0.7938553110581948, 0.7395997943416894, 0.8441617781680925, 0.8044197826096909, 0.7692621042714706, 0.6465508541527871, 0.8147054350762072, 0.7256988491136409, 0, 0, 0, 0, 0.40902055627666895, 0.44732424246103647, 0.9313610412059076, 0.7995824730232707, 0.8131530452537856, 0.7614208337919773, 0.4897757544138808, 0, 0, 0, 0.7036803522067762, 0.7943887149082569, 0.9087529586272886, 0.7979796240625001, 0.7628697674520444, 0.07642721980896389, 0, 0, 0, 0.9962319862368968, 0.9190105948266544, 0.8963796215146619, 0.8939864451029456, 1, 0.79576350249718]',NULL,1,'1/68rfbvzf.mp3','2026-06-06 15:46:20','2026-06-14 13:32:44'),('9j38a4p2','iidthvnj','Podcast Intro','ようこそ、[ポッドキャスト名]へ！ホストの[名前]です。今日は、[テーマ]について深く掘り下げていきます。ベテランリスナーの方も、初めてお聴きになる方も、まさにぴったりの場所です。それでは、始めましょう。',1,'my-voice-2','ja',19.7,1,'cheerful','f5',NULL,'[0.7407458118922263, 0.6225014793440496, 0.8935482800139084, 0.7734372017227227, 0.44834497244179383, 0.409792585685147, 0.07367160066138627, 0, 0, 0.14838592862357416, 0.7022264873292592, 0.5256112745729303, 0.4249874893193095, 0.35883077398728896, 0.09871147331097802, 0, 0, 0.515639930550704, 0.4863179030933309, 0.3996266508513982, 0.41260300564264407, 0.5038929286864947, 0.7811319266964443, 0.39033831034302, 0.2793789629577946, 0.8220188692124586, 0.5819787994356554, 0.6635907998639066, 0.1964667906506346, 0, 0, 0.6307881644288352, 0.5659518231775145, 0.789670338335262, 0.7089412275231594, 0.8593088408483892, 0.8580339662199606, 0.8424623404704656, 0, 0, 0.8412785092448213, 0.7496244125898341, 0.5773346069323455, 0.16241446659201048, 0.8730403753017315, 0.7950189380067404, 0.6537358632423075, 0.5475740048034962, 0, 0.7485316247669739, 0.47315941699827496, 0.3600255517804236, 0.4330464769006512, 0, 0, 1, 0.6514137669906525, 0.7052530797455662, 0.39179531627525865, 0.5230615253160732]',NULL,1,'1/9j38a4p2.mp3','2026-06-10 03:49:29','2026-06-13 07:17:53'),('aw6cr5o7','wcy0cecq','YouTube Outro','Thanks for watching! If you found this video helpful, please hit that like button and subscribe for more content like this. Drop your questions in the comments — I read every single one. See you in the next video!',1,'my-voice','en',14.78,1,'natural','xtts',NULL,'[0, 0.0016, 0.0032, 1, 0.845, 1, 0.4948, 0.0081, 0.0038, 0.849, 0.8136, 1, 0.9098, 1, 0.7911, 0.6778, 0.2904, 0.8939, 0.8881, 1, 0.8516, 0.6906, 0.0735, 0.0067, 1, 0.9929, 0.9098, 0.9608, 0.6992, 1, 1, 0.6167, 0.4373, 0.182, 0.8609, 0.0027, 0.0103, 1, 1, 0.8988, 1, 0.6083, 0.6101, 0.8384, 0.005, 0.0041, 1, 1, 0.8155, 0.8951, 0.6083, 0.3468, 0.0191, 0.0039, 1, 0.9253, 1, 1, 1, 0.8802]',NULL,0,'1/script_aw6cr5o7.mp3','2026-06-15 09:44:14','2026-06-15 11:28:40'),('dzshzgie','qo5ajmvm','YouTube Outro','Merci d\'avoir regardé ! Si cette vidéo vous a été utile, n\'hésitez pas à laisser un j\'aime et à vous abonner pour plus de contenu comme celui-ci. Laissez vos questions dans les commentaires — je les lis toutes. À bientôt dans la prochaine vidéo !',1,'my-voice','fr',18,1,'natural','f5',NULL,'[0.9295141965072486, 0.922796595563596, 0.9085150508110716, 0.8378207632738891, 0.8256546621281625, 0, 0.7668637124344888, 0.8980419455629705, 0.7566021929026924, 0.7744276045488293, 0.7208146375753279, 0.4926060278097968, 0.817614456603113, 0.25130153905992253, 0.5746981840641682, 0.8876746073257561, 0.8682623803491304, 0.5132504973272376, 0.902009087278255, 0.6786565066924257, 0.6357912980114251, 0.4482275651162408, 0.5173606261158911, 0.4574840912664881, 0.2797672877626741, 0.40612358425479694, 0.2350100333915655, 0.06146335017989179, 0.31520763677106445, 0.6923883317999012, 0.4039548952808373, 0.40915104862873536, 0.2739932412502095, 0.3252578807537435, 0.4347923632289355, 0.3802168957785522, 0.93041337118338, 0.8432161214978635, 0.7789236330130788, 0.5946922846842648, 0.639969922053952, 0.7255002815801116, 0.6648832225709076, 0.7916711942460265, 0.8555677026216261, 0, 0.2601878031302693, 0.8784710163754834, 1, 0.5672929424661579, 0.6608304747119141, 0, 0.5173076909159164, 0.6245776686035229, 0.5171648589261413, 0.9028299964341112, 0.9100490343306484, 0.8321608841336353, 0.8964551302324817, 0.9305720733942412]',NULL,3,'1/dzshzgie.mp3','2026-06-07 05:33:22','2026-06-14 13:31:09'),('ixaifltr','qo5ajmvm','News Report','Breaking news. According to Source  details. This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'builtin:Andrew Chipper','es',10.68,1,'serious','xtts',NULL,'[0.8957316648469986, 0.4058827127176391, 0.3342249602325241, 0.1586629221699999, 0.07977643376005947, 0, 0.04399851280321026, 1, 0.3877754212123867, 0.09362429478441232, 0.5058203400036558, 0.5039336071544648, 0.16382470957270168, 0.17781494271820483, 0.6053355389690648, 0.3801573428945518, 0.2388236536758535, 0.14705776343721805, 0.1243102662606549, 0.043001781838977786, 0, 0.816952088167352, 0.846427718311631, 0.8377060451364418, 0.3392545778781852, 0.8779324099379132, 0.4177850533574076, 0.3930084251175003, 0, 0.7970168252552992, 0.6818701432658935, 0.25022248633752975, 0.06532141900150915, 0, 0.6564023983574907, 0.8871879807418331, 0.6841692499319321, 0.48770066301972304, 0.3306040864147372, 0.21166275120864528, 0.7917126396384442, 0.2764942436400393, 0.36410238782983384, 0.5471858905183524, 0.3655975168924361, 0.30152006005704696, 0.2785233573080482, 0.5103258014083124, 0.6653020606027038, 0.12238795125326084, 0, 0, 0.13345911668296842, 0.7498257857177201, 0.4957103451241467, 0.45899421980843, 0.5944252542971871, 0.4863123413154032, 0.28692462580372535, 0.14990108316577566]',NULL,2,'script_ixaifltr.wav','2026-06-06 16:44:29','2026-06-14 14:15:34'),('n0afspme','wcy0cecq','Product Demo','Today I want to show you [Product Name] — the easiest way to [solve problem]. In just [time], you\'ll be able to [key benefit]. Let me walk you through exactly how it works.',1,'my-voice','en',11.95,1,'natural','xtts',NULL,'[0, 0.0001, 0.0042, 0.4939, 1, 0.991, 0.8891, 1, 0.7568, 0.9036, 0.7343, 0.4847, 0.3574, 0.0122, 0.005, 0.0052, 0.0077, 0.6632, 0.5889, 0.7967, 0.5251, 0.9633, 0.3908, 0.5541, 0.4274, 0.4766, 0.1811, 0.0117, 0.0074, 0.6705, 1, 0.4789, 0.2159, 0.705, 1, 0.6151, 0.7444, 0.5863, 0.798, 0.573, 0.4583, 0.321, 0.9287, 0.701, 0.2354, 0, 0, 0.0024, 0.0831, 1, 1, 1, 0.8028, 0.6938, 1, 0.9179, 0.6497, 0.6373, 0.2899, 1]',NULL,1,'1/script_n0afspme.mp3','2026-06-15 09:44:18','2026-06-15 11:48:28'),('xu7ibp0n','wcy0cecq','News Report','Breaking: [Headline]. According to [Source], [details]. This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'my-voice','en',11.76,1,'natural','xtts',NULL,'[0, 0.0027, 0.003, 1, 0.5819, 0.4935, 0.306, 0.1761, 0.0127, 0.0046, 0.0042, 0.2789, 1, 0.9943, 0.561, 0.2508, 0.2693, 1, 0.7979, 0.444, 0.2373, 0.491, 0.5113, 0.1275, 0.3772, 0.0079, 0.0071, 0.7994, 0.7043, 1, 0.782, 0.2457, 0.1744, 0.2332, 0.4308, 0.0206, 0.0052, 0.7621, 1, 0.7278, 1, 0.6599, 0.8945, 0.7496, 0.6342, 0.7233, 0.731, 0.6006, 0.6678, 0.2923, 0.2293, 0.2418, 0.1675, 1, 1, 0.9123, 1, 0.909, 0.3776, 0.9438]',NULL,2,'1/script_xu7ibp0n.mp3','2026-06-15 09:44:21','2026-06-15 11:48:33');
/*!40000 ALTER TABLE `scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0OalXQzPw908gdqQ1wDJyxhIP3eybmFuEhkyDoYF',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','ZXlKcGRpSTZJbTg0YVZoaGFTOUpTbEJJYmpocFkzbEpkM1JLTTJjOVBTSXNJblpoYkhWbElqb2lORkZYZEZSVlZWUmlUbHBwZUVwNVpXdG1kbXd3UW05WE0zTlhUR1JDTUZjNU9HRXlRblJUZFcxak5XNXBlRVpTVW5WVk0yaDNOa3Q1YkdGUGRtTklXR05hY0ZGSmJXZE5kVTVXVlRoalZFSnlkREU0YTJwd1VuYzRabk0wWm1GQmJpOWpVRzlEVG5oVFprcEhlbFJYTWtOdFEzVnVheXMzZDAxVFJXWkdSalV2VXl0Mk5FMUZaVWhhUjBkaVJIbFVhblJKZFZGSmEzQkJkVmhYWml0TWVUaFNMMDFHTUd4cmJFRnllR3BJWkdkS05XTjNaVmx3V1ZVd04yWm5RVmN6WjJaNk5uaEVWVnBLV0VsVFUyNDJaVkZFT0VRNU5tbDNOR2xMUldZNVFrNXRNbGQxYkdOV05ucEdRVDBpTENKdFlXTWlPaUk0WTJZeE16RmxaR00zT1RVNE0yVTVZalExTURVMU56UmtabU0xWVdFeVlXTXdZVE5oTm1Oall6UTBOVGhoTm1VeVptRTJOMkkwWmpreU9HVTJZVEpoSWl3aWRHRm5Jam9pSW4wPQ==',1782026068),('2DWrzzbrnAk1aDBwWafCrbozwPzxbnpNyohLqLjJ',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkkyTVdZd1owNVBRVTFXWmt4M1lteEdiV0YwUjBFOVBTSXNJblpoYkhWbElqb2libWxJVjFWaWREbE1XV1JSTTNOcmRtUnRNMXAwTTNwWFJtSnlabmhLZFVsb05HZHdNR3R3YlRGbk9WSnBRalJEWkZKd1lsY3hXRGRwZFZwNWVVeEZaMmhJYzI0NFpFODBSbmhYYWxjeGVsRTRlV0pYYmxNNVozZERVQzh5V25CRlZuQjZWSFZRU0hSMVFqZEJXSEpDWTI1Qk1ERnFaWGhTY2tKWVZYRjFNMEkyWVdKVU4xbEVhMlF5TlVwclZuTkxiMWRQUjJZelZXaEZhVXRsUmk5b0syVnVVVEIyZGtwTVkxTnFXbmxJT0RZdmREVmtaRTFFYUVjcldGcDZMME5uTTJKdVFUaEhXRFJLY1RKbmNrOHdSa05vTTB4cU1FcHlaRUZvV1N0TVMzZEdiSFp6T0d4SGIwaE9VRlZLYzBWQ01Gb3JWalZzYlcxMmNraE5XRGt6TWlJc0ltMWhZeUk2SWpFek5ESTNZMkV5T0dNMVpEbGlNalJrTmpNMFlURmpPR1ExT0dReVpqUTFPREZtWW1abFl6UXpOekptT1dWaFlqTTNaRE01TURWaFpEWmtZVE5pTVdRaUxDSjBZV2NpT2lJaWZRPT0=',1782026068),('5ky25zq6Lo1uEw4vHEcTFau0D7gQ7z4IGHPia29s',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36','ZXlKcGRpSTZJbHBKT1hGc1ZTdHhhV3hhU21SbVNHMDRhM0pUVjFFOVBTSXNJblpoYkhWbElqb2lWMk5MU0VRclZGY3pOMFV6Y1ZSeWJXbDJWSEZ4VWt0Vk9VNUtkRzl3WVhOSU0yOWxNbTVTUVV4UllXUnNjbnBVVEdrd1prcG5hMHhuY2tGWlR5dGtUVzExSzJKcFNraHBXV3RaY1hwd1JHOXhObEpOYmxZdlRUWnpVMlJ3TUN0NFFtRjNlV1prVmxob0wzWkhLMWt5SzBzM2RVMWxaa2hPYW5KMFYyaEhLMFJsUkRkeVpHSkNWMVk0VG5OalpXRTFOVEpUWm1NM05YbFFRamszWXpSdloyWTBZVWt6WTJOUmF6VTBlWHBpVDNWMWNucHNWRzVDU3pGR01HcHBhRlJYZDJSaGRIVkJPRTU2TjFsTlJFRlpRMmgxV2tZNFdIaFVWRmxyU1dWelRFeHRNM04xUkRNeWRGRTJhejBpTENKdFlXTWlPaUk1TURNek5qVXpOVEkwTkdZeE9EQTNNVGc1TkRJeE9HRXlOams1T0RZeE9UZzFZbVZsTm1GbU9UZ3pNamRqTmpJNVpXUXhZamRtTVRobFlUVTFNbVV6SWl3aWRHRm5Jam9pSW4wPQ==',1782183330),('6FNvm3vP12R92Y0FC7zkBjQJXOKmsKBPGmHBX222',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJakJ2WkVSRllUbFZORWhITkdaWlpYQlJTbnBxT0djOVBTSXNJblpoYkhWbElqb2lSVGR0Vm5Sb1JtNURaMWxNV213MVMwcFFiR0ZXZWtGblUwNXJOaXM1WTNwRWNDOTZTakZuY3l0cmJXeG5ia2x6Ym1sR1EwbE5hR2RKTUVGalRrMU5Rbk5UT0VWQmNtdHhZaXRRUW10Q2VWVjNZVTVRZUUxWWNIVjBiSGhUSzA1S2NrMDBZVzVTSzNKb2MwcFhhV1ZFTUZneFowWkRVV0ozZFU5WVNURm5PWHBOVlVob05rTjNaa1J5V1haTVZHZHRiRlZYUmpOcFpYZ3JTV2w0V1RaUFNIRmxjRVpRV0ZBclRTdG9WR1pTZEV4T2FXVjNVME1yZFVSbkwwdHVNVmRpY1hGb04weG9hemhtV1RSSlQyVXZVRzVWT0RRNGJVdFllbFUzWmxwUVRIQnJUMmQxY1UxcVNrZFBWVDBpTENKdFlXTWlPaUkyTTJKaE5UTTROVGt3TWpSbU1EQTRaalF4TkdJeE1EbGpZemt6TW1SaVpqaGhZbVptTjJKall6VmxOREJpWWpsaVkyVmhNVGRsTXpFNE5tUXhObVZpSWl3aWRHRm5Jam9pSW4wPQ==',1781980482),('92I8MJO4sfzjHFkPcUqHgKhubHFgnLenx6HCJ6sO',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJa1JaTkZkQlpUQTVaVlZ5ZDFCNmVFTlBiVGd5YTJjOVBTSXNJblpoYkhWbElqb2lSVmRSUWtWM1ExWjZiazV4VFhaUVNWaHRNREZEUzBsSGN6Wk5TaTk0UTA5a1lXNTFjbUZZTHpkTk9VUnFlVVYyVTJGSVVVNUxNVEJwV0VscGNXWnRiMDUwV21keVoxUnFNRkUwV0dsRFVEVndVRWxqUm1sTldYRXJibTFGTWpVMGFWb3ZhWEZYVFZORWIwVTVUa3B0U0dkbldWaHZVaTlvV0RKT01ucFViMWxqWVdGRGNqWkpWbGxhUWxSek5tbHdlVVZOY2xoSU1rNXpWbGQ1TVdreVdGUlVWa1pDY3pFMmFWVnJlSEpXZWpNNFprMUdVR1o1Wm01bGRqVnVaekJzYW1JNFVXTm5lRGxIWWxBd1RTczJiekJHZDFWWFV6WmxOVWhFUXpJNFFVMXhhMlpqTkRjd01rcFdhejBpTENKdFlXTWlPaUprT0RZME0yRXdPRGMyTm1GaVptTTRNMk5rTW1VME1qTXpZelZrWmpVeU5HVTJOemhpT1RVd1lUWmxNelF4TXpkaU9EQXlaR0prWkRGa05URmhNVFkzSWl3aWRHRm5Jam9pSW4wPQ==',1782019584),('AnC01m0x8VxCtuvsH098M46ICzZsbJyRBoM3obRS',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbEJOZUhwYWNtcFNLMlZSU0ZwQlNVMUVOSFZGVkdjOVBTSXNJblpoYkhWbElqb2lhVlJrTUVadE9GRmtURVY2V1dzNWFubEhOMlJUZW5BdmFYTXJiMWhuYUhack0wSm1jekJZYm01eE56WTJXa1pWZUZCelEwVjNiVTUxYTFWSlZraEZRVWwxWjJsRk1EWXJNalZVTHpRdlNXUTFjMUpvYjFkUlVtOUVTMjFOY0VKRGRIcHNVVk5DV1dGSk5rdG9TMWR0Y1dsbFVHVklRbmx0Y1RsTE5XZEplbHAxZGxOMmJGbDRNVTV5YjBaTU0wZGlURFpFVmxjd2ExcG9iblJSWjJ4RE1YRjFSRlJtYmxvdk9UUnVRVTg1UzFrekszaG5jMVZwVkZGUk1rTllSMlJNU0ZaUlZ6aHZlR1pMTlU5WGRHOU1NVWRwY2k5YWRsWm9iMXBGZWpab1IwazBSMFU0Y1VKRFJWWmhkQ3RaV0RGUFp5OWlZaTlCTTJ3dk5FbEhSRUp1UlNJc0ltMWhZeUk2SW1RMVlXWTJNVE5oWTJOaU5URmlZMk01WmprNE16ZzJPVGczT0RNMFpqSXdaRGN5TmpkaU5HWXpObVJqWkdFNVlqRXhZV1ZsT0dZNU1tTmtOR1l3TlRRaUxDSjBZV2NpT2lJaWZRPT0=',1781980485),('BgJVNjCeBQm6Vy86rP6JfYhitjjW17sxO0bMajmH',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 OPR/113.0.0.0','ZXlKcGRpSTZJbEpYVTFOWFFucFhOWE5yZEhCVVVrVTVjU3RtY21jOVBTSXNJblpoYkhWbElqb2laVlF5TDJSbk5rNHJUM0E0TlVJM2RsTjBRMjV0UVhwa2F6ZFdZekpMVFdVMWJWa3pjbXBrY0dVNWVWWkZSamd6Y1RKRlNsUlFUbkJtU3pac2NrUkZSbGRhVWpaTVpYaDBlV3huYTBKalNYQlROSEkxVWxkV1NucFlOa3A2ZG5CMmJEZDNOVXhpWmtSd1lsUTFPRzVWZVV4UGRXOURZbkJ2V21kbWFXa3daVTEyTVVJM1VHb3pTWEExYzFaTFNrdG5hR2R6TjFkNWR6ZElMekZIUjNOeVZHRlFTRkZvYzFFMFdUSlZLME5LUWpOVFlqbFZZbXhoVGxsek5FdElPRVZSUlZoTldteHJSVFJ6YTFKTk9EZFROVWw0ZG1Zd01pODNZVUp4Ym1OR1FVbEpjWGc1VGpKWFZYWlJkejBpTENKdFlXTWlPaUl3WVRjMllUZGhPREEyWTJObU5HWmxPVFppTjJVeE16azJNR0U1T1RNek1XUXpZbVkwTW1ReVl6ZG1OVFUxT1dWallqZG1OamM0WkRFek1qbGpNVGt3SWl3aWRHRm5Jam9pSW4wPQ==',1782114204),('cjo681ej0EHVcIrMuB8eME3whO8SyMh8B6DgPJlb',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJbGRWYW5RclIzQm1Sa0ZJY0ZoNGRHeFJVM2RHVVhjOVBTSXNJblpoYkhWbElqb2lSV3RaUldsWVJrVmhXWGhWVDA1VVJrVjNhVVU0UTB0clNHZENTMGt2YzJKa2RFZzFRMHRRVEdOSFRTdFZPRzl0ZG0wdk5DdGhUemMwV1hKU1owaDBlRFJ2VVhsM056RlZkMFZSYjB4eVZUSkVObE12YjNOU1VVWnNXSE5yTW5nNGNrOUdkMlpqUkhaNk9EZE1kRWxXVUZsUVoxWmtlSFJNTDBoalVXdGhVRWwxVEhoVVdIQktaVTgwT0d4b2NVTlZjRVFyVGpNd1FsWTNWU3MxTVUxTlFrNHZlVEUyVG1WVGNXY3dObmQ2UkU4MU5tZENiWEp2ZWtKcGVISm1aalJsT1hrNFFscDZZWEJPY2twVVJWZGFiM1J6VXl0bVdGcHpMMnd3WlhZeE1UZG1kWEE1TDA5cFVubDFSa1kxUW5Ca1owZEVXblZLU0RkcmNXUlJkRkJrZFNJc0ltMWhZeUk2SWprMk9HWmpZekZpWmpjM1pXSTNaVEV5TmpNd05qQmlNek0xWVRjMU56VTBNamhtTXpoak1URm1ZalUyTkRaaE5EQTJOMlE1WkdZM01tTmlNamRpWkRBaUxDSjBZV2NpT2lJaWZRPT0=',1782019584),('Ct6Axbi0oWkAsi3H3TyqTL58NMJX83IyWIWpgf6O',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbXBvYjJwak1sSnFTRU0wTjJwd2VuUktjV05QWTNjOVBTSXNJblpoYkhWbElqb2llVXBCYTFWNk5raHZPVkJTVG5GTE5Xb3lXWFJzVW5rMmIyOW1UMWwxVTJaVk9UZ3dReXQwWVhkaWFVMW9SSEJwTnpkNVpESTFVR1JxUVROVWMwZGtRa2R1TURGTlEyUnpjV1ZIVWxsb1VGVXJhMDB4U1ZCTlN6Uk1ablZLWVhOMU5rUXhlWHBSY2tnemJXdHJjR2xKYWpKb2FtTkNjRUpYVm1kYVFXOXlRV05RTWtWa1dXNDRVRXhwVDNwVFJYcElWamxZUTB4UFJFdDNUMjVaY0hnemVtcFVXblpqVkRsa2FtSnVOWFUwTjBOUmNqVk9kbGRSYkhac1dqTkVOSFZrVnpaTU9WaHpla2Q1TjJjd0syeFdSM0oxYlZCVVl6bEpjRkpXVkZrdlpWbElORkJ1ZEdrM2NYQjJOVUU0V1ZCdlFtUk9jalEzTDNCQ1RFRjNlRGR0ZGlJc0ltMWhZeUk2SWpJNVpUVTNZamczWW1NM016QXdZMkUyT0RVMFptRmxNVGN5WlRRMU9EQTRaamN3WVdRNU9HWXlOak5pWlRCbU9EQXdPV00zWW1NM05UZzFZekpoWW1VaUxDSjBZV2NpT2lJaWZRPT0=',1782270581),('CUlQkxACZfk1dy5wTRAhtEZzp3HFfJQudzPaQdkK',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJbXN4WlRRelluTTNOVTloYzNKVGRtTjVOMXA0ZVVFOVBTSXNJblpoYkhWbElqb2lWR2szWVRWSVQzQmFSVlJHU0dRMk5DOWxVMWR5TURjMVEzSkxNbVl2TTJaSU0yUnRMelZ6UW5KTU5WbHpkbGxZVG5KS05qWnpha1JQZDBod1JuWldNMWg1U0ZWNlpsYzBUbEJvUVdwNk1GTTJZa3RzUVM5UFRrMUlaRXQxZG1Vdkt6aFhPVmREVEdobFNIRkRWV2xDYWk5SWVUWnVlVWM1Y0dOSE1VdG9SM00xYm5GT00zZG9aVEpIUjI5RFIyUTNUakZwYkZkcE1ucEJUMVphTm01UFFUUlVaemRNYW1GaFprMVpielZqWldSMmQwUlZkbkpzUzNsd1RHTlhTWE5LTUhWdU5WazFVbTlOVm1ob2J6VjBUMFptVGxoUFpFMHJTa1ZVYUdwRVMyaDVUR0psVkZwMEx6SjVXVDBpTENKdFlXTWlPaUl4TW1VNU1ETmlZV1UxTkRCaVptUTNaV0U1TVRabU5ETmlPR0poTURNeU9HRmpZelUwT0RFek1UZGlOR1ZqWkRRek5qTTJaRGM0TnpWaFpHWmlaVFF6SWl3aWRHRm5Jam9pSW4wPQ==',1782020018),('D6NzF1fkomRIHHaZsVmzr6xgKNZrzpGGqatplAio',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJa0pxVFUxUk5WQm5ZeTlOWVVkWVRVVXhMM3BZTkVFOVBTSXNJblpoYkhWbElqb2llVzVVTVU1alkxZzBSazlQVFZFeGJVRjNRM2hEZEZaR1IzVm1iSEZCY0VGdVVrWmlkRTlIT1RsVFQwVTJjM1ZYU1cxNloyc3JTMXBwWXpWMlFqRlRjV2M1V1RWR1ZGaHhURFF6Unk5VVYwZzNUV3RJTW5sNVJYcFRkVmx4Um5reFdTdFZTR1JrZVdOSU5rbGxXVlozUm1GUWFYcEljazVWU1RKek9IQTViV05CV1N0aU56azJhemR6YWt4U01FSXphbEY0UzI1NVNubFVia0lyV1VsaFdEa3hRVGRRVTJKbWVUTm9kVEpwYlhGR01VRmxObnBOZEZBME9UTXlSVE13VGpGTEwzRnhWR2swVlUwM2VuQnpSSE5SV0RRclEyVk5aVlpaS3pGcVRIWkZUbU5oUkVKcFlqUlJiejBpTENKdFlXTWlPaUkyTVRkaFl6bGpObUpqTm1Jd1ltUm1OelV3TVRZeE9UVmxaVFF3TnpFeE9ETXhPR1k1WVdSak5HVTBaRGd4TURobU5USTJaVGs0WldRM09XRmhabVE0SWl3aWRHRm5Jam9pSW4wPQ==',1782020018),('Enc4XdeOGaZn7GRr7fuVSJRyDpHxJBfUBqEVSfny',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbXd2U2tKbFlsRjFUMjVzUVZaSE5VbFhjVE5aUzJjOVBTSXNJblpoYkhWbElqb2lSRzVxYzBOT1VIcERPREoxZW5ZNFRYVklRV2xEWkZWbGQzSTFXSE4yYzBsU2VsbGhNV2xTUkdGcVJGTXpUVWt3UWtsdkt6VnlMMWx1VGxWQmJtZzVRalJQTDNabFYzWjViVGd3Y25aSlFuVlRTbmR2YjI1aVQyVldUM3BTY1RKaWVWcENaMmRGT0djeFZqYzBVVGhaWkRCbGNEZFhSbFl3UlU4cmFGWlpaM2xpVXpjeVZFeExMMjFsUjJSdlJHUkhjRGMxVTNkaVJuSXhTMHM0YzFKUloxWlVPRTlxUVRKM1pUVlRSMHhqVWs1TFpVUklhamsxY2xCQlZuUkRRa2hNU1hGVGVITjFlVUZNZUdwTU1rMXVURTl6V2xaNFV6QjRjRXAyVW1GM0swdG1PV0ZPU25JemMwOURPRDBpTENKdFlXTWlPaUkwWW1JeU16WXlNRFV5T0RVeVpHWmhNamcxTVRGaU1qQTFZbVk1WlRVd1lUTTBPREF4WWpBeU1Ea3dPRGd4WldGaE5XWXhaalUzTURZeFl6RTRabVZqSWl3aWRHRm5Jam9pSW4wPQ==',1782192870),('fSSkBiv53yg7sm33pR0aqNAPUGnKvLjc9Z2H8kiL',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJbVoyY3paTGRVWkxUR0ZHVjAxQ2MwTmhlRVF5YjBFOVBTSXNJblpoYkhWbElqb2lVM0JzZURGT2FtWTFURmxxU2tWeFNVWlNXbkJyWms1WE0wbDRialJWZUcxVVZYQjRURU5UVDJKak5tWm5UMDF2YzFjeFJtTnRUVUpsVlVKRFNHOTFWblUzZUZoMVpWcFZWbWxEYkRkNlNrb3dPVTVyUjNWMmR6TTVTV1kxUmtaWk5rdEtLMVJVUmpVME1EaFZNeXMyVmxaTGRHZzFObTFIUmpZMlJsQkpVM295VFZKUFRsRTBXa3RyT0ZKUGEyOWxkM1EyZHpoaWVXOU5iMWg0UTBVMGNubzJWV05hWTFSd2RVbE1ZVzVrVm5wTVRXMHZPSGd6Tlc0ck1UQTNUR1F5YTJweFVVSnpVekpPVG1oamJFNVRaMWxCZUdJellXcFRVVkkxUmpoSVFUWnFXWGhsYVdaSVNHeFNVVDBpTENKdFlXTWlPaUl4TmpNME9UUXlOV0UwTWpjMlpERTJZelZtT0RBd1ltVmhOR1prWlRka01UaG1aVFEzTm1ObFlqaG1OekJsTVdJNU16TXpaamhrWkRnM05qVTFOVEJqSWl3aWRHRm5Jam9pSW4wPQ==',1782019584),('GphBhNnHhXYAD7r8YsQUtuPqoUdtiVZ6Yis0fN3x',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbHBOUVZKblduZFdlRlJ3VFRWRWNqSXdkMnhuU0djOVBTSXNJblpoYkhWbElqb2ljVUZsYUdoalVVZFVWVWxUUWpNMWMyWkJRbVJNVEdweldtTlZSbkpPYkc5QlMzQTFjMnh6T1daQmJVazRTRXhRVjNoaVIwNW9PU3RyYkRVelQzSXpiRVJtVVRSSk5HVjJSekpXTlRSMlNUVTFlREZpU0hReE5sRnVhRk16ZUd4bE5EbHhaelpxTjB0TlJIVXJiV0YyYjFORFNtNWFkVXB0Y0c5QmVuQnJObFJsWms1amJqaE1hMFZxYm05aFJFeGtNaXQwUkZoRVZrSkZPV2h2Y2t0MGRtSmtTRFZGTnpkM2VXUllSM1IwU21seVdXdzNaRWhMTkhVdlMwVlFTVVEzUld0WVNuSlRNSEpNV25ob1ZrOXdWMGhOT1N0bVdYQTBlakUyVWxSb1UyZDZZMWR4UjFwNmMyUjViMnBMS3pCaVVubHNSVzVtYzNsa1V6VkNWMEV6YkNJc0ltMWhZeUk2SW1ZM016ZGpNakV6TURZMFpUQmpaRGN3WWpRek56RmhOelUzWm1Gak5qZGhPR1ZsWmpReVltTmlPVEk1TXpCak9HVmpObUptWldabFltUTVZbUkyWVRJaUxDSjBZV2NpT2lJaWZRPT0=',1782158630),('HFFFyFgUQjj0kCUY0japMHb7y6hCpNeus8Wrn8fa',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJa3RIWVdWRVdWSjZOM2QyV2twaFNsWkxXVkV4YzJjOVBTSXNJblpoYkhWbElqb2llVXR3YjFkYVJXYzJVVk50YlZwM2FYbExhSFpzV0VNd2FYaHFTR1kyYm5BM2FuRmpNVnBVVVVsMlVXeENiR3BhUlV0dlRGVTVaMDFGT0daTGRIWTJZMFpsTm1kbFEwZGpOMXBHUTNrMGRFaGtaek0yVlhOVFRrUlNSbTltVEc1RU5rdHhjR1U0V0VFd2FsTjBVRWd3VUhGS1IySjFSVzVYVjBWTVlsazRabE5uUTBkR2JHWXJRa2hVTUdWNGRURXJOSEZFTlZVM1FUWlRabVF5THl0aFZGaDZhazVTVTBKbU1rUm9lVmhpV21oTlEwOURNVzl1ZG5kbWFYQkNWaTlNWm10eGFXUklibGxFWWtoWlRrZFdSbUp4Y0dGU00xWlNTV2N3UTJsUmVsZEtaV1JGY1RoMlZUWk5hejBpTENKdFlXTWlPaUk1WTJRMU5UQm1NbU0wWlRjMU1tVmpaV0UxTWpKbVkyWTFNelk1TURnek9UaGxOelE0WW1RNE9XSXhaREE1WkRSaVltWmpOR1ptWVRFMll6VTFOR0kzSWl3aWRHRm5Jam9pSW4wPQ==',1782270581),('joBUqEA2t4HUzyDeQ4leargCXdXdbO9cscbIbqiH',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJa3hRVVRoSlNtTmlNRXB0TURjeE1sVnJhV3MwUVdjOVBTSXNJblpoYkhWbElqb2lTV1I2Vm1SWFQzZGFkamh5VkRGR1kybDJNbGRZUlhWVVRWcElSVmRMYjNCVFJVSnhiWGs0VVUxeGFXMTNiR05sTkVacmQyRnpVWEJ4U0dWbFJXaFpaVVZ0WjNvMFJHRlZXbmRpTTFaSVZTdDFUVEJxYWs1MGJtZFVPRmgwZUVzMFYwNXJiRVZUYWtobU1XSXlWR2RySzB4d1UwZHBSVVpKTTJkaFRIUnFWMlk1YVRoWVZtOXhVVnBvUm13eGEyVXJUVVJRWTB4MWVrSTFWWEYxYmtoUk1qZHlVUzh5VUhRM2NuUjNSVTVWUmxCaVpDODNhMUExTm1kVlQwaDBaMVJ0ZFVWWlJpOXJkRkpUS3pSTlNGZE9VbmxJVVhwS05FSndOMnhZY1hwVk9ITkRlalJtTXpVNFNVOXNSVDBpTENKdFlXTWlPaUpqWlRZM04ySmlNV1poTjJRMU5qUmhaakU1TURZMll6SmxNRGxsTXpJM01tRmpPREEwWTJKa01tTmlNMlV3T0RNNFltSTNNRGhtTlRabU9EQmtZalUySWl3aWRHRm5Jam9pSW4wPQ==',1781980481),('kfTHcgvtPSRQ8Gj2w1jHJqEX5uhpSR2hDxUeFrgg',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkYyT0U1MFF5OVZVM05uVWxsallqUkljelJ1VjJjOVBTSXNJblpoYkhWbElqb2lOMHAxU0VoU1QyTnRlbVJYWTIwNGVrMUdNbXh0T0cxeEszWk9la1pDVUdwRE1GQm1PQzlJV2prd2MxTlNTRVZDVmpNNFkwbGhjSFp4ZFZkUGMwNU9ibFZXYldNclpUWlJRbFZJVHpOS05taFBTRUZOYmtWSk5EQXhZeXRIU1hBcldscGFVMWR2YW1oUmJsWjNTbWRYT1RaMk4wdHlhWE5wZFhwSFVrZGpkRUZKYmtaVGJXcHNSV3AzWmpKVVJFTjFUSFZYWXpORVpHNUpZM1JqVUZCdFQybGFURTh4WTFoSVFXaHlaREp6ZW1kSWFDdFlkelV3UWpoaVFVdHNhbGxSZWpSV2RHUjNRVEprTTA1VFZVYzVablF5Y0hwT2NXNU5VbEZCU2sxTWFsQk1NSEpuY2tGS1JXYzFORDBpTENKdFlXTWlPaUl4TW1Oa1pqVXhZVEZtTXpnME5UYzROV0k1WXpJek56Z3pOV05rT1RVd1lUTTVNakptWWprNU9UTXlOalZtT1RJMk1qTXlNalkyTmpJM09HVTBOREF5SWl3aWRHRm5Jam9pSW4wPQ==',1782110020),('kmB5PV5lpunhYv2KB44sadpVQa5ZRuFtsVweD7e8',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbGhVY0U5d1ZWVkdORGxMUm1aV1RVTldSa1V4YldjOVBTSXNJblpoYkhWbElqb2laR3BGUjNCaFlqYzRNM3ByVkRsVGNFRjNkRVI1T0c1eE9DOHlZM2hGWVZoVmFFZE1SRlpTTDFrM1oyNXhORnBIUjNWdWVFUnhjV2RRWlc5bmVqUlNhRXQzUjBoemIycEhVV3N4WmxoMGJubFlRa1F3VlRkNWVXTnJSRU00T1doWlZrTkJOMWhFVFZoTVVYSkthVTVLTkd4NVFUSjVVeXRpVkRoMldqTmtNRTVxTDBsTGJFbHhhVVprZGpGWVQwcGFXVEJYUjJWd2IyWTNMeTlzY1hSeFNsbGhOVGg1VG5KTVNUQlZha1ozV1RGdU5HNHJPWGg2WXpWU2JFSlRkM2Q2WW1oRGRtMUNObFZVYjFRM2RETjNjSGg2Y2pocFNqWTBMMDVITlcxTFVUSTBlR1pJUjNGaFFtbFlVVDBpTENKdFlXTWlPaUpsTjJObFpXUXpOMlJrT1dKak4yRTVORFl5TjJFNVpUTmlaVEV3T1RSbFlqQTRPR1E0WTJJMk1ETTRNbUk0TkdFMlpXUTBOakUzT0dRNE16Z3laVFJsSWl3aWRHRm5Jam9pSW4wPQ==',1781980573),('KPCKl98UCLoKs6WEXi4Db4IpFXPrj9Bm8vYO6DvH',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','ZXlKcGRpSTZJbmhhTDAxSmRuVkJaVEl3UjNvMldtUldNMVpLVmtFOVBTSXNJblpoYkhWbElqb2lhMjAzYkZwdWFXWnNWVmRyTld0RU5FSm5NRkJ0UmxWdVJYQmFaWGR5V0VadlkwSXdTbWRQU1N0TFdXSktVRVJtU3pCUVkwazRlWGt2UVhWSFQyUmlNVk5PV25GNlUzaDVjSEJKYm1SU1duUlBZbnAwUm5WUVRqRjJjRFpHVFNzNWEwTnBNME0zU0d0eU5GQlFMM1ZWYkVwTWVXVkdNMjAzYmpCbWJWZFFiMUZ1ZWtOemIxaFdORTlQWld0emMwMXJaRmx2U3poWU9VTjRSbU5JZGpONlkxWXZZMm96Vm5KRWJtOU9VRXRKVDBKWFNHeGliV0o0UVVGWVkzVnZaVkZLYmtNMVFrdEhaWFppVmxOSFRrSlRjVFZQZGxkVVJWTk1VREZrWW1kQlVtWkVTbXhGYWtKeE9HbHpPRDBpTENKdFlXTWlPaUl6Wmprek5UaGxNelJoT1RNeVkyVXdNVFZpT0RWbU9Ua3lOV1kwTVdRMlpUQTNOR1kzTm1SalpUUmpNR0ppTjJFME5XTmhaalk1TW1Rd1l6VmtOVEUzSWl3aWRHRm5Jam9pSW4wPQ==',1782025562),('KycKLO2gUvCVczEOrUhtUElOaIG19H3xWMzGm6VD',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbE5SY1dwRGFFcFFMM1ZDTURseVZUY3JWRVJoTUVFOVBTSXNJblpoYkhWbElqb2lNV0l5Y1VoRFYzaFZUMjE0WlhGSVNXZ3dNWFF5U2s1aE1TdEVkR0ZUVTA5TGNubHFaelY1Y1dnMlkwTldhRnAzY1ZKSlYxZGFiWFlyVVRSbFlsVlJTamx1Tm1sNVNrWkRjRm96V1VoSlVDdGxWMmRXVlhoNU1YbFpWV1EzWWxSbVJrTTBhVVlyTmxoT2FpdFhWa2QxU0ZWc2RYVmpVWGRyV2tSS1IwSnlNVlZLZVVveGVVTklaMlZyWVZjclVVUnRRekF3UjB4M1UxVm9kMWxrWkRNdloxRkVTR0owVDNOb1NrcHBWR1p3TmpSNFR6ZHdWMUJ3VUhoRU9YZ3ZkRVkxVDB0aVR6RnVWVlZDUmxWWE1reFZMMDFDT0hkbU1VNDJZMEZRU1cxQ1NqRnhOVmxtWVN0Sk1HaDFSbUp0WTJGT1V6SjFhR2t4ZUdjMFJYQlNRVTlOTkNJc0ltMWhZeUk2SWpZM1pERm1Zams0Wm1aa01XTmlaall5TURBeU5EZGxNekpqTkdaalpUZGlaak0xTURFeU5qSmtNV016TUdRNU9UazNZamN6TkdZME5UUmxNbU14TXpVaUxDSjBZV2NpT2lJaWZRPT0=',1782159080),('LoQHkdzlCu1lBn3fdEde7qHY98Ild8SaCWwcwxEd',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36','ZXlKcGRpSTZJbk4yTVd4VGNDOXViVkZMVkV0MlMyUlJabk0zYmxFOVBTSXNJblpoYkhWbElqb2lZMUE0YldFclkweFdhVWQzWWpGRkwyOUhNMGhvU3pONGFHZ3haM2hZY1VsNlQzUnRhVzlTTm1GR1VGcFNabWd4YzIxR01IVnZVbmxwYWtGdE1VMHlUREZsZEZwNVExRkRlbUU0UnpKalYzQjNUWE5JYVRaNFVsRm1VM0phUlc1dWNsaHpXaTkyYTNFelNsbGlMM1JKWWxSVVJHa3JjMFIwYTNCS1pFRm9XbTFKVVhadlZFWmtPR1phVlZreU5HdDJUMkpQVlVSTE9UWmFNSEZITjBvemFIZGtUMjFGVTNJMldqbEJVMVJ4Y0hOc1FtbENXV3c1VldwMGNsSjFSM2RuTTFWQ1RIZGxVMFZLYWtwRmJVVXhhMkphTW5kdlJGVXJUM2t3ZEhWMGQwTmliRGhPVmpsNllVdHhhejBpTENKdFlXTWlPaUkzTnpneU1qSXdNbUpqTURRellqYzNNalZpWkdaaU9XRXdZbUU1WkRNellUazFNREEwTkRjMlltTmhZVFl6TTJNMk5USTFOMlZtWVdVMU5EVmpPV1kwSWl3aWRHRm5Jam9pSW4wPQ==',1782183330),('O46JxGKLDfb0JCbrC6ahNCmqu5CIi42tWT1Xt3gQ',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','ZXlKcGRpSTZJa053TXl0cVJqSkdNalkwYkZaTU5WTkRaM2xUWjBFOVBTSXNJblpoYkhWbElqb2lRM3BWZUROc1ZGTjRVV1ZxU0ZodmNubGhWelpvVGxWNE9XaFpZelIyV1RSRlVrRnVObTFFWkZBMk9IQnZaM001U1ROd1NFSnBTeTl3WkRCM0szZE5NRFpaUmpaM1p6UkJRMWcxYVcwMWEzQnFSWGhWTlRONFUyTXJhRVEzYWtNM2JFb3pVM0l3YTJ4amEyNXJibWhMWkhBd0syODJaakI2VkhBelpWTmtaSFZ5WVRKaWVYWkNNRVJ5ZFV0REwzRlpUMlpPTUdGMU5YRlhXbGhWVm5OUWFHbGtiVEZ0TUhwYVZWVm5SRFl2U1U1clZFMVhPRXhWZGtOcmRUZHphV2xuZG1Kb2VUQTNXVkF5Y1N0eWNVWmtSR3BKVVhscE9FOTRSWGxIZEhjM1VtcFRUekUyYkhkUE5WSnpTVDBpTENKdFlXTWlPaUl6TlRreFpUWTFPR1UyT0RZNFl6TmlNakUzTlRVMlltUTVZakk0TTJFNU4yTTFaVGRrT0dVNVl6UmhZemxoTXprMk5HUXpZbUl6TW1JellqRmtOREptSWl3aWRHRm5Jam9pSW4wPQ==',1782026068),('QfyRCULRfJUr7rMqyj815fwUL7lmp6PTNEpH66OX',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36','ZXlKcGRpSTZJblYzY0c5MFJXSkJWVEpCV21zdk56VmlLMlU0UWtFOVBTSXNJblpoYkhWbElqb2lZblpvVTFwTEwyRnhTV2xNYWxKTlkwaDRNMWx4UnpOSlkyUk9aVm93TWsxTUsyMURaSE14YWtjNFZEZ3pVbFl2VDA5SFJWUm5UMWhQY25aTlVuVTJNVUV6TUZCemFrTnBMeTlEY201aVdUZFZXVFp3T0ZwbFNWYzJhMUZITlVkV1YwSnNNbXhRY1V0dmJEVmpjazFJY0RsYVRVeHphbTlWTVhkVWJ6Vk1jSFZMVTJWWlVIUXhTbUVyVUZsUFdFZGxibWs1YzJsaU1DdHFUbkprY21SMldVNTNPSFJpVG5sQlMzUlRNRUpxUVhWSFpUWk1WRk00T1VWelExRjVTMDFXT1daWk1EaE9aMDEyVVV4NU9VMW9hVWxVYlVGS1dsQklXVUp6WVhKWlZHOXFVM0JrSzJ0UVNVcExRVDBpTENKdFlXTWlPaUkzTldWaVpUTmxOR1l6TURFek5HSmtPR1kyTm1ReU1qUmxNVGt3TXpBNVpHVXlORFZqWVRZMFlqa3lNRGxqTVdJNU1qY3pNV1pqWm1VeU5tRTJOVEExSWl3aWRHRm5Jam9pSW4wPQ==',1781980478),('rSkYYaFgSwgn6s92u2SV8u0r4mtLyRb0YTiyX750',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJakJoWjFCS1RGaFZSR2RuVlRaTGVWa3JNM05HWkZFOVBTSXNJblpoYkhWbElqb2liRUUxUVRGSWJURkpTbEZyWkdwbWNtRlJVMEZxTDI1blowbExNRlJqTm5OT2RXbGpRV2haTldnNWRsUnRMMUpPYTJ4dlRESnNZeXRUTkhKNGFFTnJiRTkzVVc5NlZFOTFiWEpuYkRSMGNVY3hjMVZ4Y0ZWblUweFVSRElyVHpCbGJtTmFOazFZWm1KTWNIUmtRekF2ZEZGMmFuQlZZVkJxU0ZkNVpUQjVSRFZMVlZKdWRHOTNNMFpTU2xJeU1XeE5NMWhsVkhGWloyVkdTVlpWTTBkRFVURjVhVE56VlVaTWFDOTJiRzV2VDFsamJ6RnNWMlJOVkhscVRFMXFhalpVWlVWUVNWZEVaSE0zV0dobGMxTndTMFpwUzFGNlpGTlJVV3hwZVZWNkwweE5OVWRLVTFsTFIxbHFjejBpTENKdFlXTWlPaUl3TTJJME9UUmpaamhsTTJZMU5EQTNPR0ptTm1aallUVXhNelEwTkRnek5qVXdPRFpqWW1JeFpqWTFPR1EzWWpBd09HVTBNMll3TldNNVlqTmlZemMwSWl3aWRHRm5Jam9pSW4wPQ==',1781980483),('RtmjY0Gxq0k9HZRVivv3iv9GOXBCiipYvhRGFEbm',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbUp6VWpWek1FbERLM2R5UlN0eVdIY3dNM1JYY0djOVBTSXNJblpoYkhWbElqb2lSblpaYVd4bVdFeHVka1JRUm5GNmVqbEZlbU5yTUZoWGJUazBRMk54VkRrMVNqSTNlVWRhVjNONVNFTnNMMnRRT1dkb2RTdDBhRGxUTVdOUWVsTmtVR056VjBSdFRqQm5SVUYwTms5b1JIRmlOa3Q1VW1GcFFsbGxhMGszTVZsTVZIQXhRMmhMT0hseWJGZFJTVkU1YVhnMlF6ZENTMlptTkV4ek4xUnJRa3B4WmpaMk1qUnJXbXRUTkRWRFVWQndSR1JNU2pGM05HZFROR3hqU1dOVVYzVnlSRkZ5VnpOQ1YxbDFlVWN4Wm5wTU4yOUZSMjltVUhCMmNWRllSRXBWSzBwRVMwdGxRMFZ3T0hKQ2RqVnRSbE5oWkdaaWVFWnBiWEJDTUVOUFZqUkhiM1I2TldSdldTdG9lVWxOWVU1RGFtZHJWekJUV2s1WWJHb3lSMEpJTUNJc0ltMWhZeUk2SWpVMlpXSTNNalEwWWpVNE5HUXhPRFppWkRBM1pEWmlOV1kzT1RJd05USTJZVFEwWVRJNVlqRm1PVFUyWkRWaU5XRXhNekUzWVdKbU9UbGlZakl4T0RJaUxDSjBZV2NpT2lJaWZRPT0=',1781980480),('sDeF7EHhnch0iKtmfk2psayEHeCBugqKqMGcC9Zm',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbTA1TTFacVUxZHlkV1phWm01bk1sRkhWVWRaTkdjOVBTSXNJblpoYkhWbElqb2lia0ZhVFhkdmJUUjVhakZrYVhka1MzRmliM2xMV21NemFIRm9VMFl3UTBFMGRFZHhXbVZJVlZJdlpYTm9TM2h0VUZaWksxUjBTM1pHU2tKeU1VRjVNMkozVURGak5rSmpVVWd6Y21sSWMyTjRMelpvVW1keVNrRlVZMkowT0cxak5saHJaV3huUlhCRWVFNU5VSFZSVjBkR05YTnZSR1poWm5aWloxbHRiMHhCUVZaU2QxQTBTbmRIUTJONU1teHhVVVkwWVZCWFMzSnhNM0pqTTBabVNpdEtORzFDUzJFelJYTk9LM05EYzNWd1dWWXhWbXRzYURkblFUZENXblpwWW14MlJGTnlSazlGYkZwQ2FGVnFRbVJaYjBKSVNYaHdMMUZ3VTA5a1Vpc3hTa3gzZDJ0cGNuQkVRVDBpTENKdFlXTWlPaUl5WVdVNE4yVTRPVEl4T0RBMk1qRmpNR1kyTTJFM05Ua3lZamN6T1RCalpUYzVNekJpT0RjME5HRXlOelF3Tm1Ga09UWmlNalExWWpkak0yVTRaRGsxSWl3aWRHRm5Jam9pSW4wPQ==',1781980573),('sSKLBleez45mdu0YK21HAUKGOTbZEub4GJ3dWNGy',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJamxaVnpsUFZGSjFRWGxzVUdKcFJtOXJSM2d2WTFFOVBTSXNJblpoYkhWbElqb2lRa3BEUjBsQlUyNUJNWGxzTVZjclNIcFJkVGwwWW1sb1psbHJRMU5WYzJ0T1JrbEZjWGxRU0VkTmNUUndPRzVzUjFwUU9XVnZXVGhEUW0xeFNUVlJZM1YyTm14eWRFUjZiSEZTWkRsVGVrWTJiMlExTlhSMWNEQlBTMU0wYTBWSVpuSmxOU3RWVDFONWRqSlBSbU5GUTJoVGQzQTNNMjg1Y0VOc05rc3pkVU5sVEVGWlRWQjVjVUphTmpWWGRUSkpjWHBKYTBKSFNVTnpZazlJYkZObFN6aFVNbWRVUmtGQlNHSklOVXh2TDBJMlNYbExMMkpsYXl0T05YRlNPVFp3VlhoTmQyZEdWR2N3YmxOeWRGQTFjME5CUjFvM2FtOVJWRVExVDFaUVRrVldaMGxYTTBWUlJteFBUVDBpTENKdFlXTWlPaUkwWVRnMk1ESTVOemN3TURkaE9EWTBaREF4WldObVpETXdZVGs1WmpGa056VXpaakF4TnpBNU5UVmpObVU1TURnNE0yVmhaakV4T0RJeVltVTVNMlJrSWl3aWRHRm5Jam9pSW4wPQ==',1782270581),('t01Nwjqg3uTPiHVl4UpUDCWUNIo2xnXE3bV62VNc',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbEV3UjFwRWJ6bG9hM1JQVURGVGJFbFRUa3gyUmxFOVBTSXNJblpoYkhWbElqb2lia1pDZFZaVVZtUkJNa3cxUTBKemJHY3hkR0ZsTlVGRVNXdzVhV0puVEd0SEt6aHpTbnBDY0VoMWFUUlBTV2sxTm1rM2ExRmFlbkI0YnpORFRsSmtiRzlwWjFJclkxbEplVFp1U1hSNFRWTjZWVEJsT1VWNldIUllVM1pCWkRWTE1IUlFaR1YwVFZkc2EyNVVUa1V5YURaSGVWRlNhV1U0UlRWNVQydzVLekp6TWtvNGFEQlpObGxZTVdka01YTjJWMDh4TW5WQk0yMXBSMVUwSzFoc1YxQlpZa05yTnl0dVIydDVaSHB6TTA1V1l6Qm1abmxQWTFSNGQwTjZTREZUTDNvd1owVjFla3RWWjJVd2Jsb3llazlZVFUweldGaFJZVUpKZVZkVFowcEVVUzl1WjJKblJHMTZaejBpTENKdFlXTWlPaUkwTVRjd05EZ3hZVEZtTW1Fd1pHTTBaVGN4TkdNd056aGtOVEppWldSaE0yTmlaVEkxTVRka09ERmpaVGRpTmpSaU9EQTJNMkUxWVRoa05tUTFaRGsxSWl3aWRHRm5Jam9pSW4wPQ==',1782109976),('tMNaySBL52BVREXS2f1r7f969jLq8AoaktxWD544',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbkkwUzNKalJVaFVWbTk0TDBkVFowRTROSGd6YldjOVBTSXNJblpoYkhWbElqb2ljbXcxZFM5Wk1uTTJTekJEWlZCcE5WaDBjelZSYnpVMGVrUTVhRlpGUzFGd2VsZDJkR2x0UzFkdFZWRmFSM2wxWmxSWGRYTXZTRUZqVUhCb1FUQnViRkZLVmk5U01GSlBlRVJUUm5Ga05XTmhWUzlOYmxrMGFtbDVaRTFYTkN0VU1rMDRTbGRsU1VGUVltZEdUM2h1TkVaRVIycEtUV3Q2YWk5UmRteGlRVTB3S3pZdmVURlFZMnRJVlhOQ05GazVRMGxLVVhGcWJuVXphMXBtWlVOS09VTXpTRXRuWkVsQ2NrUXdOblUzVlV0c2QzWnpiSFF3V2t4MVVWZzJkMmN5U1hOeVQzZHVSVkZSWnprNFR5OW9ZbFZ4UmpjdlNGcFpSVXMyVDFCMWFXZHdlV2xXUlVjNVVFMDBSVDBpTENKdFlXTWlPaUpsTTJFMlltRXpaRFE0TVRJeE56UTFZVEUwWm1JME9HTmlNREF6TlRKaVpXSTVZakppTUdVMllqRmhOalkwTmpaa1ptTXdOak5pTmpnMk1qa3lOMlEySWl3aWRHRm5Jam9pSW4wPQ==',1782158629),('tqKVIghX3SSORgGnnsGH8zR8WEo0GXSHsMdmyKkj',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36','ZXlKcGRpSTZJazVvVG1scWExcFhZMHhXUlRJeFdXbDBSME12ZVVFOVBTSXNJblpoYkhWbElqb2lXRVZHU0ZvMWRucFhjbEJ3S3pOb1FYRjRhbU5qUlRWSVZTOTVlRnBVZG10VFpGRkRPSE5MYVVNNFNHUlJVblZFV2xRM2RXVk1OSFptTVV0c05qRnBXbmhtYms5S1kyODVhRUZGZFhad2JXaDJaMDQwWkhGRlN5dEpVbk5GVFZaM1JGcGpjM0pZUlZodk9HbE5OamhUYzJOc1JIaE1ZMkkzTXk5U1ZHTldjR1pzVlROVldVSnJlVU4yVTBaQ2RHWnBhM0psWlZKT1pIZE1jVGt5Y25WR1NqWnRUMUF5TDFnMldIRXpOMlZ6V1RSMFZsRjVjMm96ZG5wdlRYVnpRbmRCUW1WdFRUZEdVMVI0VEVobU1GcHNRa3RPT1VZclMyVlBTalpYVFhSR1dHcGhaRU5GVlZsaFFVdzVkejBpTENKdFlXTWlPaUkyTmpBM1pEVTBORGd5WWpnd1pUaGxNakV4TWpBNU5USTROR1psWlRKaFpERXhNakZqWm1OaE5XRTFOalpsTUdJd016ZGlOV1kwWWprMU9EUTRZMkl5SWl3aWRHRm5Jam9pSW4wPQ==',1781980478),('uWpUjJv9osng3VgYBhpebxws6bs9OnrFAB4dtIem',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJa3h6TlVwQ1dIRkdZVWx2ZVRVNGQxUTRVbHBzYm5jOVBTSXNJblpoYkhWbElqb2liMHBqZGtJMWNXcHlXRmx3YjNsdWMzWTRhbUpCU3pWaU5HTnBNREZETWtaTFVVVklPVEIzT1VkcWRTOVNOalkyVWpRd2VuQTBPR2xQV21WSlZuRnFVM1IzUkRJeVdHWlNhbE01Vm1sTFpXaEhla2xRTW5KVU1EQTJUVVJPVGxZemIyWm9WMk5xWkRkaVRXd3dOelZzWTNnMU1WaEJTR281UkVGNk5YVkRRMGRGZEVST05tMUZkRE5wTTAxUmJraHBURlppSzFscVNHOWtTMDFFWmxScWVXVXJWSGhzV1VZelpscElXRmhDVjI1SFQzZHZNSGxPU2pkd1NUbFNPVk5MTUVVMlZEaFZRa3AwZDJRclFUUnliMDFpVm5oQ1ZqbHhUMGRRVERKT1JuWnZhRTFYU2xSTFYyOU1ORDBpTENKdFlXTWlPaUl5WkdNM05URXhaRFpoTVRSbE1EWmhPREF5TURkaU9HRTRaak5qTWpaaFlqWTBNbVpoWW1aa1pUa3lPRFEwTURsaE5tWmpPVFJsT0RNeFpXVmhNV1ZqSWl3aWRHRm5Jam9pSW4wPQ==',1781980481),('UyS9Z9tIvoTX5cSNZ9tBqgbl3xjODVD60aoe4kP7',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbWxFT1hSMlFVOUVXblJGTjFoSmNrRjJlSFZvYTBFOVBTSXNJblpoYkhWbElqb2lWMFJzTmtab1VtNVVNbFF3Y0hGbFVVOTRNMHRFVWpGblNIWkxRbVJITXpaRFpDdGhLekZwZEhOUEswWlBaRzB3UW1KWFMwTnpObGxTVGpSdVNuQjRVU3N2Vm5sTlYySjBObTVZTUN0S1FXWkpVWFZHWjJSVFJWVkhZbVJyZWpOaGRVMHZaMWt4T0N0MFIzWlVNa2hxV0VZckwwbFRabFZKZFRreUx6TTFVMUo1VGxSa2VIcEpPVE5SVFhNM0sxcDRiRlpDYm1kVWVrUTBUbEJTTjBnMVJrNXdObFZqUld0MFEwRm5lRFl4UVZJeVlVVTBlVEpDT1hoU1VUTXZRbFpDYW5ncmFIRjZTa0oxTTNkUFMyUXpSM2MzUTB4UmVUUkpRMkk1YjJKamVGaG9RMlJsUzJsTWIybElPWEpVY25OU2FuaHVVblExVlZsMk5WTlFZelJKV1NJc0ltMWhZeUk2SWpkbE5qWmtaREV5Tnprd01UUTBORGd4TnpJd09EYzRNV1F6TUdVMlpqbGtNalZtTjJRME1qTXdOV1ZtTm1FNVpXRm1ZamRpT1RnM09HSTJaRFV5TVdZaUxDSjBZV2NpT2lJaWZRPT0=',1782192870),('VAHZRM9viM30Hd6rxgrmnw4vglLuyXvZn1Hqjqbp',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbU5ETVVwYU0yRnZkRzQzTTB3MGJYaGlXRkJYTmtFOVBTSXNJblpoYkhWbElqb2lWMnRrY3paeFFXRk9UV1pTYUVSblJHMVlTVE5YUmxJMVdWbHJWbTkzV2pjMWJ6TjRRazB2T1VoSE4wbFhWMjFpZGpSNVRrTjJjekpXZG1sUGRDOHJlV1o1UlhZMWFYTnRUMms0YUdGSlpEbFpiRFJPWkU1bk5VeHNNbVJGUmpsWlZqWktLM2xGVFdvMmEyRjJPVWN4WjBWS01HRlZSRmN2WmpCc1QzZFZPRkZwZG5oR1VUUkNhVGhOVlcxUlIyMUllRFZSV0hCa09GWTRWVlpTUm5vd1JHVXJNbVUwZDJ4cVkyVmFNMnBDV0VSNFozb3hkMnN3UlVaV1MxcHJRMHA2ZUU5cVltMWpNa3hIWVVrdmQwWnBibHBwWWxWME5XSk5jVVJUYTJwdmNWcDJNVzlLYW1kRmFERlJNRDBpTENKdFlXTWlPaUl6TVRBd1pETm1NVFU0WVRobU5HUTNPVE13WVRGaFlXSXlOekl4TVdVMllUZzJORGRsTkRVM1lXTmpZV015WXpFd05EQmxPV1psTURWak4yWTNNR1JoSWl3aWRHRm5Jam9pSW4wPQ==',1782158628),('vFIugvx2jpjfySMCfEyEnYAvQ11Z0YkH4bNcZnRX',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJak54VUVwV2VYRk9kWEkxZUVGNE1scDRkbWsxTjFFOVBTSXNJblpoYkhWbElqb2lkWFZwVDJwMFpFcE1MM05qYzFKbk1YYzJVRFYxVEhGTFp5OTBkMDlQUWtod1YxWm5VVkZMT1RkNk5rMWthVVZQYVhWYVFtUlhPSEZMSzJkaFoyVlpObUpwZDIxbU1EaDVXalJEVFd0dlpYbHJRbEo1ZUVFeFoxQldhV2hZYzBoU1ZWVnFPREpLZERrNWRFTndZVmxIZGpWSlJ6aEJiMWt5VDFneVozYzNSWGszV0dSU1kyNWpUbGhRUXpVMFFtRk9hRFY1YURoVlFWcFFjblpvZVVjNFYzaExNVTUzY0Zsb1NqVlJaM3BOZVd4aFJ6QmpjbE5QUTFoRlVYTjVZWEJxVEROWGNtNUhSVlJNUzBSSGVtNHpVbkZVYUdsM2VqUnJURkpoWWpWYVlraEhibFU0TjBkYU0zZE5ka1pDUVdkWVRUTm9NRFpMVUhSd05VTXpXblUxU2lJc0ltMWhZeUk2SWpnM1pXUmpNamd4WldKaFpUUTRaR1F3WW1Fell6UXhZemsyTURObE5URTVOekU1WVRZNU9HSXhOMk00WldNMk5ESTJaV0ZoTkdZMlkySTNNRFUxTldNaUxDSjBZV2NpT2lJaWZRPT0=',1782021637),('vLwmX4AGeyeV6TuLIEvfrna2KLr5xvDJX0ufJWOB',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJa3h1Ym1ZdlJIbGlTalkxUTBGbk56VkNTR0kyTm1jOVBTSXNJblpoYkhWbElqb2liM0EwWm5GUmVGZDZiMHgzY2s1d01tZFdhazQwU25sU1YyaEtObVl4Tlc0clpXOUlja0pHY21VeWVXaG1kVkI0VjBkeVpVOTNTRGw0WTFSd2VFMVVXamhOUzJNeVlXbERla2xGZGsxVWRqbFFaVlZQWWtkaVJqaE1PVTlEVUVzeFVsWkNUMFpsTjBKMFVHcG5iSGxqZVU1M2NreFVSazlJU2poQmFDdGhVM2g2YkV4d2VFZFpjVkJqTjFWdFJVOXVLMjVNYlhCS2FHMUZjMkp0VmxNcmJFNVlTbnBYYVVSc2JrdHRjV3RCTmxKMVRETldkMUZHZDNoSWEweFBlSEpwTjFkT2VrMTZVME5TT0hGSmNuVlpVMUIxV0VaSVpYVllaakZKTmtkdE1HbG1SSGxXVW10WGRtZFBXVDBpTENKdFlXTWlPaUl6TVRVM05HUTJOMkZqTURrNU16SmpaR0ZsTm1KbU56WXhNRFV4WVRBME5tSXhaak16TWpFd09HSmlNV00xTVdNM1kyRmxaakZpWWpSa01EYzJaRGt5SWl3aWRHRm5Jam9pSW4wPQ==',1782021636),('vzMazrvc8DkaIW8pwBbggn74dA2UbE0mawUueo0y',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 OPR/113.0.0.0','ZXlKcGRpSTZJbWt3UkVwU2NXbEJaR2R6ZVRCR1RYY3dTbEJhT0ZFOVBTSXNJblpoYkhWbElqb2lhMWhLZEdKME9IcENiRWxUVm14eWEwcGpNWGhwVlhsb1QyUkZTVEF3VUVwamFIbGxVWGhZWkVJeE1qSlBVbE5ZU0ZWWFVDOXpVak41Y2t4WWJWa3pPRUZtT0dWTWNHaEtLemhXVm1rNFJUZHBURWN3WkVRNGRVNXpSMmRyUnpsa1NsWkxTR0ZPWTAwd1VqVTFWV3BzVFZvNGNrVXdMemhLTWpGelFVcDNaSGxOVkhRNVRVcGhla1Y2VWt4bmFYRlNlRVpoY1U5UmVHTXhNMDV0YXpFM2JGaFZNbkJoWm1wdE5XOXJZM0E1ZGs0d1MzVlpVRkpoYWs0eE5rRlljVk4zWWxOMk16TlNNRmN5VW5CbU5IZFlSWEZqYlU1NU9UUXZhVVpYYURrdk1XRlRTRGxFTWpWd1dUZFlSVDBpTENKdFlXTWlPaUppTlRJek9HSTRZVEJoTXpjd1lUTTFPRGN5TjJJek5qZ3dPV1EwTnpJeE5ERTNPRE15WXpBMVpHSTNOV013TWpFd09XSmxNVFV4TmpnelpUazRPRGM1SWl3aWRHRm5Jam9pSW4wPQ==',1782114204),('wHdxUR9sMwXBtE3ejqzSEztp89FGBmxNbGMUk7kw',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJakZSWW1kNVFtVkdjMEpaUWxob2JtVklXVE5LY1djOVBTSXNJblpoYkhWbElqb2liWFZwWlZsdWVsZ3JXaXRvTW5JelEyeGFNM2RwTDBob1NFcDZXbk5DY1VaNWJVd3ZXbXRPVldsUE1pODJibTlRTldRd1luQXJTR3czYUN0WVdWcDJjR00zTW5sUVJIcHZjRlE1U0RWTWNDdFRRa2gwTkRkaGRuZFBZM2N6WVVWTGVISjNXVmd4TVdrd2RrOVBXRE5yY1ZWcFVHRnZVVWhaVG5ka05VeGpabEJwU210SVpIUnJVVTVKTjFJNWMwNW9PQzlwZWtGRmFsUm9LMEk1WVROalJtVlNhbkZPVmtoQlkyODVSVnBDT1Zjd1kzRXJNMG8xYlZOR1EzWlBUekZUTUdSRmNrTnViM1pKYWpkaWRHSnZUVGRCYWxoVGJqSjJMeTlWU0Raa1dHUlFiRk12T0VaM01tTjZRVDBpTENKdFlXTWlPaUprTW1VMk16STJaall5TldRNU5XTTNNR1ZpWmpWall6Rm1NRFZtT1dKa01qbGxZVE5oTlRobU1EQTFaREUyWkdKaE1qbGtNV1UzWlRJM1pqWmtaVEF5SWl3aWRHRm5Jam9pSW4wPQ==',1782192870),('wNfTI9wewwe5cUDL4kaKwTUkuFVVPTSk4IekjLsp',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJalI0UlVOSllqUnlSV2wyTkZwTVJscHJOMjVPYlZFOVBTSXNJblpoYkhWbElqb2lXazR2UzJsTU5GbHZhREJTY1ZOcGNXUlRaSFZ6TW5OamEzVjVhVFV4V1hvd00zcDRTRlZJZUhKd1dVUlhXREIyZEd4M1ZtSjBkeXRCVFU5UVdHVkxUbGhoUlRKUmJXRm1kM2xyVkV0aU5taFRlbFJLYnpaVmJXeDZTM292VmxNemNVbFlRbGh4ZDFjd1RuUnhUMnB0YTFSWWRFcExlbTQzV0VkWVN6UjFXWFV6Tm5ZMU5GQkNSekl2V1RBNFZsTkhOMjFoTlRkVU0yUkxhQ3RwWTJwRE0xaHRSVXBrWVhob2NtTTJjR1U1TVVKdVRuWkhiMWRpZGxBM2VWWkJZa2QxU2prMFExVkthSFIxSzBSUlJXdGxMMmN4WWpoRU5rNVpjSEZMTVRkbkt5OUVSa0p0UW10VWN6ZElNRDBpTENKdFlXTWlPaUk1TlROaVptWTVPVGd4WVRrMU1UQmlaakV6T0RJeU1qVTFZVGhtWmpGbVl6QmhObVl3WkdRM01ERXdNekV6TUdWbU1qSm1aak0xTlRsbU9EWTVZVFprSWl3aWRHRm5Jam9pSW4wPQ==',1782021636),('WYGTPQ5vSr0j9YHqIIz6MGwhR81Rhzfxkaxunknp',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','ZXlKcGRpSTZJbWhVV0N0SldVd3dOMFYyWjFOTlp6ZFFWa05HZFZFOVBTSXNJblpoYkhWbElqb2ljVGhXV1dWa1RFMUhObmhqUVhjNWNGTnJWR0l3YjB0NmIxRkNiRTFJS3k5NFdHcGxTMVZUTnpWbE5tNW1TVWRvV0hkV01FdGFVMHBDU1RKUk5WVkxhMkpNZWl0TldUSmFaME4wZVdwQmFrNHJabWRvWjA0eWIwNW5RekY0VFdGNlNqSnJabmhoWlZveVJVbHRTbkV5Ym5WM01YTXZabkpPVlVKcmRuRmhZbmhyTXk4Mk9EQXlSMmRVWlRVd2RFa3JRMFJxVURWdlV6SXJSalpRU0ZNeFNGUXZZMnRDYUdkMGVtOVNVR1pUV2tkS2NsUlhLMFI0VTFoYVNVSjROMDF3UW1SV1JIRlVaREJvWlVGWFZqVm9lRlF3ZW1KNlFtUnhLMnRtVVdkWGRYbFVMMVE0Y0hoT2FHTjZlRlZEZEN0RlNIYzJTelpDUkU0MmJETkhiVFY2VGlJc0ltMWhZeUk2SWpnelpXUmhZakExTVRZMk1UTmhabUk1TjJKbFkyRmpOMll4TjJGbFkyTTFNV1E0TUdKalpEQXlOekk1TVdZNVpXRTFZemswWm1RMVpUY3lNekl5WmpJaUxDSjBZV2NpT2lJaWZRPT0=',1782025562),('WZLRFvQTF3cDa0J0EtFuupZakidrVh5CT3ke4CoS',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36','ZXlKcGRpSTZJbTFFZUdOVldVeHBRVlJpU0V3MGJFWjFVa1JLU1djOVBTSXNJblpoYkhWbElqb2lhemxrUzI1T2Vtd3lhbWxhTTBWb05UaHphRTVwY1dwTmMybHJlRmg2WWxSVk9HMWplbXRzVG1Sd05FOXRlbE5pVlhjMGFsWTVNM2gzYkRGVFQzUlNaM2R5TWxwRGJVNXdNMnNyWVdwbE5YWkdVakZSUTNsVWVuVXpTa000YjFKR1RURmhkMGhQYTFSTmJpOXZTMlE0VEZkSVRrUnpiWGcwU1RFM1Vua3ZTM0UxZFdSb1FtMWlaWGhQT1dvM2NFNUpjVFl2V1ZCaGFDdEtWM0YzUTJGMmJUZDBLMkpXY3pCdVFWRklSemxPZWpaWmVHd3hZMkpLV1hWeGFVMW5lVTFVZWpnNFoyTndVa3hTVUhKaloyUjVZemw0UTNvdlNXbEdLekJwTmxrMlRucGpSM2hQVkUxcVpuSnpXazFuVlhJNVIyMXZNbFI0U2k5a09XdHlSR0pZWmlJc0ltMWhZeUk2SW1ZMU5ESm1ZbU15WVRCak56aGpORGxpWXpBMU5UTmxPR0psT1RkaVpEUXdNV0l3WmpOak5UWXhNREV4WTJGbU1XSXlNekUzTUdWaU5ETmpNakZrTkRZaUxDSjBZV2NpT2lJaWZRPT0=',1781980478),('xEcy3P038pU7Y7sIgOHOUUBV7mNAivKj59115I8u',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJa3hhTTJOM1pUQktNME5CYXpFd1YwaHJjM2h1YjFFOVBTSXNJblpoYkhWbElqb2lSRTlJYTJsdlZuWlJhaTlXVERoTGR6aEZNREZDUzBoVVVXWXdNMk5ITkVwbE9VSlZMeTlWV2pCRFoxSkNZekZTYmpJNE9WTXhiVGxRYmtSWFdXMU1iR0p0Y1Vsb1JYVnhkM294YldjMlYyNWphREJLT0dGaE9USXZVV2h0UzBwRmVXSkJjRkp6TTNRMFFXRk9ORlZQYUZWTE0yZE5iR1ZVUzJkcWNtbFhhbWxxT1RCd1VGQk9UREJ2U1hoQlRURkJjWGQ0UmxOWmJFdERTbFpNYTJoVWEyNHpaV016TldrNU4xbGtkbm94VlhCdFpqTndiR1pKY2paMGVURm9OV0ZhVDFJNU5VUkVVMjUwVkhKdWJrNUpLMFJWY1Rod2RHMDJibTlLY1ZwMWF6UktUVXRRTlZsd2RuWTVNRDBpTENKdFlXTWlPaUl5TnpNeE9ERXpaVFZsWXpBek56ZzJaR1ZrT0Rsak1URTFaR0l6TnpCaFpHSTVOVE14TjJFM016UmhNek5rTlRNellUbGlORGM1TUdVMVkyTmhNRFl3SWl3aWRHRm5Jam9pSW4wPQ==',1781980706),('xF889S8zY2effcibB5D7XOjfXrdMS9iCvuhTaEe5',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJa0ZHVjBReUt6SjNhMWRXV2tnNVlqbHNWVXRCUW1jOVBTSXNJblpoYkhWbElqb2lLM2Q1VEdGblVEUlVkMEl5T1ZCVUswcHlVazFwWWtWTkwzSnJTR0ZoVUhabU0xbEpjMDQ0VjNCb1NWbE9VRlJ5YnpSMlZ6ZE9iUzlyVVhkcVdYZG1XV3BPWTIxTldrYzVaRTlRWjBZek9ETmpOM3BZVmsxRVpqaHJMMDFXYlZKdVNWWktLM1ExVVZKTlpVSk5TbTl0Wmpndk9WWnVhSGx4VEhGaWVqWXpOVlZ5VEc5dU1rd3laVEF5TDFSblVUaElVbWRZUldvNFlqZEpkWGhPTkRCU1pFRkVSWE55V1ZGMk4wdzBZVkpSTm10VmVrYzFlazAyTUZneFJreFZjR0psU1RGblpEZHBUa3QxUzJaMU5tc3pVM2hCUmxwbVUwZHNhVkI1YkZoTk9YSXhlVXROSzB4T1VYUm5iejBpTENKdFlXTWlPaUl6TURWbVpqSTNNVFkxWmpjMFpUQXdNVEZpTVRkbU9URTNOV1UxTW1ObVltVm1ORFl3WkdFeE5qUmtOMkk0TnpCbE5USTVOakptWlRjek5ERXlaak00SWl3aWRHRm5Jam9pSW4wPQ==',1782159079),('XPo9pYlhrMUCb6iUpmbm0lGP10c9bIkh7fhSttIe',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJa1Z6YURkbmQwdzRWVlpIUnpReFRHZFZhakJhYjBFOVBTSXNJblpoYkhWbElqb2llRkF3VVZjMU1GSk1aWEZUVEN0NWNHNXVZa1I2U0dsR1lYRnJNVTVDY25kcFptSkZWVGxrT0ZadlIwbHJOazVZZDJSdlMxSXZObWRYUmxKamNEUnVOamxHY1RoVlRIcHdTRVp0Wm10eVIweHZTbFJqWVVwTVZHa3hTRUZpVGtKR1duWk1ibVJRTDFsdlFtNXdSR1ZzUjBsRmVWRmpiREI1TmpSVVFXNUZMMDh6TlhGa2VtaFJUQzlGWlVkSmEybzNSVVJRVlc5emNrZDVTbkkzYjFKS2FHOXJkWGt6UzNSNFNERlFibFV5UWsxd2QybENlbHBST1ROcVlXNDBjR1pJV0hoR2N6bGpSbU5SZEc1TFFrdHRaM2RaVTAxMlJHWnhUbmt2UlhkaVUyeFpRazVDVUZOVVRGbzBWVDBpTENKdFlXTWlPaUk0WkdKalltWmlZamc1TTJVeU5tSXhPR1F4TmpJMU1URTJaV000TldOaE4ySTRabUUxT1RObVl6QmxNRE15WWpVeU5EYzRNemswTkRkbU0yTXhaRGM0SWl3aWRHRm5Jam9pSW4wPQ==',1782109976),('xqp5z0ji0g2h1O1h0L8EmPzlN16UR5xDJp4pHhNo',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbHB5YlVzcmRqSTNTMFV4U1hWTlVETm5SbWxFY0ZFOVBTSXNJblpoYkhWbElqb2lTRVJCVkRSWFVYSXJRMU5hVHpFelluRTFSbE5GVFd4clZscDRiek00TDJsRlQxUkZla1kxUm01SlNuZHBjblJUYUhWMVprdHpWMloyWjNrNGRHdFFkM0pDTWpkSE5Gb3JXRWR4TjFrMmEzSldhUzh5TWxOWFZsQk5iWEJOU2sweVZsSkdNSGdyZVU1MmEzUnpWV2hZWkRkWGREQTFjMWxFYnpaUE9GVnhkMWRtSzJneFUzQTFXSG94TlZoeFNEUldNVVZzVGpkcVpYcEtjR1JVZEVvelRqRlRUMFEyWkdvd1FYSlhVbWN2YW5CUFFXaHhhMkZqZEVvd1EydzFhamc1TDFoWGQxTXJUalpNUlhWUWFGYzNiRFIxVFRSb1dESlJkSHBGUzFsUVNqSlVOVk5ZUzJwWU9EaFlRVDBpTENKdFlXTWlPaUk1TkRnd05qZzBNR0l4WW1Sa05HRm1aalF4TVRrMk1HTTVPV1V5TW1RMFl6STBOR001Wm1ZNE9XVTVaakJrWW1Ka05qTm1OalppT1RZMFlUYzNabVk1SWl3aWRHRm5Jam9pSW4wPQ==',1782159078),('YCoGaKtwBw8blDwu7bITO9Mf5nhAtu7JoncOkQR5',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJbXh4YVdWa2FtWkdlak40VkhsdFMzQnpUbk5xZDNjOVBTSXNJblpoYkhWbElqb2lLMVp1YzJsQlIxWnZOVFp1Ukdzck9TOW1jek0zYjNoNFVYbG9VRUYyWVhablRFcGlZVkZyV2xSRk5raEJZMnhyVnpORFpFNUdSbmRFYjBwcUx6YzFjamRXYTNsV1QwWTNaV0ozV0ZwS1NtNUJWMFJLT1d4TFEwNW5jRzlyUVVOdVJYWnRaSEJ3YUZGaVQyMTJTbkV6UVdSWmJqWlhTR2xKWW5SUVZHZFRaa0ZvYUZWQk4zZFFXVVZKZEZoWE1WVXJhRk41UVU5R1JFOTZTMEZ4S3pkbGJVRm1SV1pUYlhCS2F6QXlkM2xuTmk5R1ZuWTFiMmhUWVdselIyVjVPR2N2Y21jMFFqUlVWRVJDTDBNdmVrbzJPVEpuZW5aaWVsQnNNVXBFY1hKV2J5dFFhbHBrWTAxblVtUTRhejBpTENKdFlXTWlPaUk0TkRRd01EZGhNbUl4WWpFM09XSmhZMk5oTVRNeVl6Z3hZV1ZsWVRZeU5qbG1PV000TkRCbVlUazBPR0UxWXpJMk16WXhZelJpWWpJM01ERTFZMlEzSWl3aWRHRm5Jam9pSW4wPQ==',1781980705),('yhXrhkJjGSmGGOb9oIwRopK37NzUl0U9abBBvpvW',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 OPR/113.0.0.0','ZXlKcGRpSTZJbUoyTldOWFdrTnRTalI1VDJ3eU16UkdkVFZzWjBFOVBTSXNJblpoYkhWbElqb2lPVXBDZDNaNFZrMXFWRmR5YUVoT1pYaFRNVzVMTldneFdURjNVMFZMYUU1MlJuUmlTbFpsZUZOWVkydGFRbVZWVld0RWRub3ZZMHBJYjI1SGJ6SXlRWHB6TldKVFJUTlFZVUZXV1V0WlpXWnNSbE5DZGxselkyeHpaRnBXT1RnNVUybDNlVWhETDNkb05GTjVPVVJ2TVdFM1ZrUXZVM0pVWmpCa00xSjVPWFF3V0VOMVYybGlkVFZRVERWTk1qVllVSGQwY0M5aE1XeE9NM0Z1U0hoNWJ5ODRVbGd3ZG5oWU1FOHdVSEJMUzNwSFVuaHNPRWh1Y2s1M2NsVm9hVXBzYlhKd04wbGpObWhuWW5OSVIwcGtabEpyUldKNFZtbFVORTVHUm5OTkt6TTVUbmxDYW1VemRIcDRNa1p5V1dwaFYwZ3ZiRkZGVW5wT2VtY3JaelZ1TlNJc0ltMWhZeUk2SW1WbVpHTmpOREZqWkRBNE9EZzVZakF3WXpsa1lUbGlOV1F4WVdVMk1tVmxOalkxTjJRek5HWmtPRFE0TURJNE1qQTRaalkyWkRRMFlqSXdOakZsT0RjaUxDSjBZV2NpT2lJaWZRPT0=',1782114204),('YkZ1e8vDVgNXR81QlzzBQNy6trJOwgHeKmAp1sSd',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','ZXlKcGRpSTZJbmxITUV0TVptUTBkbk5aV2tneU9HRnplV3RIZUVFOVBTSXNJblpoYkhWbElqb2lOVTFSTUdnd05tOU5iMDE1VmxwUE5HWnZhREJYVURaSmExWnVaa1pEY1dvd1NYSjFXV2R0TTJrMVpsZ3lXRXhvU2pSNFNqVmthbXBNTkZkM1NrVnJRalU1VGxSeFRtZ3dNRXhMUWs1UWRqZGFSek5IYTBKUE5XUlNabk5EV25vNVZ6WnphMU5OTTNWdlRuZFlMemd6TlhsV2RETkdZV0pGY2poeFltaFZTakZLU1dVM1F6RTVVRlJQZHpkNFJXUnJabUpEYkZGbEswRnpjWGRVVUZaUFV6UjNlR3AwTTA5WVRWRkRWMHc1TkZVMmMwdHlOVmRwY0U5bGJ6ZGxabFV6VVZoWGVtcGphVmMxY0hCcVpFaFlkemxRUjBwa1MxUmliR1JDVlZOTlVuTnpaVU50S3pObmNqZG5TVDBpTENKdFlXTWlPaUppWmpaaE5UUmtNVGN5TXpNek1UZG1ZbVE1WVdaalpEQTJOR0ZrWkRjM09UaG1ZV1UyTVdNM1pUSmxZVGs0TkdReU1ERTVaR00wTnpZelpqazRNR1ZsSWl3aWRHRm5Jam9pSW4wPQ==',1782025562),('YwUPEtIS1ck8XfLiTb3sobBMluMoiC1KvGwzrgny',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36','ZXlKcGRpSTZJbmgyT1haSFdFWjRPVmMxVTBkWGExSmlaRXhXU0djOVBTSXNJblpoYkhWbElqb2lTMXB2Tm5Ga2FuSlhhVXRQYUVaVmVYTklXbk5vZDNOd1JFcEpjRkZaZWtNclZHaHZOMk5OVUM5V2RISnFSSEJLY0d4bFFVdHRTVU16ZDJKSVNXSkxTaXRMUTNscFlVMXBVVlZGZUc5MFZEY3hXVGR1T1ZGaFVWVTBUSEp2YUZOdWVrNVdWVU14ZDNCT2NuWklla2RFVGt4QlZ6SjNiMFJCWlZSVVQwSkZja3BVVkcxU2VVbHZRVFZFU21SMmRtWkJVVTFuTDI5a1FXSkVjM0ZNYUN0SllrdEhRMVJFWVhCTllXcHlSMlp2VTJOT1NXcGFlVzVWYlhOUGFFWnpkMlJxVldOR1FVdFBlVzFEYVRSM2VXdFdhV1F2WXpZMEwzcDZjVXR1VFc1eWNETlZUMUExU0dOeEwzbzRaVll5U25RMFdIUlhWakJxVFdOSVpteDZNbU0zU1NJc0ltMWhZeUk2SWpJd05qWTNPV0kyTnpsaE5qbGtaRFV4T0dJek16QXdZek0yWWpKa016STBPR0V6Tnpjd05UWmxZamN5WmpVNFkySTNPRGRpWm1FNFpqVmxNRGxoWXpraUxDSjBZV2NpT2lJaWZRPT0=',1782020018),('YXzeqjx10NXzfFDiMFEwTi9ImTwuxuGD7xoJMRwt',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJa3AyWkU1eVRqTmFVbVJwVTJkQkszbG1lSEJDYzBFOVBTSXNJblpoYkhWbElqb2lXakpTVVVveFJHZHJSVzVHVVhodVQwbDRkRGxvWjBWQ1pUaFFaMHQ2VUdObmRrOTBSVTVVZUU5TFQwZGtVbmcwV25WbWRUaHZRM1ZhVDJkellscEVUM2xtTTNnNVJFdFJLMGMxY0RFdlowNWFlVVU1VVdkTFoyaDRaa1F5VmxSQ2FIZDNUeTk0Y1c5S1pqQk5OMGhJYmxjNWNIUnlOaTlDYlRGUGMyNURkWFZoWmtWRFkwazBZVVJaVFVGd1kyOHlSVkJpUjBkR1psVmhVM3BvTHpKRFltVmFRVzlpUTNsRE4waHpkelpWUTBWcGVHZHNMM05VUTFoSllXZ3hZM0ZXVEZwdFlubHlXRkZtYjAxaFpGUjNWRkpKUVM5UmNIb3lZMGg1WTJKV2RuTjROMDlQV21adlVXaDZPVGRCVFRSeFNsbFlSMUp0YmtkeFRHMWxRV2hVV0NJc0ltMWhZeUk2SW1ReE5UQXdNVEF6WkdRMlltVTJabVl5WTJGbE1XRTFNRFJrWVdNd05XUmhaVE0yTW1FNE4yTm1aVGswTnpjNVpUUTJZbVF3TlRVd1l6SmxaVFppTXpVaUxDSjBZV2NpT2lJaWZRPT0=',1781980574),('ztug2j3ziC82acTntCSUeHeYhpn5xzE6niaej34a',NULL,'172.19.0.1','AdsBot-Google (+http://www.google.com/adsbot.html)','ZXlKcGRpSTZJaloxVGswdlJqbGFjMkZwVVU1b1QxaG1TWGMzWm1jOVBTSXNJblpoYkhWbElqb2lUak42Vmt4SFpqVjZMM1p6WTBzMU5XaGthRUZvUVdWbVJWYzJWa1puU0VJemJEQlFWSGNyTjFSM2NEaE1ka3RZV21saWVXWlFUR04zWjB0b2JqWnJaVmt5VFdONGJsVnpNM1pzVTNGTU4ySkxSVWh1VWxCQlFWVldiekIzYjA1VVdUTXlTalphTURrek5UVTBlVzUwWlRONVkwdFRjek5LVFVnd1pGTkVTbGh5U3l0bWNIbzFUbE51TDFSRVRGRkdRWEJMZGs5T2VFSm5VMHRVUXpoRlVWWkdiR3AwYjFCclkzZG1jamxoV2l0d1MweG1Oemx2VVRVMlFsWk9iRkJNUm5Kb1lUWlNTMngyVjNscGJDdGtVbVI2V2pSM1RtWkJibXh0U200dmJsSllabmsxTXpGVWVYaGpZV3RpTlZWMFlWUnNNbFpaZW1VMlJEQlhWMUZKT0NJc0ltMWhZeUk2SW1NNU5UaGpNR1JrTVdFek9UQmlNMlV3TnpZMlpHSTJPVFl3WlRVNU9UY3hPV1ZoTURRMU5URXdZV1EzTkRWbFpXVmhOakkxTURKa016ZGhNR1l5WkdZaUxDSjBZV2NpT2lJaWZRPT0=',1781980704);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `paypal_subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `current_period_end` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriptions_paypal_subscription_id_unique` (`paypal_subscription_id`),
  KEY `subscriptions_user_id_foreign` (`user_id`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,1,'pro','I-GR2USDDP0EK3','active','2026-07-06 10:00:00','2026-06-02 06:22:00','2026-06-06 09:49:48');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `synthesis_usage`
--

DROP TABLE IF EXISTS `synthesis_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `synthesis_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `synthesis_usage_user_id_period_type_period_key_unique` (`user_id`,`period_type`,`period_key`),
  CONSTRAINT `synthesis_usage_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `synthesis_usage`
--

LOCK TABLES `synthesis_usage` WRITE;
/*!40000 ALTER TABLE `synthesis_usage` DISABLE KEYS */;
INSERT INTO `synthesis_usage` VALUES (1,1,'month','2026-06',15,'2026-06-06 16:14:01','2026-06-10 04:48:17'),(16,2,'day','2026-06-12',3,'2026-06-12 09:15:22','2026-06-12 09:17:22');
/*!40000 ALTER TABLE `synthesis_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translation_usage`
--

DROP TABLE IF EXISTS `translation_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `translation_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translation_usage_user_id_period_type_period_key_unique` (`user_id`,`period_type`,`period_key`),
  CONSTRAINT `translation_usage_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translation_usage`
--

LOCK TABLES `translation_usage` WRITE;
/*!40000 ALTER TABLE `translation_usage` DISABLE KEYS */;
INSERT INTO `translation_usage` VALUES (1,1,'month','2026-06',5,'2026-06-10 04:27:51','2026-06-10 04:49:34');
/*!40000 ALTER TABLE `translation_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `plan_override` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_note` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_index` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Chathura','chathu.ad@gmail.com',NULL,'2026-06-06 06:59:54','super_admin',NULL,NULL,NULL,'$2y$12$PZhZrYH582onrcRyZOgLZeRLsbMVZvT.jq4nYfvlZVppE72uGU6Qm',NULL,'2026-05-24 07:43:19','2026-06-11 16:13:03'),(2,'Chathura','sriya@gmail.com',NULL,NULL,'user',NULL,NULL,NULL,'$2y$12$.SBlEUTK.1on0kILLVqW1Ox2EzWNF7xLROgmEC60RPz1srV0YUIhW',NULL,'2026-05-25 10:01:51','2026-05-25 10:01:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voice_profiles`
--

DROP TABLE IF EXISTS `voice_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voice_profiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `profile_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_key` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ready',
  `duration` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voice_profiles_user_id_profile_id_unique` (`user_id`,`profile_id`),
  UNIQUE KEY `voice_profiles_engine_key_unique` (`engine_key`),
  CONSTRAINT `voice_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voice_profiles`
--

LOCK TABLES `voice_profiles` WRITE;
/*!40000 ALTER TABLE `voice_profiles` DISABLE KEYS */;
INSERT INTO `voice_profiles` VALUES (6,1,'my-voice','fce9bfb6-9dfd-4e17-9ad4-10ea41712564','my-voice','ready',13.56,'2026-06-05 05:44:23','2026-06-05 05:44:23'),(7,1,'my-voice-2','c83ea104-f42a-413f-9c45-5a6097af5d53','my-voice-2','ready',13.78,'2026-06-10 03:47:29','2026-06-10 03:47:29'),(8,2,'my-voice','c8a8b2c4-4f67-4642-97fc-0ea7072de116','my-voice','ready',12.37,'2026-06-12 09:14:19','2026-06-12 09:14:19');
/*!40000 ALTER TABLE `voice_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'voice_saas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24  3:15:02
