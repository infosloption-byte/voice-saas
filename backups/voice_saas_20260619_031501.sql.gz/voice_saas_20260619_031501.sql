-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: voice_saas
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `project_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'task',
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('running','done','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `started_at` timestamp NOT NULL,
  `ended_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_logs_user_id_started_at_index` (`user_id`,`started_at`),
  KEY `activity_logs_user_id_project_id_index` (`user_id`,`project_id`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,1,'iidthvnj','synthesis','Synthesising \"News Report\"','Audio ready','done','2026-06-14 13:30:04','2026-06-14 13:30:15','2026-06-14 13:30:04','2026-06-14 13:30:15'),(2,1,'qo5ajmvm','synthesis','Synthesising \"YouTube Outro\"','Audio ready','done','2026-06-14 13:30:52','2026-06-14 13:31:09','2026-06-14 13:30:53','2026-06-14 13:31:09'),(3,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','F5','failed','2026-06-14 13:32:34','2026-06-14 14:13:25','2026-06-14 13:32:34','2026-06-14 14:13:25'),(4,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','1 scripts processed','done','2026-06-14 13:34:17','2026-06-14 13:34:20','2026-06-14 13:34:17','2026-06-14 13:34:21'),(5,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','Engine returned HTTP 500 — the model may have crashed or run out of memory.','failed','2026-06-14 13:34:38','2026-06-14 13:34:42','2026-06-14 13:34:39','2026-06-14 13:34:42'),(6,1,'qo5ajmvm','synthesis','Bulk synthesis complete: 1/1 succeeded',NULL,'done','2026-06-14 14:15:31','2026-06-14 14:15:34','2026-06-14 14:15:31','2026-06-14 14:15:34'),(7,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','1 scripts processed','done','2026-06-14 14:18:41','2026-06-14 14:18:46','2026-06-14 14:18:42','2026-06-14 14:18:46'),(10,1,'wcy0cecq','synthesis','Bulk synthesis: 3 scripts','Marked failed automatically — the task was interrupted (e.g. the page was closed) and never reported completion.','failed','2026-06-15 08:01:31','2026-06-15 09:15:01','2026-06-15 08:01:32','2026-06-15 09:15:01'),(11,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:98|scripts:3','done','2026-06-15 08:01:33','2026-06-15 08:01:53','2026-06-15 08:01:33','2026-06-15 08:01:53'),(12,1,'wcy0cecq','delete','Deleted script \"Podcast Intro\"','generated audio removed','done','2026-06-15 09:43:39','2026-06-15 09:43:40','2026-06-15 09:43:40','2026-06-15 09:43:41'),(13,1,'wcy0cecq','delete','Deleted script \"News Report\"','generated audio removed','done','2026-06-15 09:44:03','2026-06-15 09:44:04','2026-06-15 09:44:04','2026-06-15 09:44:04'),(14,1,'wcy0cecq','delete','Deleted script \"YouTube Outro\"','generated audio removed','done','2026-06-15 09:44:07','2026-06-15 09:44:08','2026-06-15 09:44:08','2026-06-15 09:44:09'),(15,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:94|scripts:3','done','2026-06-15 09:44:28','2026-06-15 09:44:48','2026-06-15 09:44:28','2026-06-15 09:44:48'),(16,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:38|scripts:1','done','2026-06-15 09:45:30','2026-06-15 09:45:38','2026-06-15 09:45:30','2026-06-15 09:45:38'),(17,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:94|scripts:3','done','2026-06-15 11:26:26','2026-06-15 11:26:44','2026-06-15 11:26:26','2026-06-15 11:26:44'),(18,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:38|scripts:1','done','2026-06-15 11:28:30','2026-06-15 11:28:40','2026-06-15 11:28:30','2026-06-15 11:28:40'),(19,1,'wcy0cecq','synthesis','Bulk synthesis complete: 2/2 succeeded','model:f5|words:56|scripts:2','done','2026-06-15 11:48:21','2026-06-15 11:48:33','2026-06-15 11:48:21','2026-06-15 11:48:33');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint unsigned DEFAULT NULL,
  `target_user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `after_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `admin_audit_log_actor_id_created_at_index` (`actor_id`,`created_at`),
  KEY `admin_audit_log_target_user_id_index` (`target_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,1,NULL,'setting.changed (gemini_api_key)','(empty)','(updated)','172.19.0.1',NULL,'2026-06-12 05:05:12');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `is_secret` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES (1,'gemini_api_key','eyJpdiI6ImRWZzZBR3htWTVQYXdsRkdFVGFZbUE9PSIsInZhbHVlIjoiMlBzUTZ2TitBNzNvdmxIMWFjejlkVkE5aUJQTHMxSldXd2V5dkxEamQ4elpoOTdWMFpTYWZUVlBGd3JEMzFjNCIsIm1hYyI6IjNkYzUyNTYwZTEwODU0YTRiNmFiMWU2N2NkZjMwMTdlYmExMDcwNmM3ZTEzMDhiMWUwN2FmNGU4MDUxMjNjNTQiLCJ0YWciOiIifQ==',1,'2026-06-12 05:05:12','2026-06-12 05:05:12');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('voxora-cache-356a192b7913b04c54574d18c28d46e6395428ab','i:1;',1781524161),('voxora-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer','i:1781524161;',1781524161),('voxora-cache-a7865b871c474506e0726a495e3cbe56b929c154','i:1;',1781762101),('voxora-cache-a7865b871c474506e0726a495e3cbe56b929c154:timer','i:1781762101;',1781762101),('voxora-cache-app_setting:discord_webhook_url','N;',1781838351),('voxora-cache-app_setting:gemini_api_key','s:39:\"AIzaSyDiZcExZumUpFukZHo5nhqJNkzHcU9gcRI\";',1781524543),('voxora-cache-app_setting:moderation_keywords','N;',1781505648),('voxora-cache-app_setting:paypal_plan_pro','N;',1781524544),('voxora-cache-app_setting:paypal_plan_starter','N;',1781524544),('voxora-cache-app_setting:slack_webhook_url','N;',1781838351),('voxora-cache-da4b9237bacccdf19c0760cab7aec4a8359010b0','i:7;',1781255849),('voxora-cache-da4b9237bacccdf19c0760cab7aec4a8359010b0:timer','i:1781255849;',1781255849),('voxora-cache-engine:active_url','s:25:\"http://34.59.245.242:8000\";',1781777548),('voxora-cache-guest_limits','a:6:{s:11:\"synth_limit\";i:5;s:13:\"preview_limit\";i:5;s:12:\"script_limit\";i:5;s:12:\"session_days\";i:7;s:10:\"word_limit\";i:500;s:13:\"profile_limit\";i:1;}',1781781118),('voxora-cache-heartbeat:queue','s:25:\"2026-06-19T03:10:55+00:00\";',1781925055),('voxora-cache-heartbeat:scheduler','s:25:\"2026-06-19T03:14:54+00:00\";',1781925294),('voxora-cache-synth_batch:1:19b4ab2b-8510-40ca-b1c9-e201aaa07c32','b:1;',1781174975),('voxora-cache-synth_batch:1:1d54d19f-9f32-4c31-a1f2-fe373bdae904','b:1;',1781447555),('voxora-cache-synth_batch:1:4de93186-0e4c-487f-9b55-6a0850674272','b:1;',1781447679),('voxora-cache-synth_batch:1:6820e42b-98db-40da-8c24-5f634893fe24','b:1;',1781338573),('voxora-cache-synth_batch:1:68dff763-9831-414c-8643-34f6ea9631fb','b:1;',1781447563),('voxora-cache-synth_batch:1:6f118756-65d1-4b8c-9f0f-d4dd3d9a3c7c','b:1;',1781447453),('voxora-cache-synth_batch:1:7eed9cbe-0960-4fa2-9348-0b6ba3ec1c51','b:1;',1781160913),('voxora-cache-synth_batch:1:81536a9d-48d9-4072-a8e5-517b89bc8372','b:1;',1781164766),('voxora-cache-synth_batch:1:aa4f3ce1-e537-4bf6-a1f3-15e38e18680d','b:1;',1781164739),('voxora-cache-synth_batch:1:b9463c72-11e7-41fc-b4fa-ebb3e43a95a9','b:1;',1781450323),('voxora-cache-synth_batch:1:dbfd552c-4466-4d93-a131-ae4815da925f','b:1;',1781338658),('voxora-cache-synth_batch:1:eeb626fe-ead1-49c5-8c8a-3bd0eb0b8c93','b:1;',1781446713),('voxora-cache-synth_batch:1:f21d5822-f253-4c6e-8ef5-ed8cc9240658','b:1;',1781447405),('voxora-cache-synth_batch:1:fede0ee5-b46d-4641-b819-367d4de3276a','b:1;',1781447658),('voxora-cache-synth_batch:2:6a6be2a5-d38d-4298-b5e8-27ffe9004ccf','b:1;',1781259389),('voxora-cache-synth_batch:2:d9cbf454-63b7-40ff-84e4-738c47b91b28','b:1;',1781259442),('voxora-cache-synth_job_owner:120d6e1f7839444ba3e9ff28bff73f7e','s:1:\"1\";',1781447679),('voxora-cache-synth_job_owner:172aac6866c04c9ab06204de1eb88e06','s:1:\"1\";',1781447564),('voxora-cache-synth_job_owner:227f98ce6b24471483ff866f67d3a9e9','s:1:\"1\";',1781164766),('voxora-cache-synth_job_owner:351766b61e9e48f2975874da51aa4de1','s:1:\"2\";',1781259389),('voxora-cache-synth_job_owner:35cec168c0b648528544a83b2189616c','s:1:\"1\";',1781450323),('voxora-cache-synth_job_owner:37c2f68f735f40839bccb0a28931db4a','s:1:\"1\";',1781160914),('voxora-cache-synth_job_owner:46b873633bd843f193ece4bace6dc8dd','s:1:\"1\";',1781174975),('voxora-cache-synth_job_owner:5aa06e9cc7c945b8b3568c87c1a29017','s:1:\"1\";',1781338574),('voxora-cache-synth_job_owner:5c949dc7a5b8446498bb82f9fbed920f','s:1:\"1\";',1781447453),('voxora-cache-synth_job_owner:6c93e4e4c9d046649478584f7a7afc0b','s:1:\"1\";',1781160881),('voxora-cache-synth_job_owner:7fb5ceeb310848f690adf16f61eb5139','s:1:\"2\";',1781259442),('voxora-cache-synth_job_owner:83582e0631d24ccea0d09337dbeaa60c','s:1:\"1\";',1781447405),('voxora-cache-synth_job_owner:8b509470a014458a8bcea2393fec5e0b','s:1:\"1\";',1781164739),('voxora-cache-synth_job_owner:957e5baf14a849b4b9fe1d7838223c81','s:1:\"2\";',1781259322),('voxora-cache-synth_job_owner:ca53db007a364e26b52f2977d30205cc','s:1:\"1\";',1781160827),('voxora-cache-synth_job_owner:cab0fd7b1f974a809cdfbccfbea15aa9','s:1:\"1\";',1781446713),('voxora-cache-synth_job_owner:d3039abfd53748fb963daa1b53469503','s:1:\"1\";',1781447658),('voxora-cache-synth_job_owner:ea60702620a84ad0a83c870cd388bc4b','s:1:\"1\";',1781338658),('voxora-cache-synth_job_owner:ecdc050bfd2748ebbcc7ea840ec21b83','s:1:\"1\";',1781160898),('voxora-cache-synth_job_owner:f3c5975ed5794715b500ea7bd718f173','s:1:\"1\";',1781447555);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine_configs`
--

DROP TABLE IF EXISTS `engine_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `engine_configs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `latency_ms` int DEFAULT NULL,
  `last_tested_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine_configs`
--

LOCK TABLES `engine_configs` WRITE;
/*!40000 ALTER TABLE `engine_configs` DISABLE KEYS */;
INSERT INTO `engine_configs` VALUES (1,'Local Server','http://ai-engine:8000',0,'online',3,'2026-06-13 07:15:49','2026-06-09 05:50:48','2026-06-13 07:15:49'),(2,'GCP Server','http://34.59.245.242:8000',1,'online',56,'2026-06-13 07:15:53','2026-06-09 16:30:54','2026-06-13 07:15:53');
/*!40000 ALTER TABLE `engine_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=2552 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_05_12_012958_create_projects_table',1),(5,'2026_05_12_012959_create_scripts_table',1),(6,'2026_05_12_013000_create_voice_profiles_table',1),(7,'2026_05_12_044441_create_personal_access_tokens_table',1),(8,'2026_05_12_100000_add_duration_to_voice_profiles_table',1),(9,'2026_05_22_000001_add_tone_to_scripts_table',1),(10,'2026_05_25_000001_add_bio_to_users_table',2),(11,'2026_05_26_000001_add_engine_key_to_voice_profiles',3),(12,'2026_05_26_000002_create_subscriptions_table',3),(13,'2026_05_26_000003_create_guest_limits_table',4),(14,'2026_06_05_000001_add_lane_config_to_projects_table',5),(15,'2026_06_06_000001_create_plan_limits_table',6),(16,'2026_06_06_000002_merge_guest_limits_into_plan_limits',6),(17,'2026_06_06_000003_guest_inherits_free_limits',6),(18,'2026_06_06_000004_add_synth_limit_to_plan_limits',6),(19,'2026_06_06_000005_create_synthesis_usage_table',6),(20,'2026_06_06_000006_add_advanced_params_to_scripts',6),(21,'2026_06_07_000001_add_translation_limits',7),(22,'2026_06_07_000002_create_translation_usage_table',7),(23,'2026_06_07_000003_add_engine_to_scripts',8),(24,'2026_06_09_000001_create_engine_configs_table',9),(25,'2026_06_11_000001_create_activity_logs_table',10),(26,'2026_06_11_100001_add_role_to_users_table',11),(27,'2026_06_11_100002_create_admin_audit_log_table',11),(28,'2026_06_11_200001_add_suspension_and_plan_override_to_users',12),(29,'2026_06_12_000001_create_app_settings_table',13),(30,'2026_06_12_000002_add_admin_note_to_users',13);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_limits`
--

DROP TABLE IF EXISTS `plan_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_limits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_limit` int unsigned DEFAULT '1',
  `profile_limit` int unsigned DEFAULT '1',
  `word_limit` int unsigned DEFAULT '500',
  `synth_limit` int unsigned DEFAULT NULL,
  `synth_period` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translate_limit` int unsigned DEFAULT NULL,
  `translate_period` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_limit` int unsigned DEFAULT NULL,
  `script_limit` int unsigned DEFAULT NULL,
  `session_days` int unsigned DEFAULT NULL,
  `multi_voice` tinyint(1) NOT NULL DEFAULT '0',
  `data_export` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_limits_plan_unique` (`plan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_limits`
--

LOCK TABLES `plan_limits` WRITE;
/*!40000 ALTER TABLE `plan_limits` DISABLE KEYS */;
INSERT INTO `plan_limits` VALUES (1,'free',1,1,500,3,'day',10,'month',NULL,NULL,NULL,0,0,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(2,'starter',10,5,5000,100,'month',50,'month',NULL,NULL,NULL,1,0,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(3,'pro',0,0,0,0,'month',0,'month',NULL,NULL,NULL,1,1,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(4,'guest',NULL,NULL,NULL,5,NULL,NULL,NULL,5,5,7,0,0,'2026-06-06 15:06:44','2026-06-06 15:06:45');
/*!40000 ALTER TABLE `plan_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emoji` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `timeline_clips` json DEFAULT NULL,
  `lane_config` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `projects_user_id_foreign` (`user_id`),
  CONSTRAINT `projects_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES ('bww8kv5w',2,'My Guest Project','🎬',NULL,'[]',NULL,'2026-05-27 14:14:17','2026-05-27 14:14:34'),('iidthvnj',1,'News','🎬',NULL,'[{\"ci\": 0, \"id\": \"tc_g50vztos\", \"dur\": 11.5, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 11.5, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"1j4xkyfr\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_1sg75nyr\", \"dur\": 16.2, \"lane\": 1, \"isGap\": false, \"start\": 0, \"title\": \"Podcast Intro\", \"rawDur\": 16.2, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"9j38a4p2\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-09 16:31:45','2026-06-11 15:52:33'),('qo5ajmvm',1,'Project 1','📹',NULL,'[{\"ci\": 0, \"id\": \"tc_cyq2jeil\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_2y0vm8au\", \"dur\": 17.4, \"lane\": 1, \"isGap\": false, \"start\": 10.1, \"title\": \"Podcast Intro\", \"rawDur\": 17.4, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"0whm6v9q\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_b02711em\", \"dur\": 13.9, \"lane\": 2, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 13.9, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"ixaifltr\", \"trimStart\": 0}, {\"ci\": 1, \"id\": \"tc_3nw3uqjd\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 15, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 2, \"id\": \"tc_yfhyuao6\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 30, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 3, \"id\": \"tc_bs79rsif\", \"dur\": 17.4, \"lane\": 0, \"isGap\": false, \"start\": 45, \"title\": \"Podcast Intro\", \"rawDur\": 17.4, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"0whm6v9q\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-05 05:45:53','2026-06-09 03:01:46'),('wcy0cecq',1,'Smple','📹',NULL,'[{\"ci\": 0, \"id\": \"tc_ijrj25u2\", \"dur\": 11.95, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"Product Demo\", \"rawDur\": 11.95, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"n0afspme\", \"trimStart\": 0}, {\"ci\": 1, \"id\": \"tc_b3ib802z\", \"dur\": 11.95, \"lane\": 1, \"isGap\": false, \"start\": 0, \"title\": \"Product Demo\", \"rawDur\": 11.95, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"n0afspme\", \"trimStart\": 0}, {\"ci\": 2, \"id\": \"tc_xj2e2or2\", \"dur\": 11.76, \"lane\": 2, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 11.76, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"xu7ibp0n\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-15 06:37:04','2026-06-15 11:49:06');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scripts`
--

DROP TABLE IF EXISTS `scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scripts` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `has_audio` tinyint(1) NOT NULL DEFAULT '0',
  `profile_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `duration` double DEFAULT NULL,
  `speed` double NOT NULL DEFAULT '1',
  `tone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'natural',
  `engine` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'xtts',
  `speaker_map` json DEFAULT NULL,
  `waveform_peaks` json DEFAULT NULL,
  `advanced_params` json DEFAULT NULL,
  `order_index` int NOT NULL DEFAULT '0',
  `audio_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scripts_project_id_foreign` (`project_id`),
  CONSTRAINT `scripts_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scripts`
--

LOCK TABLES `scripts` WRITE;
/*!40000 ALTER TABLE `scripts` DISABLE KEYS */;
INSERT INTO `scripts` VALUES ('0whm6v9q','qo5ajmvm','Podcast Intro','Welcome back to Voxora I\'m your host  voxora agent, and today we\'re diving into voice cloning. Whether you\'re a longtime listener or just joining us for the first time — you\'re in the right place. Let\'s get started.',1,'builtin:Claribel Dervla','en',15.3,1,'natural','xtts',NULL,'[1, 0.7649498033711534, 0.8000682807243477, 0.6057946042973764, 0.6429616940560209, 0.6889571802062933, 0.4658570160446355, 0.01326659431582514, 0, 0.8084577908907107, 0.8253341508206986, 0.819432282291315, 0.26338090547943754, 0, 0.7648522730988724, 0.6792788975856825, 0.6497902908470938, 0.3713296608053483, 0.008486977128579124, 0, 0.46946644648786623, 0.6764499953332289, 0.6126720138933446, 0.6004780604079435, 0.5975514848769445, 0.5685787017338365, 0.5136572412509006, 0.2886060187904511, 0.4163496773921682, 0.31460346126641964, 0.038239008109503904, 0, 0.8539395032019579, 0.8323091383577027, 0.7362208935775029, 0.6277436824360946, 0.6946152230549741, 0.46990538038188584, 0.22880694831210183, 0, 0.6336455509654781, 0.7380743977696361, 0.8419179199338434, 0.7802653929321156, 0.46263780202803856, 0.4614672004168919, 0.5127304653204565, 0.4983416516899384, 0, 0.4218125166900228, 0.7481709260446917, 0.6352357329562036, 0.4625261618043425, 0.27602187271279355, 0.12832894749010182, 0, 0.6269632972515816, 0.9110819463076308, 0.8377231648506619, 0.385523390056927]',NULL,0,'1/0whm6v9q.mp3','2026-06-05 05:46:00','2026-06-09 11:25:19'),('1j4xkyfr','iidthvnj','News Report','Breaking News. According to the Source details.This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'my-voice-2','en',11.5,1,'natural','f5',NULL,'[0.4284027863645301, 0.8100867368967286, 0.5919964486318516, 0.6322855749993412, 0.34891338168491337, 0.036660616806971386, 0, 0, 0.8522944027437968, 0.9539765390782252, 0.613670638982752, 0.44105473809673423, 0.7736346894883962, 0.43852732749411655, 0.3827326886005542, 0.1332082693972201, 0.10614143318583263, 0, 0.026600982023225785, 0.13606014521690304, 0.7958517202446228, 0.9939546673531564, 1, 0.6507129594531866, 0.571877806178813, 0.550410981673562, 0.22043040068432757, 0.03479388394911327, 0, 0.7856643916559065, 0.8992724965591053, 0.6566761971171485, 0.6998703710085116, 0.5970779760444813, 0.5679370442968311, 0.2633572591221715, 0.6636764160371029, 0.852709235786926, 0.655152423018217, 0.6156598206883411, 0.7691470331278594, 0.5995668729514261, 0.6608244768725258, 0.5251589703464814, 0.7963183947491643, 0.1827326886005542, 0.07715605749486652, 0.16696405405295836, 0.02473424916536767, 0, 0, 0.18863826974181636, 0.994058350275981, 0.9507907469832628, 0.7674642380065311, 0.6290189041434655, 0.8380088115281626, 0.22503851369567288, 0.14980554384378844, 0.1457565001996631]',NULL,0,'1/1j4xkyfr.mp3','2026-06-09 16:31:51','2026-06-14 13:30:15'),('68rfbvzf','qo5ajmvm','YouTube Outro','Thanks for watching! If you found this video helpful, please hit that like button and subscribe for more content like this. Drop your questions in the comments — I read every single one. See you in the next video!',1,'builtin:Claribel Dervla','en',13.3,1,'dramatic','f5',NULL,'[0.8135851824899027, 0.9043972501660572, 0.693772595890775, 0.887492642619719, 0, 0, 0, 0.5245175180792008, 0.6108576819410227, 0.9086743339343976, 0.687692219957256, 0.7852502365209907, 0.22409490537866547, 0, 0, 0, 0, 0.1879366158578641, 0.4510275152586643, 0.7527139452537258, 0.7463492266017393, 0.8117011756083511, 0.7251675352870608, 0.7938553110581948, 0.7395997943416894, 0.8441617781680925, 0.8044197826096909, 0.7692621042714706, 0.6465508541527871, 0.8147054350762072, 0.7256988491136409, 0, 0, 0, 0, 0.40902055627666895, 0.44732424246103647, 0.9313610412059076, 0.7995824730232707, 0.8131530452537856, 0.7614208337919773, 0.4897757544138808, 0, 0, 0, 0.7036803522067762, 0.7943887149082569, 0.9087529586272886, 0.7979796240625001, 0.7628697674520444, 0.07642721980896389, 0, 0, 0, 0.9962319862368968, 0.9190105948266544, 0.8963796215146619, 0.8939864451029456, 1, 0.79576350249718]',NULL,1,'1/68rfbvzf.mp3','2026-06-06 15:46:20','2026-06-14 13:32:44'),('9j38a4p2','iidthvnj','Podcast Intro','ようこそ、[ポッドキャスト名]へ！ホストの[名前]です。今日は、[テーマ]について深く掘り下げていきます。ベテランリスナーの方も、初めてお聴きになる方も、まさにぴったりの場所です。それでは、始めましょう。',1,'my-voice-2','ja',19.7,1,'cheerful','f5',NULL,'[0.7407458118922263, 0.6225014793440496, 0.8935482800139084, 0.7734372017227227, 0.44834497244179383, 0.409792585685147, 0.07367160066138627, 0, 0, 0.14838592862357416, 0.7022264873292592, 0.5256112745729303, 0.4249874893193095, 0.35883077398728896, 0.09871147331097802, 0, 0, 0.515639930550704, 0.4863179030933309, 0.3996266508513982, 0.41260300564264407, 0.5038929286864947, 0.7811319266964443, 0.39033831034302, 0.2793789629577946, 0.8220188692124586, 0.5819787994356554, 0.6635907998639066, 0.1964667906506346, 0, 0, 0.6307881644288352, 0.5659518231775145, 0.789670338335262, 0.7089412275231594, 0.8593088408483892, 0.8580339662199606, 0.8424623404704656, 0, 0, 0.8412785092448213, 0.7496244125898341, 0.5773346069323455, 0.16241446659201048, 0.8730403753017315, 0.7950189380067404, 0.6537358632423075, 0.5475740048034962, 0, 0.7485316247669739, 0.47315941699827496, 0.3600255517804236, 0.4330464769006512, 0, 0, 1, 0.6514137669906525, 0.7052530797455662, 0.39179531627525865, 0.5230615253160732]',NULL,1,'1/9j38a4p2.mp3','2026-06-10 03:49:29','2026-06-13 07:17:53'),('aw6cr5o7','wcy0cecq','YouTube Outro','Thanks for watching! If you found this video helpful, please hit that like button and subscribe for more content like this. Drop your questions in the comments — I read every single one. See you in the next video!',1,'my-voice','en',14.78,1,'natural','xtts',NULL,'[0, 0.0016, 0.0032, 1, 0.845, 1, 0.4948, 0.0081, 0.0038, 0.849, 0.8136, 1, 0.9098, 1, 0.7911, 0.6778, 0.2904, 0.8939, 0.8881, 1, 0.8516, 0.6906, 0.0735, 0.0067, 1, 0.9929, 0.9098, 0.9608, 0.6992, 1, 1, 0.6167, 0.4373, 0.182, 0.8609, 0.0027, 0.0103, 1, 1, 0.8988, 1, 0.6083, 0.6101, 0.8384, 0.005, 0.0041, 1, 1, 0.8155, 0.8951, 0.6083, 0.3468, 0.0191, 0.0039, 1, 0.9253, 1, 1, 1, 0.8802]',NULL,0,'1/script_aw6cr5o7.mp3','2026-06-15 09:44:14','2026-06-15 11:28:40'),('dzshzgie','qo5ajmvm','YouTube Outro','Merci d\'avoir regardé ! Si cette vidéo vous a été utile, n\'hésitez pas à laisser un j\'aime et à vous abonner pour plus de contenu comme celui-ci. Laissez vos questions dans les commentaires — je les lis toutes. À bientôt dans la prochaine vidéo !',1,'my-voice','fr',18,1,'natural','f5',NULL,'[0.9295141965072486, 0.922796595563596, 0.9085150508110716, 0.8378207632738891, 0.8256546621281625, 0, 0.7668637124344888, 0.8980419455629705, 0.7566021929026924, 0.7744276045488293, 0.7208146375753279, 0.4926060278097968, 0.817614456603113, 0.25130153905992253, 0.5746981840641682, 0.8876746073257561, 0.8682623803491304, 0.5132504973272376, 0.902009087278255, 0.6786565066924257, 0.6357912980114251, 0.4482275651162408, 0.5173606261158911, 0.4574840912664881, 0.2797672877626741, 0.40612358425479694, 0.2350100333915655, 0.06146335017989179, 0.31520763677106445, 0.6923883317999012, 0.4039548952808373, 0.40915104862873536, 0.2739932412502095, 0.3252578807537435, 0.4347923632289355, 0.3802168957785522, 0.93041337118338, 0.8432161214978635, 0.7789236330130788, 0.5946922846842648, 0.639969922053952, 0.7255002815801116, 0.6648832225709076, 0.7916711942460265, 0.8555677026216261, 0, 0.2601878031302693, 0.8784710163754834, 1, 0.5672929424661579, 0.6608304747119141, 0, 0.5173076909159164, 0.6245776686035229, 0.5171648589261413, 0.9028299964341112, 0.9100490343306484, 0.8321608841336353, 0.8964551302324817, 0.9305720733942412]',NULL,3,'1/dzshzgie.mp3','2026-06-07 05:33:22','2026-06-14 13:31:09'),('ixaifltr','qo5ajmvm','News Report','Breaking news. According to Source  details. This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'builtin:Andrew Chipper','es',10.68,1,'serious','xtts',NULL,'[0.8957316648469986, 0.4058827127176391, 0.3342249602325241, 0.1586629221699999, 0.07977643376005947, 0, 0.04399851280321026, 1, 0.3877754212123867, 0.09362429478441232, 0.5058203400036558, 0.5039336071544648, 0.16382470957270168, 0.17781494271820483, 0.6053355389690648, 0.3801573428945518, 0.2388236536758535, 0.14705776343721805, 0.1243102662606549, 0.043001781838977786, 0, 0.816952088167352, 0.846427718311631, 0.8377060451364418, 0.3392545778781852, 0.8779324099379132, 0.4177850533574076, 0.3930084251175003, 0, 0.7970168252552992, 0.6818701432658935, 0.25022248633752975, 0.06532141900150915, 0, 0.6564023983574907, 0.8871879807418331, 0.6841692499319321, 0.48770066301972304, 0.3306040864147372, 0.21166275120864528, 0.7917126396384442, 0.2764942436400393, 0.36410238782983384, 0.5471858905183524, 0.3655975168924361, 0.30152006005704696, 0.2785233573080482, 0.5103258014083124, 0.6653020606027038, 0.12238795125326084, 0, 0, 0.13345911668296842, 0.7498257857177201, 0.4957103451241467, 0.45899421980843, 0.5944252542971871, 0.4863123413154032, 0.28692462580372535, 0.14990108316577566]',NULL,2,'script_ixaifltr.wav','2026-06-06 16:44:29','2026-06-14 14:15:34'),('n0afspme','wcy0cecq','Product Demo','Today I want to show you [Product Name] — the easiest way to [solve problem]. In just [time], you\'ll be able to [key benefit]. Let me walk you through exactly how it works.',1,'my-voice','en',11.95,1,'natural','xtts',NULL,'[0, 0.0001, 0.0042, 0.4939, 1, 0.991, 0.8891, 1, 0.7568, 0.9036, 0.7343, 0.4847, 0.3574, 0.0122, 0.005, 0.0052, 0.0077, 0.6632, 0.5889, 0.7967, 0.5251, 0.9633, 0.3908, 0.5541, 0.4274, 0.4766, 0.1811, 0.0117, 0.0074, 0.6705, 1, 0.4789, 0.2159, 0.705, 1, 0.6151, 0.7444, 0.5863, 0.798, 0.573, 0.4583, 0.321, 0.9287, 0.701, 0.2354, 0, 0, 0.0024, 0.0831, 1, 1, 1, 0.8028, 0.6938, 1, 0.9179, 0.6497, 0.6373, 0.2899, 1]',NULL,1,'1/script_n0afspme.mp3','2026-06-15 09:44:18','2026-06-15 11:48:28'),('xu7ibp0n','wcy0cecq','News Report','Breaking: [Headline]. According to [Source], [details]. This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'my-voice','en',11.76,1,'natural','xtts',NULL,'[0, 0.0027, 0.003, 1, 0.5819, 0.4935, 0.306, 0.1761, 0.0127, 0.0046, 0.0042, 0.2789, 1, 0.9943, 0.561, 0.2508, 0.2693, 1, 0.7979, 0.444, 0.2373, 0.491, 0.5113, 0.1275, 0.3772, 0.0079, 0.0071, 0.7994, 0.7043, 1, 0.782, 0.2457, 0.1744, 0.2332, 0.4308, 0.0206, 0.0052, 0.7621, 1, 0.7278, 1, 0.6599, 0.8945, 0.7496, 0.6342, 0.7233, 0.731, 0.6006, 0.6678, 0.2923, 0.2293, 0.2418, 0.1675, 1, 1, 0.9123, 1, 0.909, 0.3776, 0.9438]',NULL,2,'1/script_xu7ibp0n.mp3','2026-06-15 09:44:21','2026-06-15 11:48:33');
/*!40000 ALTER TABLE `scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1c527VJ2OgbdbGbv5k7XOAuFe29eNMQnFdkhY5La',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJalUwVERSTEwxUlVkV2RtYmt4bWFrSmpiazF5UlVFOVBTSXNJblpoYkhWbElqb2lSVFJ5VWpjeVRYcFFWVGN4S3pCQmExZHJjSGQ0UW1nNWRuQTRjRk53VUdwbE1GQnpOMmxIYVhkVmVEVnNlRTFaS3prMFRGQkdibm92V25kUlFpOWtVR3N4SzJkalYzbDVUMnRoTDFkMGJsQTRLM3BHVVVwamJETkRabEE1UmpsdVRFZG1NMXBzUmxsemFXdHlXVlF2VVVSamVUWm9UazlaWXprMWRVbHFaWEJxYkhKTmNVdzNXV1pQYzNoVlJ6ZGtaak13SzNsSldXUk9PVkJ5TWsxWFZsRXlURVZMVjNGWWRFOXBiREI2UVc5Wk5YaG1ORkF3TWpOUGFXUXZSbUZwYWxWbGRUUm5ZM293TUdsTlpHRXhiRXhLSzFsdUx6QkZiVFJuVjFoak0zRjJUMlZTVEhaVFYzVk1NR2REUjBGVWVHbHJkbkZuYzB4YWFrMDFZMGhRTWlJc0ltMWhZeUk2SW1NME1XSTJOemc1WW1NME56YzRaakUzWmpaaU1qVTRaVEZsTVRWaU1URTNaamcyWkRFNE0yTTVPV1F3TUdabE9EbGlNVEZpWVdGbU9UQTFOelEzWVdRaUxDSjBZV2NpT2lJaWZRPT0=',1781587652),('1IBIP5MAgRWReCmmB4xjGerNMlwgEz8hvbM6xHAc',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','ZXlKcGRpSTZJbUZVZVM5c1ZXWTFlR2gyVEdwblUzaG9iSGwyVTNjOVBTSXNJblpoYkhWbElqb2llV2xhTXpkc1YwNWFla1p3VDFoa1FsbzFOM0p3ZG5SbVdFVnRjRUpVVWxsaE9FTnBOMXBWTkZCRFJVMVVWbmhrWjBSWk9VSlBMMHhxU1VkdFMxYzRNUzlrVFZKTlFUUlRibXRXYW00ek5sRnVVbkI2Y0VaSmVVbDVNVVpoYWtKdFJEQnBhMWhPY205SlNUUlVkSEJDVldkMWNEVnVTelF5YTAxWGEyeEphME5NVW1GQlZTdEVZbkoxYldSdlZFMUxTM2haZVhJNFFWaEdiRkI1SzB0SmJsUmhPVFpDZWpSUVNsZEdPRE5zTkhkMlJtUTJXakZKU21WS1RETnRNbVZUTm1acVlVUlZVWEI0YUN0ck1uSnVSR0ZPWlVKRmJFczBTbmxpUjBGYWVXUldOUzl6Y25OWWNUZ3ZZejBpTENKdFlXTWlPaUkwT1dWbU4yWTNOR0ZpWXpBeU5XSTBaR0UyTURRMU1tWmlPV1l6WVRVNFlXSTBOR1kwT0RoaU56WmtNVFE1T0RJMU1XUXdNbUpsT1RjME9XUTNNMk5oSWl3aWRHRm5Jam9pSW4wPQ==',1781582762),('2fjggWvIRqk4BF3sorb48qRaLf04HGtT7i9VktFj',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','ZXlKcGRpSTZJbU0yT1hCT1JFSlNjR3BuZVRaTmJIZDNhbWhxZDBFOVBTSXNJblpoYkhWbElqb2llbFV3Um1wTVEybFJkMmN3UlV4aGFFSk9hbXhXUldWR2N6RTNlSEJ1YjA4NE9XRnhhWEF3TnpOblVrVk5aelJhUm1nNU9GZEROM2huZUhKQ1oxTkJOMHRwTTB4NGNpOUtZa016YmxweFVVVjFXVGxKVkhaNGVrUlhXRXBGY2tOU1lUUjBaVTVCU25wMlJ6ZFdNbE5EVGtaUkszcFNTMU13UkhOMmRsQk1jM0k0YmpKcVZVMWlSakJOS3pWaWFUSjFMMDEyWkVjdmVuQmtOU3RJV1VadmVYUkhkbTFwVFVSQmRtWTBlSFpwU2l0UWVsVjJOalJEU2t3ME1uaEpORlE0U0VWaVNFdHZUbGwwTlVkelQyWnpVVTFyVm10VmFWTlBOa3RHY0ZWMVVUUnNSa29yYW1GbVNGUnBiejBpTENKdFlXTWlPaUl3T0dJd01XSXdNRGRoT1RBd05tVmlOV1F5WlRCaFpUazBNVGt5WTJWaU56aGhOakU0WkRka01tUTNNRGczTWpobVlXRTJNVFppTnpOaFkyUTVZMll3SWl3aWRHRm5Jam9pSW4wPQ==',1781731826),('5VoG3J6x3LpjKAVbSXyjEKozwfsaOqcUQanH2quT',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJblFyYjJwWk1HbE9jakJsTUhaUVZHOTRNSEZEYlVFOVBTSXNJblpoYkhWbElqb2lNbGRIY2tKT01ERkpURTVyTUdVek1scHFUMHMyWmpGeVExRnZOVEpsYmsxdmJGcDZiV3hNVUdwMFZrTmFSbkZKVURJd1FVRjJPR0pMTlhGV1VIcHNNa3d5TjAxTlpHdEJhRzlLYjBkVWJXUlpUMjgyTmk5WlZuZzRiRVIyZG5NdmNqWXJhWFU0VUZOdFJIZFpNbmxQTHpWUlZXazNhVnBDWWxoSWVFVkNVMkpJTUdneVNWUlhOVnBWTDBscVJWaHRRWGRzZDBkSVVuRnlkblpaVDNRMlpsbGtaVVE1WkZOUk0zWkpMMDlGTlVkUlZVTkVlbEYxTkROcFdETTRabWcyUW1VNFdsTTBZbWhHT1Zsek16Vm9SVFpIU0hsRGExZEpRakJVYjJvNE9HUXZjRkYzY0dWUmFtNVRZejBpTENKdFlXTWlPaUpoWWpVMk1EYzFPV1ZqTkRsbE1UVTVORGd5T1dJd09ETXlOelZpWXpnME1ETTJORGM0WVdWak5UbGpOMkl5TldabE4yWTVPR1ExTnpoak5ESmxNRGxrSWl3aWRHRm5Jam9pSW4wPQ==',1781587652),('6FEArbMhX8H4JuFvhR6YrDArINZPpGMuSBPl4Vev',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','ZXlKcGRpSTZJbGRPTW1aa1oydDFiSE5vWlhoQmN6UmtWV0YwVkVFOVBTSXNJblpoYkhWbElqb2lPRzlVUkRWS1JUVnJaMWxOWmxBMlVVZFRWbU5KY21kWWRHODBTWFZhY2paM05saDNjRVpqSzJKWGNFdzRMMUE1ZWk5SlVtdDBXbk5SVFV0eVZuaFBkR2RMVGpJNFlXUnRPV3N5YzNWeU9IRklMMWh2WlRGcmRFc3JWVFl4T1VoRGN6UkNheTk2UTFOblUxWlFSVzE1V1d0cFFrWnZXVmhJYUVaeFVGcDVWRWh6YVZkaFZrMWlVMHRUUkVKbmFISkZPR3hxWWpZeGRHeEVUbWhtWlZaSWFFVlRUM0JLUTFneGMwMDJhMVpTWkVSVFJXRlRNWGhXUzI1UlFWRm1TQ3NyYkdGRU9VbDBXV3RWUVUxdFZtTnFPSHBFTUhScU4wZzBjbVZqTWpoQmFUWklhM1ZrY1hOMlluVm1TVmhHUnpnNFNUaFJVRWR2YkhwclJHbFBObUkzWXlJc0ltMWhZeUk2SWpnM056RXpNRGhsTUdNek56TTBOR1U0WXpNMk1Ea3lPV1E1TUROalpUTTBZak5rTkRZd05HUTRZekEwTmpJeVpEUmtNV1kzTkRsbU4yWmtNelV6WlRraUxDSjBZV2NpT2lJaWZRPT0=',1781582813),('7uBlqoxmrQM7gdgsNMKyLFk6XshniGpCjezDV5cM',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbmg2VmpZNVREa3dkR1l5VTJ0clJWZFdkMkpIVkZFOVBTSXNJblpoYkhWbElqb2lTV0ZZVVV3MVlXcDJiV2s1TlRaMFF6bEJSbTFhVkVOd2REUkRaR3BrVEM4dmJUZEJNbm81ZGtKcFZFaE5Ra3hRVEZCYVEwNXBOM1UzUVM4eEt5czRXbEpVY0hsVFVYUmlOR05DY2tjMlprbFlka0ZQVTFKUVNGVmtPRXgzU1ZGdFdqRlJVVTlyUmxkd1pqZFNWRlpSUTJWbmVVOW9SM2RCYVV0cllTc3lSbWRVYmpWVk1FcENjQzlaYTNad1ZHMDViRWhpVlVSTmJYZDZTMmhIVFhOU1owbFBlRFo1ZEVseFZEaHRXa2RoYjBkSVpUZG1TeXMwTlZSRlpuaGljVE5qTW1WdmMyRktVRTl4Ynk5Vk5FTndTazFaTkhRemQybElSbkZaYkhoS056TXpVeTlITkV0WmNreEZPQzlWU1dSb2FYcExhSGxUVWxaMVNIUkhORmRsYkNJc0ltMWhZeUk2SW1abE16UmtNek0yTWpRMU1EVXdOVEpsTWpVMlltWXhZVFEzWlRCallXWmpPVEZqTXpCaFl6UTFNR1EyT0RWbVpEa3lNVEE0WkRnNU5qZGhOVEJoWWpVaUxDSjBZV2NpT2lJaWZRPT0=',1781668726),('AX5vfPTEczuMydlxp21VMCY79c7bw1zlTKqKO38i',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJblZDVkVwSWMxb3JlR01yUXpsdU1XMWllVko0TldjOVBTSXNJblpoYkhWbElqb2lUMUpSWlRkTFpHWlFabmRaVmtkaWJtRmpaalUyWW1oU1UwNHZWa3BUVVVReFpqSnVRa2h1UkdOTU9VSnNiVlZrVFhOM1owTXpUakJ4U1V4UVJteG1TVTVwWVhkWVlWRkVUVk53ZG0xSWVIUndPRFJvS3pCdlkwVTNiRVIwVFRsc2RXaFdaak50V0dFemVGSmpWVmN4SzBaV1FWQlNXbE40TURSWmN6bFVjamtyYlRaUFJGbEtaMVJFYWtKWGFtUTRRekZUVHpsS04wbEpURGx1Vm1sTVNHUmFlU3N6YVVFck0xSnhhaTlwVms5elpVc3liSGhyU0d0UVMyUklTVmN4ZFZsU1NFeGhLMkl4VjFSbVdrWnRXbmR2TjNsMVNGSnRTMnhVV0dGVWNWbFdhbWd5T0dKNlZrMW9XVDBpTENKdFlXTWlPaUl5TWpsa1lUWmpOelZoTURJMFpUY3lZV1JqTkdaaU9URmxaVGcyWkRFMU5UZGpNVFU0T0dGa05tWTNZekl6WVRNeVlUSmxaREUxTURFME16STVaR1U1SWl3aWRHRm5Jam9pSW4wPQ==',1781667638),('bOFsIxyZVqfroitEX700xlcaGhQphf4USpHKj5NS',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJblJ4V1dreWFFVnBZM1p4TUN0VFpsVXhOQ3RHWmxFOVBTSXNJblpoYkhWbElqb2lSeTlQUmtGU01ucHlReXRYYnpGbVVuTjVOSEpXU0dWamQxUlhkbVV6Y25adFRtdERTVEJ5SzBKTVRtSk9TVEpVVmpRNVZEZFdWa1oxZWpkRmVXSnZZak5HU0dwMk4zaFRiemwxYVhKeFVUVkxRVGc1YkhjelNqZ3ZUa1ZhZG5OUE9XdHljMko0ZFRSbVEzaGtWMEpMVTIxUWFrczVabEJNV1dodU1DOVdOVlpwYldSbU9WRlpTM1p6TDJoaU9HVkZlbUlyTWt3eVlWRlJNR3QwWTJGS1IycDZMekpqY0hRNFNVczNXR05xZUZCUlRrRnFTMDVSVWtwb2RIQXZSMjlITVZaNVVWQlNjamh4ZGxCUGEwdHJkbVZxTkRjMFFuZ3ZhekZPYkhaMVZWQm9jSEZPUlhsS1VWRnVORDBpTENKdFlXTWlPaUptTVRCall6QTRNVGs0WkROaE1XRmtaVGhpWkdGa056ZG1OVFUwTlRrME5UWmtPRFpqT0RWbE1URTBPV0UyTlROa05qVTBOV1E1TnpoaFpXWTJNbVUxSWl3aWRHRm5Jam9pSW4wPQ==',1781762031),('cCeJQabvJPSLhnqxF69DQzXdkVc9Yqj7c4t51IAE',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkZTUVhaSFkyaEphVXg1TjNjelEyeDZRelpaUm5jOVBTSXNJblpoYkhWbElqb2lhQ3RQUzBkSmVqSnVZblk0YW1GVVYzUm9PVlptYW1aaWVXdDViemczVlVwR2R6SndaSHBpTjBoSFptTnZVRlJsZW1kVUx6WmpWa0l6VW5wTVdXNUNUa0ZoUWpndmIwbEVTalJhVFM5RU9HRlRVVU56YzBRMVNVNW5iRlZxTWtsWVJTOHZNVWcxZG1WaVpsUndUblJzYjBFMmJIWkdWM1UyVkM4NWNYb3lUV0ZhVG10SVJYVlZObFp3UkRsaWRuQmFTREJMWVhkdE9ISTJZbmM0U0U5Q1dVaHBaRTh2Wm1vcmVuTkhORkpVTTJwWE5VNHhTSE5JU1dVMk9Ia3JZMjU1WTBodE1tbHhUMDFhUkVWa01YbEhPRVYxTlVkblVuSnBXbEZ0U0d0WmN6VnVTM3BFVTNobVQxRjRORDBpTENKdFlXTWlPaUl4TlRVMFlqVmlaRGRoT0RObVpqQm1ZbVJrWkdNMk5XTmhaV1F4Wm1ZM05HWmhOVFJrWm1SaU5tUTRNVEkxTWpRME9ERTJOMlV6TUdFNU1ETmhZVEZoSWl3aWRHRm5Jam9pSW4wPQ==',1781587652),('Ck56QiUEg1ZJ99LuFjGx8aKPxf2hr0hpFtftQRNp',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','ZXlKcGRpSTZJbVJTU2xWMWIzQm1XVEJvV0hBeGRFWjVSbVJqYzNjOVBTSXNJblpoYkhWbElqb2lhV3hKWW5aM2JEZFlWVEZ6UjBoWmJYaFdlRXQ2YjNOWFZUWlVabU4wWjNwUFpGaDRiVXB0VjI1alJrWkxSWGhVWjJ3eEx6RmhlV2d3Y2xkM1VqbFpNVlEwV1VGaFRFcHFlR3RLZEVGT2JFNTNaM1p1YkcxeVowcFVlRk54TkRkSFNUVldhMkZsYm01WFFtMXlka1F4UkhGV2JIRXdha1ZxUm5abUwyMHJSSGxVYTJ4U1IzWndPRkpzZG1KYWJqTkRhV0pFWW5kbllYUTFjV1Z5UWpGelJHVjRUVzlsYzBKRVJIZEdWVVJCY1VGRFdHRnBZVGt4YVRabVYwNHZUSG8zWjFOcU0wRnFkelpWU2xOblMwTnVVV3RWUlU4ck5FTnNXbTV0Ykc5bllVOTVUVXcwU20xWVNsazFVek5YUWs1R05tbEtkRkUxVFU1VWFHZFNOR2w1YXlJc0ltMWhZeUk2SWpoak5tUTFZV05pWm1KaE1qRTRZbVEyWm1Kak1EWTRPV0prWW1Vd01qQmhNbVl6TW1NNVltRm1NemhtWkRGbU1UVTVNemcxWlRZeE1ETmtNMk5qT0RRaUxDSjBZV2NpT2lJaWZRPT0=',1781582762),('D51M7eR2pX9wFUgHzEH4v17U6R0PZKWOfQHj7tY6',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/142.0.0.0 Safari/537.36','ZXlKcGRpSTZJbVIwWnpSQ05FTmtVekZ6THpaUGFGVlJNQzk0VldjOVBTSXNJblpoYkhWbElqb2lZVGN4U0dwRmFVbDZUVUpoUjFGd01taHVUQ3R5T1cxclQwcHBiRTVUWWk5RWJrRTNZbGt3Vm04MFEySlFNa2hLVmxsSU1IcFdWRkZYV1hNMVdFaEhVbTQxYmswck4wVjBaRUUyUVdOc1pEaFpZamR4Y2pOR2RXaHpLemRMTkdaSVRWVk5iRkI2VFZCWVprdEpSRVkyWnprMFNXMTVVMXA1V0RCSVIyTkVkRmxKVldaMFpYcHdUelUyVXpSemEwTk1ORVZLY0RkVmRrdEZPVkp0Y1ZkWEswbGFiM2xhWkVKUGJETlllSEk0VURCS05HZEJiR3huT0dkNGVGRkdkVk5zU2sxU0syUnBiWFpqUWtkSmNsSTNMMUpGYjFOemRIbGhjbTVpV0VKRVlXVk1ha3R3T0Zwc2JVOUNNM0J5YWtJMlpVNTBha2RNUkdGWGRWbHVOWFZMU2lJc0ltMWhZeUk2SWpJM1lUUTFPR1JtTXpjMU1XRmpZVGcyTVdNNVpHSmxPREU1TURrNU1qSTNNR0l4T0Rka016TXlZVGczTVRReFpUYzVNMkptWW1WaFl6RTFZekUzTnpBaUxDSjBZV2NpT2lJaWZRPT0=',1781579103),('ERg6sao8B2S4HOO8fEstCrBvw5RgMcCx4KwU8xxl',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','ZXlKcGRpSTZJbTFxVGtsNmF6ZGxWME5KUzFkUGIxSkRNWE54V0djOVBTSXNJblpoYkhWbElqb2lTV0k0ZW5vMGVFOVNRVk5ZTldVeWFGWlJRa3BDV2k5TlVFMWtLM1E1VkRSclQzaHJaRkl5ZW5obmNXeHRkVzFaYlhONlZYbDFVMEZ0U2pkc1lqWXdibTByY1U1eWJGTlVZWEo0ZGxGYVZGbGFNbkp0VDNjclIxTTRZVnBaYlRKVVZXOVVSMlUyUkdkekt6ZFVWSFF5TmtRdk1HSktWemt5V0d0cFJHa3pTME4yZFRka2EwNTVZV0YzYVROcVoyRTNlbU4zZGtwT01VRjRSV1V2V1d4RFJHOTJNV2RUWWtKQ01YVkdkR3RaVW0weWF6Rm9aRVFyU1dOVVRWbGtlak15TjB4dVZuYzVVVnBhUTIxNkszRnJVMjVFUzJoaGRYaG1TbmRPVm5KaWQwWkNTMkpaYzNOSFZrUk9TVDBpTENKdFlXTWlPaUpoTmpnNVpUZzNOalUzTW1WalkyVmpNVEE1WlRRMVpUTmtaalZoTjJZMll6UTJNelE1TVRFNU5HTTFOVEkwTmpNM1ptWTVZak5qWkRSak1EZ3habUZoSWl3aWRHRm5Jam9pSW4wPQ==',1781582762),('fGSVI1TePIPvj3kPZBKX5fRWSNUs0y5ZCGFmV5rA',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbGh0VVdWRVNVbHhTWHBDWVZSNmFuTm5lVmhMVW5jOVBTSXNJblpoYkhWbElqb2lXRkpIVERCWFNHOXNSbGhWWm1Zd1JGVTVWRlZ1ZEdKWFRUYzJSbWxsTWxOMGNtYzJPVE5hWkUxMVRDOWxTR3hvU1RKVFoyTkxUbUp0TTFkWmFVazVVVmhhYVhRMmNFcHRhRW95VUd0RGVrSTRNekZKYURCNFZtVnRZbFJUY0hkb0szVmpVM2hoTVhsMFZUQkhhbTk1WVZWWFYwd3pRMVU0Ukc1TVQxZDBRemsxTTIwMFZreG9aMGxuTldWWU16bG5TRnA0Y0ZwNVRsVm5NM0p1SzNCb2JWVmtWV3R4Y1dObVNXRnJTbkF6YVZST2VYZGFTR000U0U1VVdEQm9OVVF6U0U5NE5rMUtlbFpFV1hOUkszUllZVmhrWkUxclJqQkdVakZ6VkZGTlRYQlljazk2YVhSVGJVUkVTM2xoTUZsSlRtNVhPVGd5V1hOM01WRldVVEZzYlNJc0ltMWhZeUk2SW1RNFl6TmtPR0pqTkRZMVkyWmlORFF5TWpJeFpqTXdNREUwTkdKbE5EZzNNemN5WmpSbU1EUTNZbUl5Wm1KbE0yVmxPVGcxWVdFek9UazVObUpqT0RJaUxDSjBZV2NpT2lJaWZRPT0=',1781585577),('G68N3a7lAakOEltPn9IRQ5bm3j08W7Tgy2B2K8Od',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','ZXlKcGRpSTZJbFI0UlhGTE1GQldWRXhYYjAxRGIybHlaR1owTDNjOVBTSXNJblpoYkhWbElqb2lXamh0YkVKNGJXeFhLM0JwUVhCSmFsUk5aWGMwVm1SUmRVRlhPVWw2ZDBZMWVtbFZTRVpSUlU5U1Z6WlNWR00zVkVWaFEyMTZPR0ZTVVdKdlFsTXJkSE4yWXpOemRqSjJNekJxVmtreWVtaEVLM3BKSzBFMU1tOVRaek5pYTB4SlFYbDZUa2hXTDJoTVNWRkZia3hMVEhsb1dXZEhUUzlhVHpWaU1XUTVjbWRaVGpSYVFtZ3JaeTk1TTJGdFdFSlhVMm9yWjJSSFpWYzJORTEwWTBsdGVtSlpMMDh4WkRJNWFIQnBia05rVUZkdEx6TnFjblU1VERVMFVuSlBSM1pTUWs5aU5EbHdOMnhPVVZsUGRHbzFSWEl5TmpscGJrTm1NSHBxSzNsTFVqWXpiRGt5YWtWeGRDOVdSVDBpTENKdFlXTWlPaUl3T1RFM1l6RTNNelV5TW1Ga016Sm1Oekl5TUdFM1kySTNOemN6TjJJM1pHSXdOemhoTmpVMFkyRTRZekE0WmprMk1HUmlNV0ZpWVdaaFpqRTNOV1kzSWl3aWRHRm5Jam9pSW4wPQ==',1781582813),('h6PwWJqkleNAvQhjzFr85IqrrGAfcd6YpK03JWoq',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkF2T0RVcmRrVkNUMVF3SzNOU2RuRjNZbVpvVVZFOVBTSXNJblpoYkhWbElqb2ljbXh3YkZwek9XZHBSRWxQTDJGRmIwbFhjMVpSTmxadVYwdDVTV1ZxZG5oRFNXMXlTQzgxZVZCV2NFUjJZMnBaYTJscFZuRnlhemRtYW10V1RXaHNWbXB3VkhaRFFsbE5Za0ZPZWxWSUswWjBlblZKY0hRek5UWTBWbFozVTFWb09GcGlNVXRhVUdkSU1ITnhhVzVPZFVsUmEzWk5ZVGw1WTNJM2NuVkJPU3RGYmpscVVUaElLMlZLUVdRNU1rZERNR05TY1ZCMWFUUmhSM2QyVTFocVYwSlNiMmwyYW1WV1RIQkdaMFV3ZFc1MlExWnBiRGhNV0VneE1FcERaMjFVZERGUFZGbFNWWGhrZFRBME9VNTFTM2xaZDFWa1ZEbG5RMWcxWXl0UlkxUTJabVkzVERsb1dXZFlZejBpTENKdFlXTWlPaUl6TW1WaVlqRTNZMk5sTXpsaFkyVmlObVEwWmpZNE4yWTJZV1pqTURZek1XUTBaVEJpWkRCbE9EZzNNV1V5TWpBME5EbGpaVEF6TURjNU16WXpZVFkzSWl3aWRHRm5Jam9pSW4wPQ==',1781582813),('hf0KRCPxU0SX2ApG5I3bz5wibf5b3KqGU4CpGF5M',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/142.0.0.0 Safari/537.36','ZXlKcGRpSTZJbFpMWjJkNFlWZFpja2RLTjNKSUwxQkNRbTF3U21jOVBTSXNJblpoYkhWbElqb2laM0ZuTjNkVWNYVTBjVmRaYVVkMk1qRjJRVFF6TVc0MmRreFNhVlJFWml0UEswMUtkRkpMWlV4SWRtcHZhV05xYVZwM2NUQklURFF5T1hsVlZUQldhemRNU0daQ1VHVlhUSE5MVkhWWlUzQndOVUpISzFoblEwZEJVREZxV1RGWmJVZG1hMlo2VjAxUVltSnlSbEZPUzJGdFVUSkhSVmRwU0RoTFRFSXlhakJUTTFsWGVFWXpjVGRpV0d4TGJYSnljelJUZWpOSlFqUXpSSE53YTFkeFJIbE1kRUpKYkhaWWMwZ3hWRWhLYVZFNFdqVXphVVpPZWpGUVNXdDBlbkkzVmpaWWR6bEZVWG8xV1RGWmFYUmhlVkpWVWtOTEwzZFBjRU5JUTA4NFJFc3hXVmRXZFdNdlVHRlVWVDBpTENKdFlXTWlPaUl6T0RjMk5ERmhZV1E1TXpOaU9EUXlZMkV6TTJVeVlqUTBPVGRoTW1SbU1EUmlZVGxpTkRVMVpXUm1OMlUyTmpBNFlXRXlOVEZtWkRkbE1UQmtaRGsxSWl3aWRHRm5Jam9pSW4wPQ==',1781579103),('hWq1lb7WNUXqRpDtrGSi29KAaZowOczI6n75Y7G1',NULL,'172.19.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1','ZXlKcGRpSTZJaXRtY0ROVFYzZ3JaQ3RoY2xwRGF6TllhVEYyVkVFOVBTSXNJblpoYkhWbElqb2laV3hSY1U5WWJEWXdjak54VWxWQ1VucHlXVlJIYTFOaVpXeE1UVXRuUW5NclpUZEVjRGt4YVdOaFJIbHJURmxaVlVORVpHdG5XVWR5WXpGRlJHNTJiREV2WWtwUFUwNWxPRkptVEVKbmRGcHNRWE5PTlRNM2MyNXdWRzlsYjBWQ2NrMW9iRFpUVFhCUE0xbE5WalJqTXpNMWNUbEhLM05QYXpOaloyWmlSbTVqVlc1WWNXOVdlVFpCUzFkMGF6aHpNVzVOWlRCVE4wSlVSVTloWmtFclpFdDZOblF4VEhGQlpTOVdObmRhUkU5WVpFUmpZa2RYUXpkaFowWk9WSFo2YWxKM1RtNDRXbWwxUkVwdmVIQkhjakZ0Y3pKTU56azRhMHBsY2xack9IVkNkVkpCT0Vvd1dHVnpXVDBpTENKdFlXTWlPaUkzTXpFME5XTmxPRGszWlRjek56UmtaV1JtWldJNFlUYzJZVEppWmpVeVpERm1aamt4WTJGbVlUQTBZMlUyTlRWa01HRTNNakJsTm1ZMFpqaGtPRFkySWl3aWRHRm5Jam9pSW4wPQ==',1781580383),('i8Caebk9SXIRJOun3NuYuMPQHiw6qYqrhvHRVYD9',1,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbXhqWTFVME5VUk1WREJGWlhwNVdtWlRjRXA1YUhjOVBTSXNJblpoYkhWbElqb2lZMjlHYlc5WU9XSTVhMHhIVEcxa1ZXVTJhSFV3UjNadVNGWkJZV1ZLTkZCdE1GWlRiMGRHZVc0ek5EaG9kRFJ4ZW5Sa05VcG1lRXByU1M5VFZsWTNWVVZGTVM5UmEyaENaVVJxYmsxc05XMTVWU3RzTkRGM1IyVnZhVXQ2T1VWRFVEZHZTWFJvYm5STVdESkdXV2g1TjFneFlrbHNVV0prY1RrcmNtSkNlU3Q0WTFkS1pqaGpUamhhYTFKeFRWcGpNbU13YjFGSlNYVXlUa2hhWjBJMmNrcGxkakJqVjBkMWJVY3pOR2R0VWpGbkt6VjFibmN3TDBnNGVYTlROWEUzVVhGSGNXbDVhVTlTYmtSc1lXZG5aa016Umtkb1ZVbFBSelIxTVdFd2VqbERUMWRPYldoSlZVd3liRWxTU2taU2VXVnNOamhWYUdGRlUwcFVZMjVMYVV0WE1tNXVkRWxsT1VONFFpdEpSRmRLY1c4MFNFNVJXRGw2ZEdSVlJXbDNiV0pYWkRsTWQyWmlibTAzV1N0aVRrWjVjREJKWjFFMFRHNVNRM0p6Tld4MVF6aERTR2MyTDBKMFVTOHlkMVpXUm1WSVpEVlVRVE16UjA1aWVXbFhLMDR3T0VOVWNsVlFhbXBoTjJZdk9YTXJSQzg1TkZKeWJVSnRkSFZqTVdKdGFEWlVaa2RVZHpKbFMydEZlbEpTTmtKek5ISldSWFZrYXpGUVpUVm5VamwzYW1WdU5sWTBaMk42VkRoTVdFVlphbmhwYVVwbk9GRjRRMFk0YjNwV2RTSXNJbTFoWXlJNkltUXdaR05rWXpCa05UVmtaVFV6WVRFMVptSTFaREV5WldVNFltSmhZemhqTjJKaE1qWTNNVGRtTWpCa1lqY3lNRGswWWpWbU5XTm1NbUpoWVdRMk1tWWlMQ0owWVdjaU9pSWlmUT09',1781762057),('jMxQgfdtjfvhX78Io04XyHEEgRMosUhUlLPCXLDd',NULL,'172.19.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1','ZXlKcGRpSTZJak42Y21WYVkxcHRXbmR6VEVweFNTdHBTbGxuTUZFOVBTSXNJblpoYkhWbElqb2laemxZUVRGcFdtaEJWSFJoYWtaUmNtZGtZbEYwVVZrME9ESnJTa0pwYW5oclRubEJUMGRuVkdsaWMxQTFVbTFWZHpsdU9WVmFXRmN6TW1SMlVVRkZRbkp5Wm5sQ1FXMXdiMUYzV214aVJUaHdPSGRHT1RWV05uRnBPQzlXTjBSemFsSmhPVXQ0WVhkbVdscFFaMGRIYmxKSWMyRlZNRVZsY1ZFMlJtbDRTRzVETHpsRGFFMXdkRUpHY3pKeGJtTndWVnB6U0RaSFVYUkJkMjFsSzFoRWEyTmphbFpMTjNoa1ZtcE5hR2N4YmtKdFMwVm1jR2RDZVhndlNHdDBjRkJHWnpkQkwyNWFVa3ROVVhKRldWTlNPRmx0VGxFMWRYSlhaa0pEYUc5VlRYWkdhRVJQTVU5MmFqRlljejBpTENKdFlXTWlPaUl3TTJZNVpEazFOVGs0T0dSbE1qZzJNekUxTVRGbE5EQmlNMlJpTURFek1tWXdORGhoWXpNek5qY3pOVFkyTVRGaVkySTBOemMxTXpRNVlUSXdZakpqSWl3aWRHRm5Jam9pSW4wPQ==',1781580383),('KBpkDEb8szQLBRWDiJmHxBUieo1zou7K8no9Wqul',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJamw1UW05d09GTk9OMDFJVTNsTllVOHZXamhOZWtFOVBTSXNJblpoYkhWbElqb2lRMFk1TVVWQ04yUTJhR3BEUXpaTWJVaFRVVGxHU0dkd2JEQjBVa0ZFU1hjelUyOTJNMnBGVTI1Q2RtaFJRM3B2T0NzM1VFOW1TVTFKUjB0eE9FWk1iMm93ZGpWMmVEWjFjMGN3YmpZclJHcHdSRU5aUVVOMWIyZ3ZUVXhqVjJ4T05sTjVUMVJTUjJ4TFIwWkpTREJZUnk5U2NIVkVkVUZHTXpaR05XWm5NR1ZpYURRNGRVSXhkeTlJWTA5bmEyZHRZbEJtVHpOaFYzUm5NRTlUVVhoMUx6RjVTalZqWmpoNGRrODVjMUJGY0ZWamNrWkplamt5TDAxdmJqVnpSalZMYUhwb2NDODFVMUpLVG5WaldVVkVSMlJTYkVSemRqbFVObXhTVnpZMlJ6SnRSVzVsY1ZCeGN6QTVUVDBpTENKdFlXTWlPaUpoTW1aaVlUYzJOR0UxWkdaaE0yTTJNV0V3T1RRME5EQm1ZbVUyTkRrd01HVTNaV0ZsTlRKbU5HTmtOVGRoTXpsaE1qUXhaVFl3WldJeE5XRTNObUV5SWl3aWRHRm5Jam9pSW4wPQ==',1781580864),('KwqVP9NgP6RWw5utSiFWBUVHiGAUwu8vi4aVQWLS',NULL,'172.19.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1','ZXlKcGRpSTZJbkZPYm5oTVNFTjJPVU5RZEdGQmRuRjRZVFJ5VDNjOVBTSXNJblpoYkhWbElqb2ljRVV5UjNBNFMxQk9WVVlyT1RKdmRrUTNjVXhzYlVsR1FVOUZVMk5vUkVGcGVIcGxXSEJPVUVWRFEydHJZM2MwTjBsU05tWjJWVWt5UlUxYVNqTTBUMVJ2Vmt4Wk0wdExRbmRSV25KcFVYbFVPR2hqT1hKTlFVOXdWa3h2VldscVdsa3ZPSGRIWW1sdGQydHBTbTF3SzB4cWJrbDRkVEpKTkhaUVJtaHJlRkZsYzJwTmNWSkhZMnBZVDJwbFVtaElVbkFyU2sxMldreFFRVzF4Tm10MmNWZEdkMVZDVlROaFJFVm5kRU54WVRVMlZuYzVVR3BuV0VGdFZYVkhUblZ0VUhvM2NGSmFUR04wVDI1WVRsRXJOak5RYUVwaFppOVBRVXRsVkdGMWJWTk9kbnBMYlRWVU4xbFBUa2MySzFabVVGTTBRMGRwUW14UFZHdFZkME4wTWlJc0ltMWhZeUk2SWpaa056VmhNems1T0RBMU56aGlaRFkyTkRjellqQTFaRFppWWpjME9UVmtObVZoTkRJME9EVmpOR1F5T1RJMFkyWmtNVGd6WW1NME1qa3dPREkyWVRBaUxDSjBZV2NpT2lJaWZRPT0=',1781580383),('ONyUkqKd3WbAHDPW5GXw9lLK4T0fF1mZEG1Y0jI9',NULL,'172.19.0.1','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Googlebot/2.1; +http://www.google.com/bot.html) Chrome/148.0.7778.96 Safari/537.36','ZXlKcGRpSTZJbWRZUzNJd1FsQktObVZCTm5kR1lrZzBjRzVoWVdjOVBTSXNJblpoYkhWbElqb2lNVUo2VlRGcFltMXBjbXBYVUhCM2RYY3lRMGtyVVdWbVNXSjFWVFpoTkZoc1NGZ3lSVVl3ZFZSdVRHaFNRMjlFUkRFNFIzUktlVFJrZDIxMmIzbGpiVXhIZDJOaVRsQm5XRk4wYVRZelpXOU9WR3hQUW1waVNqQXlibGxQTVZKSGNWY3ZSWGMzVTJ4NEwyaEljWFJXWmpkVmQzRkJOVkpHWWxWek5FOXZSVlJ6YVU5M1RIaDFaM05ETkcxYWREYzJOSG94WXpGSlVtWnVaRUp5Tm01U09GWk9aME5YUTNwR01VTmFUVkZrZDBKb1NFbDRaMkZRYkhCamNrSjFlbEZCTURVd2MwRmFXQ3RXUVRGdlFVVTVUemwwWjFFNVVFVlRVa3RoTWpaRGMwOVliVmM1VTNaU1kwSkNPRDBpTENKdFlXTWlPaUl5TWpSak9XTmpOV0l6WVRJeFl6aGxZall6T0daalkyTXlOREZpTlRoaU16SmlPV1EyTVdSbFpEQmlaRFV3WVdJeE9UQTNORGxrTkdZek4yWmhNREEzSWl3aWRHRm5Jam9pSW4wPQ==',1781731828),('oTTvnGyJNETAFMVmnMyPqWHRXyZ1wW0ehf01akSw',NULL,'172.19.0.1','Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)','ZXlKcGRpSTZJbkpzVGpKUmRVdzVaVmhHVTJzNFZXWkdUVU5RUjJjOVBTSXNJblpoYkhWbElqb2lUVU5yVW1seFNtZEpRMnMyVUVORVdYcEdZMWhtZURSVk5XbDBaU3ROUldoclZsUnhOMnBJV21vNGNqUTNaVkZSWkRWMVIwRmxTRXdyUkhWa2NWbHpLMDV3YWpkMWFXMXlWMmhXVkRkTlRYWnpaV2xJTWpWTVZEZHdSbUV2TjNaQ2FISmtjR2RsYzBGbFlVSk1RWEpHVGpNMFdXMDNkV1lyWkN0cFJtbzRhVWhuTUVGWlNWRktPQ3N5TlZSVlYxZzNjU3RRVkRjMVJqbGlXbVY0U2t4eFkzWXdOM1U1Ymtwc1UzQmtWV3RsTVRsakwySnJUM05FTkZOcFV6QlRSRWxyU0doSU5WRnRja3RWU21kb1FsZENPVU5pUjI1TWFVTlJUM1JRZDNseGVYSkZiMlJaY1ZsQmJVVmtRVDBpTENKdFlXTWlPaUptTURVMU9EQXlOakV3WXpRNE16azJaamczTXprd09UQXlNREJqWW1Fek56Rm1aV0kzWmpOaFpXVmxaV0kzTURaaFpESXpOMlExT1dJNE56azBabVZtSWl3aWRHRm5Jam9pSW4wPQ==',1781777518),('pHgJkeEKzzoXhnXLhMCTca2hLyXIE6kdeGKfWKs4',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','ZXlKcGRpSTZJbkZXVG05dFZqZFhibU53T1RGeGFWSXZhMnhIWkdjOVBTSXNJblpoYkhWbElqb2lObmxhTW5jNGVISlJXbWwyVGtWU2FUWkNPR2RGTmk5UllsaGFlVzlUV0dReE9HZDRkMXBIUnpocmNqVk5WbEJzSzJaRVl6QkpVRE5PT1hZNFpVRnRUV0UwYjFkTFJXRmpZa055UWk5dlpFVmxaVkZ6YTFCUlZURmpUV3hZZDBKd1ZGRmlRV2d6U21SR1ZEbEVUMGcyVTI5aGFWQkpXVVZ1WmtoVGMwczJRMWQwYlZwNE1VNU1TamhDYUc1RWJEaFNSM0J3ZFRCSGFFb3JhVTVrY25Gc1VGUTNjbEJaUTFsNlkzaFBiRXdyWTNoNFZ5OHdWR3BHWm5wek56WnJRMFJJUWpZMFJ6TXpVM05ZU3pSYVdVTkhTRGx4U2xaVGRrVkVkMkZPVjFvM05TdGFPR3g1UmtzclEwSlFWVDBpTENKdFlXTWlPaUkyTlRrNE1qZG1NMlptWTJJNU1XVTNPV1poTjJVeE9EVXpaVGt4TjJZNE5XSTFZekkzTlRVd1pHUTNNVGc1TkRBNFpqSTVOV05qWWpZelptTmlNR001SWl3aWRHRm5Jam9pSW4wPQ==',1781731826),('Q1iLnL8O8VwprXOwKOPPmmRz2TF7KOUTQiHx7CeE',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJa1I2TUV4SksweDRWVkVyY2xjME5WQTBhaTlKVTJjOVBTSXNJblpoYkhWbElqb2lSMEpFYW5KaFMzaExkbXhtTTFreVJsSlBOSFJRU1dwc1JIVkROMko0UkROeFkxbHdWMnBOZDBvcldtSjZTbVJqU2l0a1FVaFpSWFJtWm5kUE1tZEVRbFJNVlZaM01USm5abkJsZUU1S2FrNXdZVEZtWjA5ME0wMTNTbEp0VUZWbGMzSmllakZZYUZCWlkySmpUM2xzUlVKUlVEWndTMnhJUWtWRk16aDRWR2hZT1dkQ01IVnZjVEZ4ZVRKRGIwaHZZVmxSVWxocGNGTklkMUZyU2psVFRpdE5SVEpuUkhKalZtUXlhVFoxTmxvMVIyYzVWVUk0ZEZGd1RsUk9PSGRyVURoclQxUnJRVlpvU2tKMWRUbEZSRlJsTlRGRFVXUjVURkpEY0dGaWVWaHVWamxHTDNKWlNUUm1aejBpTENKdFlXTWlPaUpoTW1KbU9UTmhZVEpoTnpGbE1XTmxNamd6TmpZNFlqUXdORFU1WVRJM01qQmxZbU13T1RCaU1XVTJaVGhsWW1Oak5tUTRPV0prTW1NNU56Z3dNamN6SWl3aWRHRm5Jam9pSW4wPQ==',1781790658),('t8NcFeBZagNkQtz0zkOaY6S8meNak4ascdJ25hll',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','ZXlKcGRpSTZJa3B3Tld4c09TdEhieTluWVRKNVNuVm9UMlkxYVhjOVBTSXNJblpoYkhWbElqb2lUVFpoTTBSa1FsUmFTMEk0Y1RsMmFqbGhMMmRWYVN0RVozZElhbTFPVkVkNVpteHdZVzlzYXlzME1HeDBNV05uY1hWMFdYWmpjMWMzUmpSR05WcFRUMVJtVG1sUk0yRmllVWNyUkU5cGRUUkpkRE5yVWt0RlIycEtVR1ZGUjNBNFdGaDFibk0zWjNKaGEyWTVTak12Y0ZOWlJEWjRiR0ZUY3pOdVRISlJSalIwVlc5c05HVm9SV00yV21sbVFUZENkMmM0YXlzMlpYbG9XVXhFZVVOaGRYUm5hMlJqZURCRFNtUjFObGROVGtabWFuY3JRM2M0TDBJMmEwRmxkVmxsYkVWaFNGRkpOREF5YVU1WUwwWXhRV3AwWWxaeGVtbGlVbTFXY1dWeWRuazFWR1l3TVVzNVYxcFBXazlrY0ZZNFZEUlVNMVpoZEdaeE0zaHFLMHR1YXlJc0ltMWhZeUk2SWpFNFltUmlPRFJpWmpZMU56azRZVGcyTkRrM01ETmpaREJoTmpWaE5HUXdZbVppWW1WalkyTXlZVGhpWXpRMk4yVmtOek15WmpBeE0ySmhaR1k1TXpnaUxDSjBZV2NpT2lJaWZRPT0=',1781731827),('t8rAVCeM7Ky1frPbVUzwB7wiJBQ87zzwhJ7L8aOD',NULL,'172.19.0.1','Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)','ZXlKcGRpSTZJblZVWlRabVRFRlNUMjVuVWxSU05rSnJVRXhtWW1jOVBTSXNJblpoYkhWbElqb2lTVzQyYlVZM1ptRjZTemRrY0dKT1NFcG5iMDl2WVU5Vk5YRjRWMmhOVWxsMmJIQmFjVTkyYW0xdk1HNVVTUzh5V2tWU1dVWXliWFZOTlRGb1p5OTNUbm9yYzBwd1UwWXdXbEJqTmpsMFNYRmthbXBqYUROMlpsWlNTRFpOZFdsbFZuUjJiM0JTV205QmExRlZOMFJtUkdGaVRUTlBVM1pGWjI0MlVrWktaVGh2TVRoQmFqZEpabkZ4U0d4emRGUTJTa1Y0VlZGa2RHRlBRek5pZG5oQ05WWlBTa3MwY0c5SWRGVkdWbFUzYkRabGNGTlJVVGR3VjBOTk1uWjNjWHBNUzFrd1kyWnFNVzV1VkROeGNqWlZTWFJETm5rd1pFUnpPWFpNU1VwTmVHaHBhazByUlVwQldpOW5XVDBpTENKdFlXTWlPaUpoWmpkbU9Ea3lOV014TXpCaFpXWXlNV0UxTnpoaE4yVXdPREV6T1RObE9XSTVaakJtWXpoaVpUZ3dabVptTnpnME16Y3lZamhrTURrME9USXlOREk0SWl3aWRHRm5Jam9pSW4wPQ==',1781777518),('u5eeX819xA5bn7BtKgKqABbF3E0I74Qi3dZl3a9z',NULL,'172.19.0.1','Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)','ZXlKcGRpSTZJbVZyUVU5V05tZGFPR3hFUnpGdmVWRjFOa3BKYW1jOVBTSXNJblpoYkhWbElqb2lhWE42VTBsT1NXTkpXR1pVWTNCRlEyWm5aRUZGV0ZoUmVGcDNXWFZsSzJrNU5teDFUME5YVTFZd1FUVnhRblZpZDBoUVIxaE1ZbVEzTlhacFltMUlaa0UzWVZwdk1FcHFSR3hSYnk5cE9IVkVUa1ZxUlhWS2JHNXBVRTlhVjBsUGRFTjVka2d6YzFVNVUxaG9iVTFrT1daNmFVSnZhazF0T0VoNVkxZExSeXR0WkZsVVpYbEZVM1pRUzBsTlNIVkRVSEJYYVROa1Fta3hkelUxU1c0NVRIUjBjRlIyTVcxNE9WWjNZVWd4ZVZCTU0yVk1RVlJDVjFvcksxVTFUVlJtYldRNU56bElNVUV2VUdvMVdFZHNUa1JQVEdKTlRtOURSbTQxV0VRM056TkxjRkpLUmtaTE4weEVUamRCY1ZSSGFIVXJSV3RKV0Voc1kyVnNRVkZ5ZHlJc0ltMWhZeUk2SW1FM016QXdNR1F3TlRsaFpEYzNPRGMwWVdSaU1USXpaREU1T1RWa01tVmpaV1psTnpRME56UTVaVEF5TURVek1qaG1aRGxtT0dWak9EVmpPVGRpTmpFaUxDSjBZV2NpT2lJaWZRPT0=',1781777518),('uApAugAYASbUlagjTzhjueDGBiaBiYDgdIpStnPA',NULL,'172.19.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/142.0.0.0 Safari/537.36','ZXlKcGRpSTZJamQzVG5GWWJHMXZkemh5VlhRNVJtdGFUbGRLVm1jOVBTSXNJblpoYkhWbElqb2lVMlpJUTNoSFpXaHBaVXBhV1ZoWWNqaGplV2N4VFc1eWRXSjZRM1JaV0VaYWFuRTFOVmsxT1ZCVk9FRnlWRzl4VTBOVmFVZFhSekp5Y1ZCMlZHZzRUakptT0ZjM1UyOXFkelJhTVN0SGVXeERNWGRKWmpGMU9XUjJPRVkyTlRKdVdFZE5WVU51TUVGU1ZXTkNSek5HYWtaeGFIbEdiSFp2WmxkWVQwOUVlVU5sVW05eVl5dHZlWE56VTIxU1FsWlhka05CZFVZMFEydGtUVmxJWml0TEsxbGpkVTR4UzJaNkwxUnlUbE5tWm1sSmJYaFRXSEE1VkZJclFVcHRhVkppVFhaMWVIbHhWakpGU0ZkbFVrdDRSV0p1WlV0VWJUbHhaVzkzTVdJMVNXeFJabTlKTVV3MGVFYzBjejBpTENKdFlXTWlPaUppWkRjNVpEWm1Nek5sWlRVMFpEazBNemRpTkRCbFl6UTRZbU00T1dRM01UUXpPR0V3WWpSa1ptWmhaalZrT0dRMVlUbGpZalJpT0dNMk1EQTFPRFF4SWl3aWRHRm5Jam9pSW4wPQ==',1781579103),('V3oS3kFOs4sJAmt78xEXMnGUwnfpJmwBHMKdfnTV',NULL,'172.19.0.1','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Googlebot/2.1; +http://www.google.com/bot.html) Chrome/148.0.7778.96 Safari/537.36','ZXlKcGRpSTZJalZPYW0xelYzTm9iVXRuZDNOamVpOUpaM1ZLY1djOVBTSXNJblpoYkhWbElqb2lXbk5vTDA4MFNUZHhOMWt4Y21KWFZGQkZaRmsxTW5aMmRWYzJVbU52Y1ZwcFRrRjRNbFZHZVhCNWRVbGxSbE5rWWpkMVRIVm1UMlo0TkVGSlVrTTRVVVZETkZwYVFUUkdXVk41YWxGcmJ6WTRNVEJQY20weldHeExORTRyWlZaS2IydHZVQ3RwVVdaNVoyUm9lR1ZvY0c0emEybzJWMUpIWkVsNVJXTmlZMFZRUTNOUVdWbzVjSEl5ZWlzM2FtMU9SVTFLZFdsNWN6Tm9hekJUV2tkNmVHaERTVVpvVFdsbGRqa3dUa1YxZDAxQ1lpczRUbFY0YzJwblp6RTBUR1Z2TURobVQwcFJjVUpEUmxSWFdHNURhRFJyUTFsUU1HaGlhM2ROWlhkYWRHcE1NbmxOVlN0cWRESldRVDBpTENKdFlXTWlPaUprTkdaaE1qVm1aak13WWpFNFpEWTFZelF3WW1WbFl6WTJaRFJqTldWaE9HTTBNemhsTURjNE1qQmlNMkk0WW1GbVlXUXlOR1U0TVdJME1HVTNaV001SWl3aWRHRm5Jam9pSW4wPQ==',1781731827),('VEh5YgnCYvDI71YbbZV0cVE4cp43KxJFvc7v9bXH',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkZ2WTFaaVpIcGhPRUpoTURkTVdscHplRGd6U1djOVBTSXNJblpoYkhWbElqb2lRMUoxYlZabVJHbEtjRzg0Tm1adVRWUkJWMUpPTkZJNFRsYzVVMU5PYlUxMGJGSnBiVzgyVFROc01YSkZNbTk0YWxoR2QyeHRlVThyTkhaWEwzUXdabGRSVVVWQ1RFNVhabU5PZFdsb05WcHBjbHBTZWpoVU1tdFBaWEZuTjFWYWQwVTJjVlJFYWtkaGJ6SmhhbkJ2UlV0SVJFb3JlbkJIVWpFeVZUUnFXbFF6YUZOWk0xSm9kV2R0VEdweVlWTTVPWGhpVW1walRYWkRNakZ6V21rM04zRkRUamgxV25KcGFVZG9aek5XV2t0SloyMWtOalJ0T0c5blpsSjRXall2VjBSU2QxZEVaRlJzVGtoMFMyTmFVVEZ0TVVjeUsya3llRkpWY2l0WmJETlhWVTQxZDBsdWR6SjZORDBpTENKdFlXTWlPaUl5Wm1WaU16SmxNakJpTkdKalpEazVPRGsyWW1JM1ltTTNNamsxTWpWak16ZGtPR1kwWXpWbVlUQmlObUUwWmpRNFlqZGxOV1l3TVRFd016ZGhNbVZoSWl3aWRHRm5Jam9pSW4wPQ==',1781762031),('XrZ2BSqtSaWD8GUb1GPXcldplMkPwbQ7iHPZhHWC',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbGgyWWtSR2JqTlRlWEIyWXl0T1oyazRSbXRuU0ZFOVBTSXNJblpoYkhWbElqb2lSM0Y1ZVdwc1NIcEhaaTlpVTNRMGRISkxSalpvVWxwNWVYQmthRnBoVEVGdVEyWnhOeklyYzJ4U1YwdDNVRXBIWlhwVVpFTmtOa2xHVFhGdFFtaDVhVVZZTkdGdmQxVnlSSHBHTWtGR2JXWlJTSG80TUZkUlRFSnBTakpDZDFwNlNGQlBaSHBwSzAxcmR6VkRRaTlVV2k5aFQwZEZSek51T0hSR00wVmpWSFZ6VURoaVNXd3dlWFY2YUdwdFFsbGpkblF3YjIxM05ua3pkV0l3VXk5R1JWSm9jeTlwYVd4dEt6aDJlWE4wZVhZdmJDdHpaVmRoUjNsaWNHMDVOa1p6VEdGMUswUjNVVFpMTkM5MVpUTmxlWFJXUTNSTE9XNHdZbVF5ZGtkMloxUm1kbVZ4T1ZSWlFTOUVjejBpTENKdFlXTWlPaUl5TVRNNE1EazBPVGhsWTJFNU9USm1Nak5rWmpNMU5ETTVZV013Wm1WaU1EZ3haamM0TWpjNE5ERmxOR1kwWWpJMU16UTVOVEZtTkRCaU1qSmxaREJqSWl3aWRHRm5Jam9pSW4wPQ==',1781580864),('zlPTI9YLyUOgsNrPwIB9EOnbuGUIMY0MyPSyxIAH',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbXR3YldoVlpVMTZVMGhQUVVrNFUwZzBSRXhsU1ZFOVBTSXNJblpoYkhWbElqb2lORlpVWVdocFltSkpUVzFUVDNWU1JGQnRTV2N4VVhkeGNFOVVTVTl5WkdVMGN6VkdOV2hhVjJKTFpXdGxXVGt2TVc5RFdsaG9TV3hoYkZBNGVFcFBlRVZCTW1sa2NIcHNMM0YxUkcxdWRqVmtMMmhvT1RCTmMwcHVhalJUUkhrd1NqQTFWMmswTmxWbWNGSjFNR3hUVjJwT1kwWk9NRU4zZUc1SVEyNW5RbkI1YWxwRlVVaFJjVkZ5UTFOR2IxbGpaVlZaUlVZMGNFdDJTV3hOVkV0TWFubG9NRFozVVZkM01tbEJkbVZHV2xOSEsyc3dWa0UyTnl0alIxaDVWVlo0YTFGR2RtRXphelptVkVSTlQwRm1ZVTVvUVd4RGMwRmxlVmMwU2pKVFRVOUdVVE4zUkVGTVpXUmpXVDBpTENKdFlXTWlPaUpqT1dSbFlXSTJabU16Tm1JM09UUTFPRFl3TXpRME9EY3hZV1V6WmpjelpHSTVZVFl5WXpnNU5HTXpOV1k1TWpFek56TTJOVGM0WldZek0yUTFZMkV3SWl3aWRHRm5Jam9pSW4wPQ==',1781667638);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `paypal_subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `current_period_end` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriptions_paypal_subscription_id_unique` (`paypal_subscription_id`),
  KEY `subscriptions_user_id_foreign` (`user_id`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,1,'pro','I-GR2USDDP0EK3','active','2026-07-06 10:00:00','2026-06-02 06:22:00','2026-06-06 09:49:48');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `synthesis_usage`
--

DROP TABLE IF EXISTS `synthesis_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `synthesis_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `synthesis_usage_user_id_period_type_period_key_unique` (`user_id`,`period_type`,`period_key`),
  CONSTRAINT `synthesis_usage_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `synthesis_usage`
--

LOCK TABLES `synthesis_usage` WRITE;
/*!40000 ALTER TABLE `synthesis_usage` DISABLE KEYS */;
INSERT INTO `synthesis_usage` VALUES (1,1,'month','2026-06',15,'2026-06-06 16:14:01','2026-06-10 04:48:17'),(16,2,'day','2026-06-12',3,'2026-06-12 09:15:22','2026-06-12 09:17:22');
/*!40000 ALTER TABLE `synthesis_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translation_usage`
--

DROP TABLE IF EXISTS `translation_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `translation_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translation_usage_user_id_period_type_period_key_unique` (`user_id`,`period_type`,`period_key`),
  CONSTRAINT `translation_usage_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translation_usage`
--

LOCK TABLES `translation_usage` WRITE;
/*!40000 ALTER TABLE `translation_usage` DISABLE KEYS */;
INSERT INTO `translation_usage` VALUES (1,1,'month','2026-06',5,'2026-06-10 04:27:51','2026-06-10 04:49:34');
/*!40000 ALTER TABLE `translation_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `plan_override` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_note` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_index` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Chathura','chathu.ad@gmail.com',NULL,'2026-06-06 06:59:54','super_admin',NULL,NULL,NULL,'$2y$12$PZhZrYH582onrcRyZOgLZeRLsbMVZvT.jq4nYfvlZVppE72uGU6Qm',NULL,'2026-05-24 07:43:19','2026-06-11 16:13:03'),(2,'Chathura','sriya@gmail.com',NULL,NULL,'user',NULL,NULL,NULL,'$2y$12$.SBlEUTK.1on0kILLVqW1Ox2EzWNF7xLROgmEC60RPz1srV0YUIhW',NULL,'2026-05-25 10:01:51','2026-05-25 10:01:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voice_profiles`
--

DROP TABLE IF EXISTS `voice_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voice_profiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `profile_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_key` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ready',
  `duration` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voice_profiles_user_id_profile_id_unique` (`user_id`,`profile_id`),
  UNIQUE KEY `voice_profiles_engine_key_unique` (`engine_key`),
  CONSTRAINT `voice_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voice_profiles`
--

LOCK TABLES `voice_profiles` WRITE;
/*!40000 ALTER TABLE `voice_profiles` DISABLE KEYS */;
INSERT INTO `voice_profiles` VALUES (6,1,'my-voice','fce9bfb6-9dfd-4e17-9ad4-10ea41712564','my-voice','ready',13.56,'2026-06-05 05:44:23','2026-06-05 05:44:23'),(7,1,'my-voice-2','c83ea104-f42a-413f-9c45-5a6097af5d53','my-voice-2','ready',13.78,'2026-06-10 03:47:29','2026-06-10 03:47:29'),(8,2,'my-voice','c8a8b2c4-4f67-4642-97fc-0ea7072de116','my-voice','ready',12.37,'2026-06-12 09:14:19','2026-06-12 09:14:19');
/*!40000 ALTER TABLE `voice_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'voice_saas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  3:15:01
