-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: voice_saas
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `project_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'task',
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('running','done','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `started_at` timestamp NOT NULL,
  `ended_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_logs_user_id_started_at_index` (`user_id`,`started_at`),
  KEY `activity_logs_user_id_project_id_index` (`user_id`,`project_id`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,1,'iidthvnj','synthesis','Synthesising \"News Report\"','Audio ready','done','2026-06-14 13:30:04','2026-06-14 13:30:15','2026-06-14 13:30:04','2026-06-14 13:30:15'),(2,1,'qo5ajmvm','synthesis','Synthesising \"YouTube Outro\"','Audio ready','done','2026-06-14 13:30:52','2026-06-14 13:31:09','2026-06-14 13:30:53','2026-06-14 13:31:09'),(3,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','F5','failed','2026-06-14 13:32:34','2026-06-14 14:13:25','2026-06-14 13:32:34','2026-06-14 14:13:25'),(4,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','1 scripts processed','done','2026-06-14 13:34:17','2026-06-14 13:34:20','2026-06-14 13:34:17','2026-06-14 13:34:21'),(5,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','Engine returned HTTP 500 — the model may have crashed or run out of memory.','failed','2026-06-14 13:34:38','2026-06-14 13:34:42','2026-06-14 13:34:39','2026-06-14 13:34:42'),(6,1,'qo5ajmvm','synthesis','Bulk synthesis complete: 1/1 succeeded',NULL,'done','2026-06-14 14:15:31','2026-06-14 14:15:34','2026-06-14 14:15:31','2026-06-14 14:15:34'),(7,1,'qo5ajmvm','synthesis','Synthesising \"News Report\"','1 scripts processed','done','2026-06-14 14:18:41','2026-06-14 14:18:46','2026-06-14 14:18:42','2026-06-14 14:18:46'),(10,1,'wcy0cecq','synthesis','Bulk synthesis: 3 scripts','Marked failed automatically — the task was interrupted (e.g. the page was closed) and never reported completion.','failed','2026-06-15 08:01:31','2026-06-15 09:15:01','2026-06-15 08:01:32','2026-06-15 09:15:01'),(11,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:98|scripts:3','done','2026-06-15 08:01:33','2026-06-15 08:01:53','2026-06-15 08:01:33','2026-06-15 08:01:53'),(12,1,'wcy0cecq','delete','Deleted script \"Podcast Intro\"','generated audio removed','done','2026-06-15 09:43:39','2026-06-15 09:43:40','2026-06-15 09:43:40','2026-06-15 09:43:41'),(13,1,'wcy0cecq','delete','Deleted script \"News Report\"','generated audio removed','done','2026-06-15 09:44:03','2026-06-15 09:44:04','2026-06-15 09:44:04','2026-06-15 09:44:04'),(14,1,'wcy0cecq','delete','Deleted script \"YouTube Outro\"','generated audio removed','done','2026-06-15 09:44:07','2026-06-15 09:44:08','2026-06-15 09:44:08','2026-06-15 09:44:09'),(15,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:94|scripts:3','done','2026-06-15 09:44:28','2026-06-15 09:44:48','2026-06-15 09:44:28','2026-06-15 09:44:48'),(16,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:38|scripts:1','done','2026-06-15 09:45:30','2026-06-15 09:45:38','2026-06-15 09:45:30','2026-06-15 09:45:38'),(17,1,'wcy0cecq','synthesis','Bulk synthesis complete: 3/3 succeeded','model:f5|words:94|scripts:3','done','2026-06-15 11:26:26','2026-06-15 11:26:44','2026-06-15 11:26:26','2026-06-15 11:26:44'),(18,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:38|scripts:1','done','2026-06-15 11:28:30','2026-06-15 11:28:40','2026-06-15 11:28:30','2026-06-15 11:28:40'),(19,1,'wcy0cecq','synthesis','Bulk synthesis complete: 2/2 succeeded','model:f5|words:56|scripts:2','done','2026-06-15 11:48:21','2026-06-15 11:48:33','2026-06-15 11:48:21','2026-06-15 11:48:33'),(20,3,'lfoe5um5','synthesis','Bulk synthesis complete: 1/1 succeeded','model:xtts|words:7|scripts:1','done','2026-06-24 08:39:09','2026-06-24 08:39:23','2026-06-24 08:39:09','2026-06-24 08:39:23'),(21,3,'lfoe5um5','delete','Deleted script \"AaaaUntitled Script\"','no audio','done','2026-06-24 08:41:21','2026-06-24 08:41:22','2026-06-24 08:41:22','2026-06-24 08:41:23'),(22,3,'lfoe5um5','synthesis','Bulk synthesis complete: 1/1 succeeded','model:xtts|words:69|scripts:1','done','2026-06-24 08:41:41','2026-06-24 08:43:43','2026-06-24 08:41:41','2026-06-24 08:43:43'),(23,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:80|scripts:1','done','2026-06-24 09:39:28','2026-06-24 09:39:44','2026-06-24 09:39:28','2026-06-24 09:39:44'),(24,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:273|scripts:1','done','2026-06-24 09:41:26','2026-06-24 09:42:10','2026-06-24 09:41:26','2026-06-24 09:42:10'),(25,1,'wcy0cecq','synthesis','Bulk synthesis complete: 1/1 succeeded','model:f5|words:503|scripts:1','done','2026-06-24 09:43:02','2026-06-24 09:44:31','2026-06-24 09:43:02','2026-06-24 09:44:31');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint unsigned DEFAULT NULL,
  `target_user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `after_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `admin_audit_log_actor_id_created_at_index` (`actor_id`,`created_at`),
  KEY `admin_audit_log_target_user_id_index` (`target_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,1,NULL,'setting.changed (gemini_api_key)','(empty)','(updated)','172.19.0.1',NULL,'2026-06-12 05:05:12');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `is_secret` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES (1,'gemini_api_key','eyJpdiI6ImRWZzZBR3htWTVQYXdsRkdFVGFZbUE9PSIsInZhbHVlIjoiMlBzUTZ2TitBNzNvdmxIMWFjejlkVkE5aUJQTHMxSldXd2V5dkxEamQ4elpoOTdWMFpTYWZUVlBGd3JEMzFjNCIsIm1hYyI6IjNkYzUyNTYwZTEwODU0YTRiNmFiMWU2N2NkZjMwMTdlYmExMDcwNmM3ZTEzMDhiMWUwN2FmNGU4MDUxMjNjNTQiLCJ0YWciOiIifQ==',1,'2026-06-12 05:05:12','2026-06-12 05:05:12');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('voxora-cache-356a192b7913b04c54574d18c28d46e6395428ab','i:1;',1782294242),('voxora-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer','i:1782294242;',1782294242),('voxora-cache-77de68daecd823babbb58edb1c8e14d7106e83bb','i:1;',1782290561),('voxora-cache-77de68daecd823babbb58edb1c8e14d7106e83bb:timer','i:1782290561;',1782290561),('voxora-cache-a7865b871c474506e0726a495e3cbe56b929c154','i:2;',1782363702),('voxora-cache-a7865b871c474506e0726a495e3cbe56b929c154:timer','i:1782363702;',1782363702),('voxora-cache-app_setting:discord_webhook_url','N;',1782443144),('voxora-cache-app_setting:gemini_api_key','s:39:\"AIzaSyDiZcExZumUpFukZHo5nhqJNkzHcU9gcRI\";',1782292682),('voxora-cache-app_setting:moderation_keywords','N;',1781505648),('voxora-cache-app_setting:paypal_plan_pro','N;',1782292686),('voxora-cache-app_setting:paypal_plan_starter','N;',1782292686),('voxora-cache-app_setting:slack_webhook_url','N;',1782443144),('voxora-cache-da4b9237bacccdf19c0760cab7aec4a8359010b0','i:7;',1781255849),('voxora-cache-da4b9237bacccdf19c0760cab7aec4a8359010b0:timer','i:1781255849;',1781255849),('voxora-cache-engine:active_url','s:25:\"http://34.59.245.242:8000\";',1782443064),('voxora-cache-guest_limits','a:6:{s:11:\"synth_limit\";i:5;s:13:\"preview_limit\";i:5;s:12:\"script_limit\";i:5;s:12:\"session_days\";i:7;s:10:\"word_limit\";i:500;s:13:\"profile_limit\";i:1;}',1782446633),('voxora-cache-heartbeat:queue','s:25:\"2026-06-26T03:10:47+00:00\";',1782529847),('voxora-cache-heartbeat:scheduler','s:25:\"2026-06-26T03:14:48+00:00\";',1782530088),('voxora-cache-paypal_access_token_686f372cc9173e495972bb26d2c7b3f7','s:97:\"A21AAIgsi65liIkqk8sdhNrUfqtZRayHfUerL7nCR8MgSHiV6Ldu8BcihesJBr0S_l6mgO4UbGnqzpdGPGlzPQyZWnuRjw4ag\";',1782392507),('voxora-cache-synth_batch:1:19b4ab2b-8510-40ca-b1c9-e201aaa07c32','b:1;',1781174975),('voxora-cache-synth_batch:1:1d54d19f-9f32-4c31-a1f2-fe373bdae904','b:1;',1781447555),('voxora-cache-synth_batch:1:4de93186-0e4c-487f-9b55-6a0850674272','b:1;',1781447679),('voxora-cache-synth_batch:1:6820e42b-98db-40da-8c24-5f634893fe24','b:1;',1781338573),('voxora-cache-synth_batch:1:68dff763-9831-414c-8643-34f6ea9631fb','b:1;',1781447563),('voxora-cache-synth_batch:1:6f118756-65d1-4b8c-9f0f-d4dd3d9a3c7c','b:1;',1781447453),('voxora-cache-synth_batch:1:7eed9cbe-0960-4fa2-9348-0b6ba3ec1c51','b:1;',1781160913),('voxora-cache-synth_batch:1:81536a9d-48d9-4072-a8e5-517b89bc8372','b:1;',1781164766),('voxora-cache-synth_batch:1:aa4f3ce1-e537-4bf6-a1f3-15e38e18680d','b:1;',1781164739),('voxora-cache-synth_batch:1:b9463c72-11e7-41fc-b4fa-ebb3e43a95a9','b:1;',1781450323),('voxora-cache-synth_batch:1:dbfd552c-4466-4d93-a131-ae4815da925f','b:1;',1781338658),('voxora-cache-synth_batch:1:eeb626fe-ead1-49c5-8c8a-3bd0eb0b8c93','b:1;',1781446713),('voxora-cache-synth_batch:1:f21d5822-f253-4c6e-8ef5-ed8cc9240658','b:1;',1781447405),('voxora-cache-synth_batch:1:fede0ee5-b46d-4641-b819-367d4de3276a','b:1;',1781447658),('voxora-cache-synth_batch:2:6a6be2a5-d38d-4298-b5e8-27ffe9004ccf','b:1;',1781259389),('voxora-cache-synth_batch:2:d9cbf454-63b7-40ff-84e4-738c47b91b28','b:1;',1781259442),('voxora-cache-synth_job_owner:120d6e1f7839444ba3e9ff28bff73f7e','s:1:\"1\";',1781447679),('voxora-cache-synth_job_owner:172aac6866c04c9ab06204de1eb88e06','s:1:\"1\";',1781447564),('voxora-cache-synth_job_owner:227f98ce6b24471483ff866f67d3a9e9','s:1:\"1\";',1781164766),('voxora-cache-synth_job_owner:351766b61e9e48f2975874da51aa4de1','s:1:\"2\";',1781259389),('voxora-cache-synth_job_owner:35cec168c0b648528544a83b2189616c','s:1:\"1\";',1781450323),('voxora-cache-synth_job_owner:37c2f68f735f40839bccb0a28931db4a','s:1:\"1\";',1781160914),('voxora-cache-synth_job_owner:46b873633bd843f193ece4bace6dc8dd','s:1:\"1\";',1781174975),('voxora-cache-synth_job_owner:5aa06e9cc7c945b8b3568c87c1a29017','s:1:\"1\";',1781338574),('voxora-cache-synth_job_owner:5c949dc7a5b8446498bb82f9fbed920f','s:1:\"1\";',1781447453),('voxora-cache-synth_job_owner:6c93e4e4c9d046649478584f7a7afc0b','s:1:\"1\";',1781160881),('voxora-cache-synth_job_owner:7fb5ceeb310848f690adf16f61eb5139','s:1:\"2\";',1781259442),('voxora-cache-synth_job_owner:83582e0631d24ccea0d09337dbeaa60c','s:1:\"1\";',1781447405),('voxora-cache-synth_job_owner:8b509470a014458a8bcea2393fec5e0b','s:1:\"1\";',1781164739),('voxora-cache-synth_job_owner:957e5baf14a849b4b9fe1d7838223c81','s:1:\"2\";',1781259322),('voxora-cache-synth_job_owner:ca53db007a364e26b52f2977d30205cc','s:1:\"1\";',1781160827),('voxora-cache-synth_job_owner:cab0fd7b1f974a809cdfbccfbea15aa9','s:1:\"1\";',1781446713),('voxora-cache-synth_job_owner:d3039abfd53748fb963daa1b53469503','s:1:\"1\";',1781447658),('voxora-cache-synth_job_owner:ea60702620a84ad0a83c870cd388bc4b','s:1:\"1\";',1781338658),('voxora-cache-synth_job_owner:ecdc050bfd2748ebbcc7ea840ec21b83','s:1:\"1\";',1781160898),('voxora-cache-synth_job_owner:f3c5975ed5794715b500ea7bd718f173','s:1:\"1\";',1781447555);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine_configs`
--

DROP TABLE IF EXISTS `engine_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `engine_configs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `latency_ms` int DEFAULT NULL,
  `last_tested_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine_configs`
--

LOCK TABLES `engine_configs` WRITE;
/*!40000 ALTER TABLE `engine_configs` DISABLE KEYS */;
INSERT INTO `engine_configs` VALUES (1,'Local Server','http://ai-engine:8000',0,'online',3,'2026-06-13 07:15:49','2026-06-09 05:50:48','2026-06-13 07:15:49'),(2,'GCP Server','http://34.59.245.242:8000',1,'online',56,'2026-06-13 07:15:53','2026-06-09 16:30:54','2026-06-13 07:15:53');
/*!40000 ALTER TABLE `engine_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=4572 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_05_12_012958_create_projects_table',1),(5,'2026_05_12_012959_create_scripts_table',1),(6,'2026_05_12_013000_create_voice_profiles_table',1),(7,'2026_05_12_044441_create_personal_access_tokens_table',1),(8,'2026_05_12_100000_add_duration_to_voice_profiles_table',1),(9,'2026_05_22_000001_add_tone_to_scripts_table',1),(10,'2026_05_25_000001_add_bio_to_users_table',2),(11,'2026_05_26_000001_add_engine_key_to_voice_profiles',3),(12,'2026_05_26_000002_create_subscriptions_table',3),(13,'2026_05_26_000003_create_guest_limits_table',4),(14,'2026_06_05_000001_add_lane_config_to_projects_table',5),(15,'2026_06_06_000001_create_plan_limits_table',6),(16,'2026_06_06_000002_merge_guest_limits_into_plan_limits',6),(17,'2026_06_06_000003_guest_inherits_free_limits',6),(18,'2026_06_06_000004_add_synth_limit_to_plan_limits',6),(19,'2026_06_06_000005_create_synthesis_usage_table',6),(20,'2026_06_06_000006_add_advanced_params_to_scripts',6),(21,'2026_06_07_000001_add_translation_limits',7),(22,'2026_06_07_000002_create_translation_usage_table',7),(23,'2026_06_07_000003_add_engine_to_scripts',8),(24,'2026_06_09_000001_create_engine_configs_table',9),(25,'2026_06_11_000001_create_activity_logs_table',10),(26,'2026_06_11_100001_add_role_to_users_table',11),(27,'2026_06_11_100002_create_admin_audit_log_table',11),(28,'2026_06_11_200001_add_suspension_and_plan_override_to_users',12),(29,'2026_06_12_000001_create_app_settings_table',13),(30,'2026_06_12_000002_add_admin_note_to_users',13),(31,'2026_06_25_000001_add_creator_plan_and_align_limits',14);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_limits`
--

DROP TABLE IF EXISTS `plan_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_limits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_limit` int unsigned DEFAULT '1',
  `profile_limit` int unsigned DEFAULT '1',
  `word_limit` int unsigned DEFAULT '500',
  `synth_limit` int unsigned DEFAULT NULL,
  `synth_period` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translate_limit` int unsigned DEFAULT NULL,
  `translate_period` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_limit` int unsigned DEFAULT NULL,
  `script_limit` int unsigned DEFAULT NULL,
  `session_days` int unsigned DEFAULT NULL,
  `multi_voice` tinyint(1) NOT NULL DEFAULT '0',
  `data_export` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_limits_plan_unique` (`plan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_limits`
--

LOCK TABLES `plan_limits` WRITE;
/*!40000 ALTER TABLE `plan_limits` DISABLE KEYS */;
INSERT INTO `plan_limits` VALUES (1,'free',1,1,500,20,'month',10,'month',NULL,NULL,NULL,0,0,'2026-06-06 15:06:44','2026-06-25 03:15:12'),(2,'starter',10,3,5000,150,'month',50,'month',NULL,NULL,NULL,1,0,'2026-06-06 15:06:44','2026-06-25 03:15:12'),(3,'pro',0,25,0,2000,'month',0,'month',NULL,NULL,NULL,1,1,'2026-06-06 15:06:44','2026-06-25 03:15:12'),(4,'guest',NULL,NULL,NULL,5,NULL,NULL,NULL,5,5,7,0,0,'2026-06-06 15:06:44','2026-06-06 15:06:45'),(5,'creator',0,10,0,600,'month',200,'month',NULL,NULL,NULL,1,0,'2026-06-25 03:15:12','2026-06-25 03:15:12');
/*!40000 ALTER TABLE `plan_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emoji` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `timeline_clips` json DEFAULT NULL,
  `lane_config` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `projects_user_id_foreign` (`user_id`),
  CONSTRAINT `projects_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES ('bww8kv5w',2,'My Guest Project','🎬',NULL,'[]',NULL,'2026-05-27 14:14:17','2026-05-27 14:14:34'),('iidthvnj',1,'News','🎬',NULL,'[{\"ci\": 0, \"id\": \"tc_g50vztos\", \"dur\": 11.5, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 11.5, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"1j4xkyfr\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_1sg75nyr\", \"dur\": 16.2, \"lane\": 1, \"isGap\": false, \"start\": 0, \"title\": \"Podcast Intro\", \"rawDur\": 16.2, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"9j38a4p2\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-09 16:31:45','2026-06-11 15:52:33'),('lfoe5um5',3,'Kesara Bandaragoda','🎤','Fff',NULL,NULL,'2026-06-24 08:37:46','2026-06-24 08:37:46'),('qo5ajmvm',1,'Project 1','📹',NULL,'[{\"ci\": 0, \"id\": \"tc_cyq2jeil\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_2y0vm8au\", \"dur\": 17.4, \"lane\": 1, \"isGap\": false, \"start\": 10.1, \"title\": \"Podcast Intro\", \"rawDur\": 17.4, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"0whm6v9q\", \"trimStart\": 0}, {\"ci\": 0, \"id\": \"tc_b02711em\", \"dur\": 13.9, \"lane\": 2, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 13.9, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"ixaifltr\", \"trimStart\": 0}, {\"ci\": 1, \"id\": \"tc_3nw3uqjd\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 15, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 2, \"id\": \"tc_yfhyuao6\", \"dur\": 15, \"lane\": 0, \"isGap\": false, \"start\": 30, \"title\": \"YouTube Outro\", \"rawDur\": 15, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"68rfbvzf\", \"trimStart\": 0}, {\"ci\": 3, \"id\": \"tc_bs79rsif\", \"dur\": 17.4, \"lane\": 0, \"isGap\": false, \"start\": 45, \"title\": \"Podcast Intro\", \"rawDur\": 17.4, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"0whm6v9q\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-05 05:45:53','2026-06-09 03:01:46'),('wcy0cecq',1,'Smple','📹',NULL,'[{\"ci\": 0, \"id\": \"tc_ijrj25u2\", \"dur\": 11.95, \"lane\": 0, \"isGap\": false, \"start\": 0, \"title\": \"Product Demo\", \"rawDur\": 11.95, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"n0afspme\", \"trimStart\": 0}, {\"ci\": 1, \"id\": \"tc_b3ib802z\", \"dur\": 11.95, \"lane\": 1, \"isGap\": false, \"start\": 0, \"title\": \"Product Demo\", \"rawDur\": 11.95, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"n0afspme\", \"trimStart\": 0}, {\"ci\": 2, \"id\": \"tc_xj2e2or2\", \"dur\": 11.76, \"lane\": 2, \"isGap\": false, \"start\": 0, \"title\": \"News Report\", \"rawDur\": 11.76, \"volume\": 1, \"trimEnd\": 0, \"scriptId\": \"xu7ibp0n\", \"trimStart\": 0}]','{\"mute\": [], \"solo\": []}','2026-06-15 06:37:04','2026-06-15 11:49:06');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scripts`
--

DROP TABLE IF EXISTS `scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scripts` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `has_audio` tinyint(1) NOT NULL DEFAULT '0',
  `profile_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `duration` double DEFAULT NULL,
  `speed` double NOT NULL DEFAULT '1',
  `tone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'natural',
  `engine` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'xtts',
  `speaker_map` json DEFAULT NULL,
  `waveform_peaks` json DEFAULT NULL,
  `advanced_params` json DEFAULT NULL,
  `order_index` int NOT NULL DEFAULT '0',
  `audio_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scripts_project_id_foreign` (`project_id`),
  CONSTRAINT `scripts_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scripts`
--

LOCK TABLES `scripts` WRITE;
/*!40000 ALTER TABLE `scripts` DISABLE KEYS */;
INSERT INTO `scripts` VALUES ('0whm6v9q','qo5ajmvm','Podcast Intro','Welcome back to Voxora I\'m your host  voxora agent, and today we\'re diving into voice cloning. Whether you\'re a longtime listener or just joining us for the first time — you\'re in the right place. Let\'s get started.',1,'builtin:Claribel Dervla','en',15.3,1,'natural','xtts',NULL,'[1, 0.7649498033711534, 0.8000682807243477, 0.6057946042973764, 0.6429616940560209, 0.6889571802062933, 0.4658570160446355, 0.01326659431582514, 0, 0.8084577908907107, 0.8253341508206986, 0.819432282291315, 0.26338090547943754, 0, 0.7648522730988724, 0.6792788975856825, 0.6497902908470938, 0.3713296608053483, 0.008486977128579124, 0, 0.46946644648786623, 0.6764499953332289, 0.6126720138933446, 0.6004780604079435, 0.5975514848769445, 0.5685787017338365, 0.5136572412509006, 0.2886060187904511, 0.4163496773921682, 0.31460346126641964, 0.038239008109503904, 0, 0.8539395032019579, 0.8323091383577027, 0.7362208935775029, 0.6277436824360946, 0.6946152230549741, 0.46990538038188584, 0.22880694831210183, 0, 0.6336455509654781, 0.7380743977696361, 0.8419179199338434, 0.7802653929321156, 0.46263780202803856, 0.4614672004168919, 0.5127304653204565, 0.4983416516899384, 0, 0.4218125166900228, 0.7481709260446917, 0.6352357329562036, 0.4625261618043425, 0.27602187271279355, 0.12832894749010182, 0, 0.6269632972515816, 0.9110819463076308, 0.8377231648506619, 0.385523390056927]',NULL,0,'1/0whm6v9q.mp3','2026-06-05 05:46:00','2026-06-09 11:25:19'),('1j4xkyfr','iidthvnj','News Report','Breaking News. According to the Source details.This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'my-voice-2','en',11.5,1,'natural','f5',NULL,'[0.4284027863645301, 0.8100867368967286, 0.5919964486318516, 0.6322855749993412, 0.34891338168491337, 0.036660616806971386, 0, 0, 0.8522944027437968, 0.9539765390782252, 0.613670638982752, 0.44105473809673423, 0.7736346894883962, 0.43852732749411655, 0.3827326886005542, 0.1332082693972201, 0.10614143318583263, 0, 0.026600982023225785, 0.13606014521690304, 0.7958517202446228, 0.9939546673531564, 1, 0.6507129594531866, 0.571877806178813, 0.550410981673562, 0.22043040068432757, 0.03479388394911327, 0, 0.7856643916559065, 0.8992724965591053, 0.6566761971171485, 0.6998703710085116, 0.5970779760444813, 0.5679370442968311, 0.2633572591221715, 0.6636764160371029, 0.852709235786926, 0.655152423018217, 0.6156598206883411, 0.7691470331278594, 0.5995668729514261, 0.6608244768725258, 0.5251589703464814, 0.7963183947491643, 0.1827326886005542, 0.07715605749486652, 0.16696405405295836, 0.02473424916536767, 0, 0, 0.18863826974181636, 0.994058350275981, 0.9507907469832628, 0.7674642380065311, 0.6290189041434655, 0.8380088115281626, 0.22503851369567288, 0.14980554384378844, 0.1457565001996631]',NULL,0,'1/1j4xkyfr.mp3','2026-06-09 16:31:51','2026-06-14 13:30:15'),('59iexlcq','lfoe5um5','Untitled Script','100% agree.\n\nThat’s probably why token usage is now visible in the UI — to create a rave for secondary AI adopters.\n\nBut people need to understand this clearly:\n\nBurning more tokens is not the achievement.\n\nThe real achievement is what those tokens moved in the world.\n\nDid they create a clearer decision?\nA better output?\nFaster execution?\nReal value?\n\nToken count is not the score.\nMovement is the score.',1,'my-voice','en',37.15,1,'natural','xtts',NULL,'[0.9583, 0.7918, 0.6113, 0.9343, 1, 0.7564, 0.7423, 0.8002, 0.608, 0.817, 0.0885, 0.0056, 0.0259, 0.8971, 0.8841, 0.6549, 0.6479, 0.8933, 0.8989, 0.8092, 0.8814, 0.6721, 0.5137, 0.8021, 0.8715, 0.6361, 0.8985, 0.7487, 0.3418, 0.0393, 0.0842, 0.938, 0.6299, 0.6969, 0.7588, 0.6479, 0.631, 0.6748, 0.7943, 0.9258, 0.5797, 0.745, 0.6158, 0.1727, 0.8747, 0.5818, 1, 0.8595, 0.4555, 0.7491, 0.8051, 0.9134, 0.7356, 0.7504, 0.5358, 0.002, 0.0008, 0.6835, 0.7417, 0.2399]',NULL,0,'3/script_59iexlcq.mp3','2026-06-24 08:41:24','2026-06-24 08:43:43'),('68rfbvzf','qo5ajmvm','YouTube Outro','Thanks for watching! If you found this video helpful, please hit that like button and subscribe for more content like this. Drop your questions in the comments — I read every single one. See you in the next video!',1,'builtin:Claribel Dervla','en',13.3,1,'dramatic','f5',NULL,'[0.8135851824899027, 0.9043972501660572, 0.693772595890775, 0.887492642619719, 0, 0, 0, 0.5245175180792008, 0.6108576819410227, 0.9086743339343976, 0.687692219957256, 0.7852502365209907, 0.22409490537866547, 0, 0, 0, 0, 0.1879366158578641, 0.4510275152586643, 0.7527139452537258, 0.7463492266017393, 0.8117011756083511, 0.7251675352870608, 0.7938553110581948, 0.7395997943416894, 0.8441617781680925, 0.8044197826096909, 0.7692621042714706, 0.6465508541527871, 0.8147054350762072, 0.7256988491136409, 0, 0, 0, 0, 0.40902055627666895, 0.44732424246103647, 0.9313610412059076, 0.7995824730232707, 0.8131530452537856, 0.7614208337919773, 0.4897757544138808, 0, 0, 0, 0.7036803522067762, 0.7943887149082569, 0.9087529586272886, 0.7979796240625001, 0.7628697674520444, 0.07642721980896389, 0, 0, 0, 0.9962319862368968, 0.9190105948266544, 0.8963796215146619, 0.8939864451029456, 1, 0.79576350249718]',NULL,1,'1/68rfbvzf.mp3','2026-06-06 15:46:20','2026-06-14 13:32:44'),('8uxj0cau','wcy0cecq','Untitled Script','The submersible Nautilus II groaned under the crushing weight of two miles of ocean. Inside the cramped, glowing cockpit, Dr. Aris Thorne stared out the reinforced acrylic viewport. The high-powered halogen beams cut through the abyssal blackness, revealing nothing but marine snow drifting through the void.\n\n\"Depth: 4,200 meters,\" synthesized the ship\'s computer.\n\n\"We should be seeing the trench floor by now,\" Aris muttered, checking his sonar readings. Beside him, Maya, the pilot, kept her hands steady on the thruster controls.\n\nSuddenly, the sonar pinged. It wasn\'t the erratic reflection of jagged volcanic rock. It was a perfectly rhythmic, repeating echo. A grid pattern.\n\n\"Aris, look,\" Maya whispered, killing the secondary thrusters.\n\nThe halogen lights caught something massive. Emerging from the silt was a structure that defied all geological logic. It was a monolithic archway, easily eighty feet tall, constructed from a seamless, black material that seemed to absorb the light rather than reflect it. Luminescent blue veins pulsed slowly across its surface, mimicking the rhythm of a heartbeat.\n\n\"That\'s not a natural formation,\" Aris breathed, his scientific detachment melting into pure awe. \"The composition looks like obsidian, but the structural integrity at this pressure... it\'s impossible.\"\n\nMaya nudged the submersible closer. \"Look at the base, Aris. There are carvings.\"\n\nHe zoomed the external camera onto the foundation of the arch. Etched deep into the black stone were symbols. They weren\'t Egyptian, cuneiform, or Mayan. Yet, as Aris stared at them, a strange sense of familiarity washed over him. They resembled star charts—specifically, the constellations as they would have appeared from Earth sixty million years ago.\n\nSuddenly, the Nautilus II shuddered. The external temperature sensors spiked, jumping from a near-freezing two degrees Celsius to a blistering forty degrees in seconds. The luminescent blue veins on the archway flared into a blinding, brilliant gold.\n\n\"The power grid is fluctuating!\" Maya warned, alarms beginning to blare in the small cabin. \"We\'re losing battery alignment. Aris, we need to pull back!\"\n\nBut Aris couldn\'t move his eyes away. In the center of the archway, the water itself was changing. The abyssal blackness was being replaced by a swirling, violent vortex of liquid light. Through the shimmer, Aris didn\'t see the ocean floor. He saw a sky. A sky filled with two moons, violet clouds, and rings that spanned the horizon. It was a window to another world, opened at the bottom of Earth\'s ocean.\n\n\"Initiating emergency ballast blow,\" Maya yelled, slamming her palm onto the manual override.\n\nThe compressed air hissed violently, and the Nautilus II lurched upward, breaking away from the gravitational pull of the gate. As they rocketed toward the surface, the golden light faded back into the dark.\n\nAris clutched the digital recording drive tightly to his chest, his heart hammering against his ribs. They had descended into the deepest trench on Earth looking for undiscovered marine life, but instead, they had uncovered a cosmic doorway. The stars weren\'t just waiting in the sky—they were waiting at the bottom of the sea.',1,'my-voice','en',229.63,1,'natural','xtts',NULL,'[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.9933, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.995, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]',NULL,5,'1/script_8uxj0cau.mp3','2026-06-24 09:38:36','2026-06-24 09:44:31'),('9j38a4p2','iidthvnj','Podcast Intro','ようこそ、[ポッドキャスト名]へ！ホストの[名前]です。今日は、[テーマ]について深く掘り下げていきます。ベテランリスナーの方も、初めてお聴きになる方も、まさにぴったりの場所です。それでは、始めましょう。',1,'my-voice-2','ja',19.7,1,'cheerful','f5',NULL,'[0.7407458118922263, 0.6225014793440496, 0.8935482800139084, 0.7734372017227227, 0.44834497244179383, 0.409792585685147, 0.07367160066138627, 0, 0, 0.14838592862357416, 0.7022264873292592, 0.5256112745729303, 0.4249874893193095, 0.35883077398728896, 0.09871147331097802, 0, 0, 0.515639930550704, 0.4863179030933309, 0.3996266508513982, 0.41260300564264407, 0.5038929286864947, 0.7811319266964443, 0.39033831034302, 0.2793789629577946, 0.8220188692124586, 0.5819787994356554, 0.6635907998639066, 0.1964667906506346, 0, 0, 0.6307881644288352, 0.5659518231775145, 0.789670338335262, 0.7089412275231594, 0.8593088408483892, 0.8580339662199606, 0.8424623404704656, 0, 0, 0.8412785092448213, 0.7496244125898341, 0.5773346069323455, 0.16241446659201048, 0.8730403753017315, 0.7950189380067404, 0.6537358632423075, 0.5475740048034962, 0, 0.7485316247669739, 0.47315941699827496, 0.3600255517804236, 0.4330464769006512, 0, 0, 1, 0.6514137669906525, 0.7052530797455662, 0.39179531627525865, 0.5230615253160732]',NULL,1,'1/9j38a4p2.mp3','2026-06-10 03:49:29','2026-06-13 07:17:53'),('aw6cr5o7','wcy0cecq','YouTube Outro','Thanks for watching! If you found this video helpful, please hit that like button and subscribe for more content like this. Drop your questions in the comments — I read every single one. See you in the next video!',1,'my-voice','en',14.78,1,'natural','xtts',NULL,'[0, 0.0016, 0.0032, 1, 0.845, 1, 0.4948, 0.0081, 0.0038, 0.849, 0.8136, 1, 0.9098, 1, 0.7911, 0.6778, 0.2904, 0.8939, 0.8881, 1, 0.8516, 0.6906, 0.0735, 0.0067, 1, 0.9929, 0.9098, 0.9608, 0.6992, 1, 1, 0.6167, 0.4373, 0.182, 0.8609, 0.0027, 0.0103, 1, 1, 0.8988, 1, 0.6083, 0.6101, 0.8384, 0.005, 0.0041, 1, 1, 0.8155, 0.8951, 0.6083, 0.3468, 0.0191, 0.0039, 1, 0.9253, 1, 1, 1, 0.8802]',NULL,0,'1/script_aw6cr5o7.mp3','2026-06-15 09:44:14','2026-06-15 11:28:40'),('dzshzgie','qo5ajmvm','YouTube Outro','Merci d\'avoir regardé ! Si cette vidéo vous a été utile, n\'hésitez pas à laisser un j\'aime et à vous abonner pour plus de contenu comme celui-ci. Laissez vos questions dans les commentaires — je les lis toutes. À bientôt dans la prochaine vidéo !',1,'my-voice','fr',18,1,'natural','f5',NULL,'[0.9295141965072486, 0.922796595563596, 0.9085150508110716, 0.8378207632738891, 0.8256546621281625, 0, 0.7668637124344888, 0.8980419455629705, 0.7566021929026924, 0.7744276045488293, 0.7208146375753279, 0.4926060278097968, 0.817614456603113, 0.25130153905992253, 0.5746981840641682, 0.8876746073257561, 0.8682623803491304, 0.5132504973272376, 0.902009087278255, 0.6786565066924257, 0.6357912980114251, 0.4482275651162408, 0.5173606261158911, 0.4574840912664881, 0.2797672877626741, 0.40612358425479694, 0.2350100333915655, 0.06146335017989179, 0.31520763677106445, 0.6923883317999012, 0.4039548952808373, 0.40915104862873536, 0.2739932412502095, 0.3252578807537435, 0.4347923632289355, 0.3802168957785522, 0.93041337118338, 0.8432161214978635, 0.7789236330130788, 0.5946922846842648, 0.639969922053952, 0.7255002815801116, 0.6648832225709076, 0.7916711942460265, 0.8555677026216261, 0, 0.2601878031302693, 0.8784710163754834, 1, 0.5672929424661579, 0.6608304747119141, 0, 0.5173076909159164, 0.6245776686035229, 0.5171648589261413, 0.9028299964341112, 0.9100490343306484, 0.8321608841336353, 0.8964551302324817, 0.9305720733942412]',NULL,3,'1/dzshzgie.mp3','2026-06-07 05:33:22','2026-06-14 13:31:09'),('ixaifltr','qo5ajmvm','News Report','Breaking news. According to Source  details. This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'builtin:Andrew Chipper','es',10.68,1,'serious','xtts',NULL,'[0.8957316648469986, 0.4058827127176391, 0.3342249602325241, 0.1586629221699999, 0.07977643376005947, 0, 0.04399851280321026, 1, 0.3877754212123867, 0.09362429478441232, 0.5058203400036558, 0.5039336071544648, 0.16382470957270168, 0.17781494271820483, 0.6053355389690648, 0.3801573428945518, 0.2388236536758535, 0.14705776343721805, 0.1243102662606549, 0.043001781838977786, 0, 0.816952088167352, 0.846427718311631, 0.8377060451364418, 0.3392545778781852, 0.8779324099379132, 0.4177850533574076, 0.3930084251175003, 0, 0.7970168252552992, 0.6818701432658935, 0.25022248633752975, 0.06532141900150915, 0, 0.6564023983574907, 0.8871879807418331, 0.6841692499319321, 0.48770066301972304, 0.3306040864147372, 0.21166275120864528, 0.7917126396384442, 0.2764942436400393, 0.36410238782983384, 0.5471858905183524, 0.3655975168924361, 0.30152006005704696, 0.2785233573080482, 0.5103258014083124, 0.6653020606027038, 0.12238795125326084, 0, 0, 0.13345911668296842, 0.7498257857177201, 0.4957103451241467, 0.45899421980843, 0.5944252542971871, 0.4863123413154032, 0.28692462580372535, 0.14990108316577566]',NULL,2,'script_ixaifltr.wav','2026-06-06 16:44:29','2026-06-14 14:15:34'),('n0afspme','wcy0cecq','Product Demo','Today I want to show you [Product Name] — the easiest way to [solve problem]. In just [time], you\'ll be able to [key benefit]. Let me walk you through exactly how it works.',1,'my-voice','en',11.95,1,'natural','xtts',NULL,'[0, 0.0001, 0.0042, 0.4939, 1, 0.991, 0.8891, 1, 0.7568, 0.9036, 0.7343, 0.4847, 0.3574, 0.0122, 0.005, 0.0052, 0.0077, 0.6632, 0.5889, 0.7967, 0.5251, 0.9633, 0.3908, 0.5541, 0.4274, 0.4766, 0.1811, 0.0117, 0.0074, 0.6705, 1, 0.4789, 0.2159, 0.705, 1, 0.6151, 0.7444, 0.5863, 0.798, 0.573, 0.4583, 0.321, 0.9287, 0.701, 0.2354, 0, 0, 0.0024, 0.0831, 1, 1, 1, 0.8028, 0.6938, 1, 0.9179, 0.6497, 0.6373, 0.2899, 1]',NULL,1,'1/script_n0afspme.mp3','2026-06-15 09:44:18','2026-06-15 11:48:28'),('rgpeao9t','wcy0cecq','Story 1','The time machine groaned, settling into the year 2026. Leo stepped out, desperate to warn humanity about the impending climate collapse. He found a bustling city, people laughing, and neon lights humming safely.\n\nHe grabbed a stranger’s shoulder. \"You have to listen! In two years, the sky will turn to ash!\"\n\nThe stranger smiled gently, pointing to a massive, shimmering energy dome overhead. \"We know, traveler. That\'s why we built the shield last year. You\'re just in time for dinner.\"',1,'my-voice','en',34.7,1,'natural','xtts',NULL,'[0.0028, 1, 1, 0.9294, 0.669, 1, 0.3858, 0.9491, 0.9659, 1, 1, 1, 0.9691, 1, 0.9008, 0.9015, 0.4636, 0.6518, 1, 1, 0.3345, 1, 1, 0.9991, 0.777, 0.3194, 0.5778, 1, 0.859, 0.0529, 0.8686, 1, 0.7423, 0.7706, 0.9286, 1, 1, 1, 0.9531, 1, 1, 1, 1, 0.9171, 1, 0.92, 0.8349, 0.1513, 0.641, 1, 1, 0, 1, 0.9614, 1, 1, 0.028, 1, 1, 0.9757]',NULL,3,'1/script_rgpeao9t.mp3','2026-06-24 09:35:56','2026-06-24 09:39:44'),('v8ffnf40','wcy0cecq','Story 2','The sign on the door of Curiosities & Co. read: Enter at your own risk, leave with what you need. Clara, seeking shelter from a sudden autumn downpour, pushed it open. The air inside smelled of old paper, vanilla, and ozone.\n\nBehind the counter sat Mr. Abernathy, a man who looked as ancient as the grandfather clock ticking heavily in the corner. He didn\'t look up from his ledger. \"The umbrella stand is on the left. Your destiny is on the right.\"\n\nClara chuckled, thinking it was just eccentric marketing. She wandered down the narrow aisles, her fingers brushing against tarnished silver mirrors and velvet-lined boxes. At the very back, sitting on a silk cushion, was a small, brass pocket watch. Unlike the others, its hands weren\'t moving, but the casing felt remarkably warm.\n\nShe picked it up. The moment she pressed the crown, the ticking of the giant grandfather clock stopped. The rain against the window froze into suspended crystal droplets. The world had paused.\n\nPanicked, Clara looked at Mr. Abernathy. He was frozen mid-page-turn.\n\n\"Oh no,\" she whispered. She pressed the crown again. The world rushed back—the tick-tock resumed, the rain slammed against the glass.\n\n\"Ah, the Chronos-Pocket,\" Mr. Abernathy said, finally looking up with a knowing glint in his eye. \"A favorite of those who feel the world moves too fast.\"\n\n\"How much?\" Clara asked, her heart hammering. She was working two jobs, failing her classes, and constantly drowning in deadlines.\n\n\"It doesn\'t cost money,\" the old man smiled. \"But remember: the watch only pauses the world, not your own aging. Use it to breathe, Clara. Not to work harder.\"',1,'my-voice','en',116.86,1,'natural','xtts',NULL,'[1, 1, 1, 1, 1, 1, 1, 0.7846, 1, 1, 1, 1, 0.7839, 1, 1, 1, 1, 1, 0.8426, 1, 1, 1, 0.9937, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.9744, 0.9872, 1, 1, 1, 1, 0.9747, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]',NULL,4,'1/script_v8ffnf40.mp3','2026-06-24 09:38:10','2026-06-24 09:42:10'),('xu7ibp0n','wcy0cecq','News Report','Breaking: [Headline]. According to [Source], [details]. This comes after [context]. More information is expected to emerge in the coming hours. Stay tuned for updates.',1,'my-voice','en',11.76,1,'natural','xtts',NULL,'[0, 0.0027, 0.003, 1, 0.5819, 0.4935, 0.306, 0.1761, 0.0127, 0.0046, 0.0042, 0.2789, 1, 0.9943, 0.561, 0.2508, 0.2693, 1, 0.7979, 0.444, 0.2373, 0.491, 0.5113, 0.1275, 0.3772, 0.0079, 0.0071, 0.7994, 0.7043, 1, 0.782, 0.2457, 0.1744, 0.2332, 0.4308, 0.0206, 0.0052, 0.7621, 1, 0.7278, 1, 0.6599, 0.8945, 0.7496, 0.6342, 0.7233, 0.731, 0.6006, 0.6678, 0.2923, 0.2293, 0.2418, 0.1675, 1, 1, 0.9123, 1, 0.909, 0.3776, 0.9438]',NULL,2,'1/script_xu7ibp0n.mp3','2026-06-15 09:44:21','2026-06-15 11:48:33');
/*!40000 ALTER TABLE `scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0cOsHp1KdagNxHZN5dIgqD2xsCOsB9VNSL0cdue3',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbU0yVms1eGIzUllRVmd6UjA1SVZYQXdZbXQzYjNjOVBTSXNJblpoYkhWbElqb2lLMDFJWXpsemVtNDBhMlEwTlc5aGQwNXFPRlJXVXpSYVlUaExha1pGYTFwRVRVOVJLemxtWkVWUFNHeHRPRzgxTDB4TFVHRTBiV2hhZGtsWlRFdzVWazFCUlZKdE0yWmlPV1poVEV0elVFTmFka1JqY1VaMGJFVlFWVTlxTjBoeE9YaGpaWEo1SzNvclkxZHVSWGt2TmpGUlkxQm9jbTF4UWtwWWFVOURjVkJaWjFKM1FrNHZZMGxXZG5wTVltdDVWU3RoYVUxYU5FTkthbnBrVDBsUk9IcDVVekpZYmxOc2ExSkdPRlZRYVhGSFdHaGplRWQ1TVVsR2RtVmlaMVZqY1VzMFFra3hXR2t4V25aaE4xZ3lka3hXUkVkdFlsSkJZV3hWTm1SRlRHMUJUV0YzWTNZM1YzazFlVk5xTTIxalpHbEZPVU5OWjFCWEt6RnhVRGRHWnlJc0ltMWhZeUk2SWpFeE5EVTRaV0UxTUdaa05HTmxaalZpTXprek9UYzRaRGhsWkRnMlpUVmpNV1kyWkRJME5EWXdNelJoTmpOa09EZzVZalZtT0dFNE56WmtOR1EyWVRraUxDSjBZV2NpT2lJaWZRPT0=',1782395028),('7Tm6rXAU0BTCvZLuiktIFKUENtIuchjQAPUESFSm',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbXRGZEZoUGFGSkZORE0yT0hoT2MxUlhSbE5ETVZFOVBTSXNJblpoYkhWbElqb2lja05pYzJoRVEzVnRNbEJoUlU1clZVaHhUR1Z2TkdaUU9UUkNWWFJvT0hwdFZqQm5iRzlUVFhaVVdsQk5ObUpUTjJ0MVYzUnFkbWt2VWpSeGVFMWhaR3BqVmtwRlMyOTBTV3gzY1V0MmRqUnJhWGhwWVZGdGFVNWtXakE0YlRobFVXNU5jR3RxWTIxMk56QnJPRVJWTVVFeVQzRjVlWFJUZUhWT2VrRnNkbGxxUW5kME5sVndVRWxGV1dVd0wwRXhZbTlsVjI1emNUWTFOVEpLZWxwTVJWRjRXbXB3Um05Qk5scHVka2MyT0hkb1MwNDJaMWRxYjJKS2RGTnFlR1Z6Ym5KdmJFazBVa2RZVlZBMWJGUTNORVZtYURsc01tMUNVMGxLTjJaVVRHTXJjMmxUWlVaeFJqZFVaejBpTENKdFlXTWlPaUprTlRCa016RXdOVGcwWkROa01XWTJaRFV3TURZeU1qZGpNbUpsTlRWak5XTTBOMk0zWVdFMVpURXpNalprTWpnNE5HSmlZbVkzWWpWaE9UZGxaRGhtSWl3aWRHRm5Jam9pSW4wPQ==',1782394241),('cWRuGT99jYtcMP9b64smaDtuyDEPpo1oAkG09jvC',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36','ZXlKcGRpSTZJazl4VHpZeldsTkRTMkZQUVd4dk5rVm1XWGRFUTNjOVBTSXNJblpoYkhWbElqb2lVVEJ6VEZWSldFTnVVbk50ZERKb1lrTlRWalZwVXl0eGJGZDBjSE5YZFVwdmVFTkZXVUZxYlU1MVUya3hVRWRyVXpWb2NVazFNVEp6T0d4RlV5OURXV3BWTVdJd1Ewc3ZVMEZpSzNRNWNucE5la1YyU21WSGFWTlBRMFJ0YVRkc1RXRlZiVEJ3VkhRMVYxbDNWbWxLWmk5d1oybFdiRUptTmxwTmFrUk5RbWR4VjFaUFUyOVVZVGh2UTA5aGNFeFNTRWxaVFd3NE1UWm1ZblZIU2t0M2N6ZHBTVVpzYVhKRWFITmxkMkY1WkRGM2FEYzVaMEZqTm1wa2RrWm5NVmRZYlZnMWVIUXJUMDFyVUd4SGNFNDFRV1JHZG5FdmQwOVJjV3hZZDBSUk1VRXllU3RCWkROdVYybEVSVDBpTENKdFlXTWlPaUpqTkdVeU5qUm1ZMkkyWVdWak1XVm1OMlJqWXpOa05HWTFPVGt5TnpOa1ltUXdZMk0zTVRsaE1XTXhPVFl5T1RBek5EUXlNR1V6TkRkaE1HWTBNVFV4SWl3aWRHRm5Jam9pSW4wPQ==',1782397019),('d4TqtkRAvCegzqvBqjV0geWlk7rIsqBxsXZ3bhZB',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36','ZXlKcGRpSTZJa2xHTjNwU1pGRjRialk0UkZwaWFEaFVlVEY2VGxFOVBTSXNJblpoYkhWbElqb2laVmh1YkZoaFVFcEdWalF6Y1VGb1dVUm1ZMFJPVkVOblJXbHNaRFE0ZGxrdk5sRmlTa28zYUZSS1owTXlNMjFZTUdRNVEycDBUazVrUWt3ck5YaG5jRUp2VEcxU1kxRTROemQ1UmtwUlZGZzBSRk14VW5wUmIySnhiWEJvYUVacUsxRldWakJhVVdaWVkxVnZaeXQ2Tlcxd09GUmhUM0V4WmpKelUzZHBXQzgyZFdaTlJDOXJZVlZGSzI1WlJWcEZUMWxUT0ROT1MySlpOMFZXUzFsalV6Y3pjM0k0YkhwYVFTOHlhMnR0Wmt0dFJXd3pWR3BZZWtSMlFtRlRjVkJsY1dWWFlrZzFhMjAyT1hGU1oxUnhXWFo1TDAxME1rZDVObHBrTDB0aUwxTnRPREpaUW1KVlNGazBURFlyTlRCTk4xaHpZMUp0SzBZMGMxbE9iV0Y1WlNJc0ltMWhZeUk2SW1NeU9EWTFNVGhrTVRreU5UTTJNRFV3TUdZeE56TmlZekE0TURFME9XSmlNR0V5T0RVMk5tUTVNVEkzT0RVNE0yUXpNakJsTWpJMU9XVXpaakkwTkdZaUxDSjBZV2NpT2lJaWZRPT0=',1782397019),('FRI2YYeVxyIewen0C5XHyKRk2ypbIJFznMoWTe5Y',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','ZXlKcGRpSTZJa2swV2xCcVFrcG1hMWxVTVNzM1EyVlRkak5PYVdjOVBTSXNJblpoYkhWbElqb2lSWFpMZDFaVFptMVpTbXR0TjJsdFZtVnhTQzlqWlVSQ09XeGhRbWwzYlhCelptWkpaMjltY21WcFQyaHBiVzUxUWpjNFUwdE9SR2xKY0ZwSlJVWXhTalEzVDJORGFWWlZRMlpRY2xob1dtNVZiRFpGT1hRMWRtcEpRalU1Y2tWeUwydE9kM0J0YzFCclZUazVkR0YwUlVocVZFVTFOMUpaUVM5d1FqSXhkVXBpY205U1ltWnNlVWhHVG5kUUwwdDBhVVUyYjA5NWRtWkpRemx4UzNaNVpuSktOMWM1ZVZod05ubGhUMWhRV0VSc2NqUjRRbElyYzFKdkwxSnphakJGTUhGcFozY3hhbmxyWm5saU5UQk1jR3hoU2tOTk1HOXZVVVpITjFoaVJIRnhSRGhWYTJwNmVYZDZRbWQ1ZFRBMWR6TkRRV1Z1ZDJOTlRYSXhhM1JOS3lJc0ltMWhZeUk2SW1Sak0yVXlZekUzTXpJellqQTFaV0ptT0dFelpUSXpObUUwTnpnd1lXRXlNakkxWkRBMFpUZGlZbVU0WTJGaFpURTNaV1l6TTJNMVkyVmhNbU15WTJZaUxDSjBZV2NpT2lJaWZRPT0=',1782406287),('gvHC2BbufKXXyNFV8y5dvOLlbbnYk2P1zzCEmIEU',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','ZXlKcGRpSTZJazVoTkVaNEswMHJOelU0YkU4eEsyTk5PR2hDYUhjOVBTSXNJblpoYkhWbElqb2lUbFYyVEN0TlFUbFFkbUpXVG5RdmVYVkNObWMyYVRGbFkwUm9LMmh3V0habFEwTXdOak5aUkZNelZGUTJWSGhOYW5veFdHSnBjWGN3U25rck9XYzFlRmhNWWpWVmQybElLMlp5ZERWUlkwTm5NSGhzVVhJM1JGUTNOblpGWlVaSGFrZHJZbk55ZWpOTkwzWTBZME54ZWpCQll6WnZNVGRCYkZOdlFVNDRia2gxTkVSaWExRm9UVVI1TW5CSU1saG1OemQxYkV0U1IyTmlMemREYlVoc1QzbElha1IyZGpCcmVWWXdMMFJQU2psWlMwaGpNakZDTjJSdGFYZzFkMlJVZEhsa2IzcDZSM0pxUW1oTGEyNUpOa05DUkdjMk5HNUJka05VTTI1dFVHNVdRMjFCWXpWU2Vua3ZZejBpTENKdFlXTWlPaUl5WVRobU9HTXdZbVJoT0RVNE5XTmhNemxpT1RjeU9HUm1OVFV5T1Rsak1USmpZbU16WkRWaVltTmpOV1V6TURWbE9UTXlZVEprTWpWak1ETTFNVGd5SWl3aWRHRm5Jam9pSW4wPQ==',1782406287),('jgZgaiLlDcKfq08hsqph3oZ80Q8skjvDtGLQIuAt',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','ZXlKcGRpSTZJakUxTjJsV2FuQllNRkE1VW13eGQwSlFUR2R3VTBFOVBTSXNJblpoYkhWbElqb2labTUzVjJFdk4za3JUMnRGYldOdFZVNU5RbXBRU21WMk9FVTFPWGhEY1dGdVRtMUJNamhoT0VsMk5uQk5MMDlTVWxwNVExRnNZa0ZyTVc5dlVYbEJOVFpVTkdjMlozUllWWEF2ZUUxMVRtTnZiemh1VlVwd2RFUldiRVpTWlhaWFpscGxVRmRQV0RCeUwzWlZUelpKYUdZd1luSkZNemxQWlRWdGFsWnhOVmMyTm10RlYzRTJSakl6YzI4eVUzQk9MMHRVUzFCbVUzTlFNMjVYVTI4cldESTNTa3BFUm5abVJIVTFZekEyYW1OcmFGcEhRV3hUTTBkRFJWVmxSbGN3TVRaWWNXeHRRbTFOZHpBMGFqaDVWV2cyYVUwMGFWVlpNMnhSTW5BNVNWSlNOVVF6YWxScmMxUTJVSE15UkROd2QxQjJiR3B5U2xScGRsRlBaWGxoYnlJc0ltMWhZeUk2SW1VM1l6RTNabUV3TkRJME4yWmtPRGhsTWpNMU5UWTVNREptWkROaVlqaGtZbVkyWkdSaE1qRXdaRFppWldNelpHWXhNMkV3WmpJeVlqZzJObUprTWpNaUxDSjBZV2NpT2lJaWZRPT0=',1782400283),('KmfUicAi5ncMxIJv4yu4uS05Gm3Ybt3esTMMbLll',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','ZXlKcGRpSTZJbGhpUVZab2IwcDZWVWhhT0hsdVdqaGphV3R5TmtFOVBTSXNJblpoYkhWbElqb2lVMUpwU0ZSbVVrSjZWR2x2TURkdFpFSkthVTFsTHpCU1pFaHFaMU41VmxoelQxbDBURk5IWVVJMFpDczFWWGxqV1hCM2JEVTJaVFJCYVdOYUwyeFZOelF3WVZGUlF6VnZUVWxPZVcxU1dIRlhVMjFYTHpCRmRtbzJiV3N2YTFodWFrNUlXRk13ZDJoTVNFOURhWFV4TjNaeGFHTjZaWHBuTW1aRU1ETmtWMmhSVkZSR1FtMVBZM2xRVDNObFJUaFJNVEJoZGs1RFJVSlZXblZZVTNVNFN6WTVaa1pvYkVwaFZGTnBibU4wT1ZnMloxaHBaVzlQYlRsVU4zVjVXVFF3ZUdwbmRGWmtUVVprWlRGbVpUVnhNVEZXUVdaQ1VGUldZM2xWZGpONE1GWjFaSGxzSzFGaFpEVnFiejBpTENKdFlXTWlPaUl3TnpOaU5qUTFZelUzTkdGa09UazBNelF6TkdVNU1XRTNORFptT1RjMVpqSmtNVGxtTURWaFlUQTRaV1F3WmpJM05UZzRPV1kxT0dOaVpqbGpPV05rSWl3aWRHRm5Jam9pSW4wPQ==',1782400283),('lQhutg49Eak1dLzfrbIyYXrFoBpySTkCBaCinqWr',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36','ZXlKcGRpSTZJaTg1YjBKc1ZVRlpjWFZRU3pKV1NVOHhjMUZTYVVFOVBTSXNJblpoYkhWbElqb2lPR1JUV1ZoT0wwWjBjSFEyVEVWSk9DdGlibWxLZWpSeGJuaFlNamhxYVhoSlYzSnZURlpVWkVGWlVFaHNRa0Z2T1c1bFdGSk1jMDkzTUZnM1Rrc3hRWGRZYVRCWFZWSkhkbUUwZUdwQkszbDRjMXAxVjJOUlIydFlRbmRuUzFsYVVETlRSRWhvTURaWE5tRktja1E0VFhNMU1XNVFWVVJJYWtkdVVGTk1VWEJ2ZG14alMzWXllRWRGVXl0cllsSllhamxWYld4VVlraHBMMlZoVVU5b2R6bFJhM2hDWVZNd1NWaDJRVE5KWVdoeWVFODBWMWRtZEZkNkwxZFJNRlpsWm5oTFQyOWFZbEJCYzA0M2FGZzJNbWRHUVVkMGVWRm5kbU4yV1ZSUWFETkhaa0pxTTBWRVQxZEthejBpTENKdFlXTWlPaUl4TVRka01tSm1NVEEzWkRZM1lqVm1aVEl5WlRKbU1HWmpNekl4TWpKbVlqQXhZalppTUdNeU1UWmlNakJoT0RBME0yRTVNak0wTVRFd09XTXdOREUzSWl3aWRHRm5Jam9pSW4wPQ==',1782443033),('MQTgfec0Xq7Lm95zep9IF3Sf81wKfO84h8PcApZy',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkUzUVVGbWVuUnNTa1JrVkZaQmNHTjNNaXQ2UmtFOVBTSXNJblpoYkhWbElqb2lUMjFLZHpoRlJuVkxjbkpUYm1WcWMxUnpiVzgxWjJoRmRrRXJXV0pYYmtGelRYRmhNa2M1Y1VSTlNTczRVMWRuY1dNNFdIbFZiV3hYWmpOaFdsRmFORWhxVEdKMFNqTlhjRzVCUm5wSlpHcEZSWFIwUVRSeE5YQlhiVE0xTDJWWFZGbFhiRWhzTmtkWWVXUnZjbmhZTW1kU1ZrZDJXVFJqYTFodU9VSnVTMHN2UkVvd1NURnlXWEpsSzJrelNXTlZlamhrZDJodU56WTNUV2xzVjFCelExcHJjblowT0hWeE0wZzVkV2hYUVVsWFdqSkNaa1IwZUVVNVNsVmpOVlJJWlZsa1ZraFlWRU50WkhSUlZYZzRaV3hvZG01WWJIcHhWbXhoYlhGQk9XUnBhMVIwVVdkUFV6RnNaejBpTENKdFlXTWlPaUl4WldNeU5HRXhaVEJoWXpsalltUmhNakV5Tm1abE1UTTVNek00T0RaaU1UQTJaR0V4WWpBeE5EZzFZMk0yT1dZNE1qRXhNR1V3WldJNFpXUmlZelE1SWl3aWRHRm5Jam9pSW4wPQ==',1782394241),('NZUJJyDAL46McSk81xXIjI7VmBJ5B3eKnWmCvv29',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36','ZXlKcGRpSTZJazVMU25kMFpXY3pSREozTTFVek5reE5PRkpxY1VFOVBTSXNJblpoYkhWbElqb2lSbE5qVkZndlIwTkVVMEUzYkcxbGR6ZGhaVmR4WTJjeFZUaHhSalYxV2psR01VOVBZbWRyYVU5ek9TdHpUblZGUlU1c1lWQlFVblUwTDJaclluSXdWMWxpTVVsb1NuZ3JTRVJZZFZZMVMyOXlZV1pPWm5SWWVIbDFOSFV2TTBsWFVURlRkbXBXZFU4MlltcFdZMVZFSzBKUVRYbGlUM3BGVjFJMU1ESlpSamxHTkd0c1UwRkplblJ3WmtsbGVsZFNZMnMxZVc5UVprSm9NRlZsUlZkQ04xaEJhamhTYzNaRFNta3JkVzR5V1RoS1MzUkxaREJtVUhwaFdtcGlaa0pTWWtaSU1HaFFSbk5HYWxRclpGTmtielp0SzJaWlowdFhhMHR3ZG1GV2VWUnFNbFJKV0RWMlVYUXZSMHBHZVVSWlMxZzVOMUkzYkNzclJrMTFlbUpOVUNJc0ltMWhZeUk2SW1OaU1UUXpZemRsTTJJeU1qa3pZVFl4WkRkaE1ERTVPVE5qTlRGbE5URTBaakUzWkdNMk56VmpZMkl4TlRJeE5tWTROekZtWkdWaU1tWTVNV1ZqWTJRaUxDSjBZV2NpT2lJaWZRPT0=',1782396928),('PAYUNYEgAmTTlV4DDxEeuIlMDnpwcA0PEqL2JIKk',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36','ZXlKcGRpSTZJa0UxTDIxblNVUklOSGxCTlhCdE9EVklaV05GVm5jOVBTSXNJblpoYkhWbElqb2laalJ0WW5sc1RVeFFUMGx3U0dWeUswYzBZakJwWVZWRFRIQk1OV001Y2pka1NuZEZabTB4TUZCcFZqVnBkMmxaZGxacksycE5WMEl3ZG5aRWRpdFFkMVkxSzBKbFRXMDNXWFIzZG5Wa1FWTlJZbTFxTVhCMVpUZEpMMnRqZWxseFVFdHhMMjlqZW5Wc09IaHBSWGxyT1RGSUswMTZRamgxVGt3eVJtWktTSGMzTWpST1VpOVZWbkptZEdoWVdISlJiMkpPUkhGWlRqZHJPRU5JWlVaSGQzZGtjWGRqTmtGRFJVMW9OREl6YjBwcFFreHJORFZtYUc5blNta3hSbE5LT0U1elIyOXBZMWwwTUdkTFpHMXljRlpXUmxscU56bHdkRTl2TDBKcGF6UjZLM1p5Y0UxNmFtbDJPRDBpTENKdFlXTWlPaUk0Tmpka00yRmxOVGhpTWpsaFltWm1NVE0wTlRreE9URmtOamxsTjJRMFpEQTRPRGMzT1dKbVl6UTFObVl5TXpReU9UWXlZelJpTnpjMlpqUTFaR1l3SWl3aWRHRm5Jam9pSW4wPQ==',1782443033),('Q8ccalfnOqvsE68zvf6iS7RoW3xqBK5F0mZNqO0O',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','ZXlKcGRpSTZJa0puTUdORWNsSm1hR1F2YUVGUWR6SXhZMWhPZUVFOVBTSXNJblpoYkhWbElqb2lVVlpsWXpKWk4wbFliVnAxWldnMWJVOWpVREZSWjI4dlluaFVRMWhMZDNWM2MwTkZjV2hUTkhkRU0wbGpkRXcxVURCRVNUVTRSV2xUTW10RmNWTk9XVXhWUWtOSGJXMHZSVE4zTWpGSloxUnpSMlJKWlhZMmNqRmxSM2RYWkhWR0szRXdhMVY0WWxGM1FqSjJNbGx1YzJnMGVIRXJjVGRzVTJweU5GWkljRXhvVGxsamJHSkZUVXhRYTBWMVJrWldRVFJ6ZW1kTlJrSnZNMkZXSzFKNVdEZGFSakpCYmtWaE1YQnFPVzE2U1U5WFdUWmtTVWxPTmpOa1ZYcFphR1JpVFdaWE0yMU5hSEFyU2xwUlQzaGpSMWR5TURSRlptTldVSGh4UlRONU5qZEJjbG8xUWk5VlpreEpkejBpTENKdFlXTWlPaUl5TldFeFlqa3pNV1E0WmpWaVpERmtOR1l5TlRsak56Z3pNVFE0T1RGaE5EZzJOV00xWVRSaFlqSXpabVEzWldNeVl6WmtaVFJsWlRka1l6Um1abUkzSWl3aWRHRm5Jam9pSW4wPQ==',1782406287),('qvvppCcbFIKPvjsl6unJxOFI9SIekigLaRhYpefn',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','ZXlKcGRpSTZJalk1VDNaelRHcDZZbWQ1ZURZdlRGUnBSM1p5ZDJjOVBTSXNJblpoYkhWbElqb2lWMGhNVFRkV1NrVnJXWFJZUzJkb2FVRnRWMFZvVkdneFZFbFdkSE50VDNCdldsWmtZVzFuZFRCNmNESlBTMWRzY2xsSmNWUlBMek53Y0U5U2Qyc3ZNMUpFZGtSVWEzYzJXa2xHWldwWGJubFlaVXRQUWtKRFpUSk1MMnBsYm5KcFYwaHRWR1ZUWldOU1ZUTm5hVFZsZVRrME1VTnRNalJMZGpGSlZrVlZNbmg1ZG1GNlMwaEVUWFpWUms5bFNGVjVZVzl2TkdKd2FYRXlaR2hXWlhKR1p6QTBiWGRSZUVGMlEzWnVkbE4xTTBOc2VUWkxTMU5tZGxoaWFVbEpRMGhYYjFGU2FFWlpORXBOTjA1MEszaFlkWEIzTDBkMFprZEtWVzV6UWpSeWNEQlBaa2t6U2tKQ1NtbFdTVDBpTENKdFlXTWlPaUl3TjJFNU9UWmxPREEyTW1NM01qTmtNekUzTkRBNVlXTTVOR1JsWmpKaE9URXlOV1l5WWpZeFpEZzNNalEwTUdJek0yRmpaVGxpWVRReVkyUm1NRFl4SWl3aWRHRm5Jam9pSW4wPQ==',1782400283),('RotxQ4cURxNhXXyurrj7zKUfZSG6eqis930wDgOg',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36','ZXlKcGRpSTZJa3hTT0UxSlEyaFpiMHh4Ym5SemF6VmxSbmcyUm5jOVBTSXNJblpoYkhWbElqb2lTMHQxVEhkcU1HUTFhREJyUm5FMGFubHNPRWxrWmxSdmFuTkRaVkY0YVZCbVpIWjFlVFl2VkdOWmEwdE1XVkphZHpoWU5UTldaVlJEZVVGQldUWnRkVlJNZERZMVZHMVVWblpIYWtRNFJtMUxhMVkxV21KMk9IQkhTV3A0TjBGTlZEWjFVazlhWms0MVR6ZHFLMlZVVmxWeFNXTlBWQzg1U0VNNGJIVXpja05xU0VNMGIwOWtWbkJXTUdwR1VsTjZTbVZ3VTNNMU4ycHVRVU5PZG5Wd1FteFVjRzF2UVU1S2RUSldUbE5aYkdOU09IUjBabWwwYlhvMFRqVlpORzAwWjFKNVV6UktNVFkwY0ZveVRXOTNiSEJvY1dScmVpdENRMGhKY2pJMU0xZDNSa3hwTkdkRWVWbGhaejBpTENKdFlXTWlPaUptTkRKbE5HSTNNVEprTUdRd09EUmxOak5tWkdWbE9HTTFNVFJtTURZeVpqYzRNVE15TjJFd05qTXhaVGxrTURFNE5URXdaRGN5TWpZd05HVTNPREl5SWl3aWRHRm5Jam9pSW4wPQ==',1782397019),('v9YFiHEMSB4xYIqoeu9vDTp5klC4SaEcLzj1QNbE',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36','ZXlKcGRpSTZJa1ozV1RaeWVEQTBWMGRpWmtsaWVtRmlZM1ZLYVZFOVBTSXNJblpoYkhWbElqb2lNVkowVGs1TWJDOTNTa05xYjFGaFZYSXlUVWc1ZHpSNE1qVnJla3Q0VkZRclVpdHJVWGNyYkc1TGR6RTVMMEpoYVhKcE1VOVVNVVJaSzIxQlFqbG1kbXhHYURVMVZsbGtOa1JOTUhjMWJEaDNPWGRhTmt0Tk1GaE1PRFZyWTJaT2VtZE1LMlZGV1ZSRVJXdGxSVE54UkV0VGJqSnlZeTlDWkdrd1MwVkdkbXB2UVZReVJESnRjMEkzWVhCRlN6QlFaMmRPVkVNd1JXOVdSako0UjAxTVZUQnpjaTlHTWtGT2N5dHRTVmRuVnpKRFdtRlBZVVpGZDNCR2IzcGFWalp3TmtSR2RHNVhSR3BKZFVVMmJuZG9OMk5MYTJGS1FrSklORk5rWlhJeFFUZHFjRzAzU1cxcmIxbDNiejBpTENKdFlXTWlPaUppTXpRM1lXUXlZMlF3WVdKa1pEQTJaRFUwTmpOa1lqUTFNVE0xWW1RM1pUaGxOalZtTm1Gak9XRXlOMkpsWVRBeU56TXlNelk1T1RreU9EQXpaalUwSWl3aWRHRm5Jam9pSW4wPQ==',1782396928),('yCVb1aVaIPkyif5zBVkppUuaEeVPSlPjtAnEWBqU',NULL,'172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36','ZXlKcGRpSTZJblprVnpoNU9VTlFhVFpNWVhWaWNYVkJTalpIZUVFOVBTSXNJblpoYkhWbElqb2lVRTk1U1RCTWVFZElObXN5YlhObFduVmxUMlppTlZsSWRrbGphVWRGV0VOcVFrTnRaWEJUUW05NFZrczBLMjFGU3pOUFVuZERZeXRzV1VWemNYcGhUa3d3Y2pKTWJFVlVhMHRqU214c2NtdEtOMHRsWm1GNVpHUTJZVlIwWWtKclZUTjNORVpaYm1seVZIZERjRkYzV1N0NlVURm5XVXRuTW5Wa1RXOTFVRkJtTjNselFXTmpOSHBUVjJka1pVdDNTRzl1YTFwNWVqZHpPU3R3TVROQmFETnRaMlpaVEd3eVNpOTZiMjUzZW0xRFpWTlhXSFpYYjJscVJHbEJNV3QwZGt4Rk0wSXJkRXBDVkVOWlNWYzFVVlJJWmxKME16RkxUVVJZZG1KV1VsWkxiVWM0VEU5d2RHSkZhejBpTENKdFlXTWlPaUl4WkdFMk0yVmhPV0kwTXpKak4yWTJNalV4TldGaE1UWTBZakE0WmpsalpUVTRNR0ZsWlRZM1pEVXlPR0ZrTm1GaU1qUTFPREZoTTJFNFlqUTRNREJrSWl3aWRHRm5Jam9pSW4wPQ==',1782396928),('ZzvSJ9XAZBEPOHxMhMFzCEBTEpbFhHEBdfgM9u1v',NULL,'172.19.0.1','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36','ZXlKcGRpSTZJbVJDV1hwUk1XbDZRamQwTjB0U2NtbEJPVGxXYW5jOVBTSXNJblpoYkhWbElqb2lRbXRFZEhaRk1XSmtNV1ZwUTNOdWVHNVdaRGRGUmpaWk1sbzVRMEUxZGtJM1pVVnRhMVUyVWxaMlZ6SnViSHB2YUZWMFNuUlJaMUZrZGxKbU1IcGFXbk5EUVdaRFpYQnNiR0UyYmsxWEwyOVJVM0ZPWkhCblJrbENWa1EyVTBSd1oyOXZTWEV3VlZkV1JqQlRkalZ0VEdSYWRGUk1VV1J6WVVreWRuZDNVVmRFWjBwdmNpdEJjMk5QTm1GQlRuZHRWbEk0YXpSblJuZGhWV3hOVW5aNFJVZzFaMWxXT0VkNFlYVjRaRXRhVmtKMlQyYzVSR0Z1VkVWSFQydDNWbmR4WWtWbVVqRkJXblZ0U25Ndk9YVlRVMjFRYjJodllWZHFTMGRNTVhSMFJIWXdMekphTDFvNUszSkJPRUZ4VEdsMFkweFlNV0ZWY0c0MFkwRnhha0ptWlNJc0ltMWhZeUk2SWpCaFptTXdZMkUwTldZM01qZGtObVl6WkRZeE1UYzNaV1kxT1RoaU9UWTJNalkxTkdJME56TTVOakJsWVdGbE1tSXdZekZtTW1RME9UTTRZVFJrWlRjaUxDSjBZV2NpT2lJaWZRPT0=',1782443034);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `paypal_subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `current_period_end` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriptions_paypal_subscription_id_unique` (`paypal_subscription_id`),
  KEY `subscriptions_user_id_foreign` (`user_id`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,1,'pro','I-GR2USDDP0EK3','active','2026-07-06 10:00:00','2026-06-02 06:22:00','2026-06-06 09:49:48');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `synthesis_usage`
--

DROP TABLE IF EXISTS `synthesis_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `synthesis_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `synthesis_usage_user_id_period_type_period_key_unique` (`user_id`,`period_type`,`period_key`),
  CONSTRAINT `synthesis_usage_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `synthesis_usage`
--

LOCK TABLES `synthesis_usage` WRITE;
/*!40000 ALTER TABLE `synthesis_usage` DISABLE KEYS */;
INSERT INTO `synthesis_usage` VALUES (1,1,'month','2026-06',15,'2026-06-06 16:14:01','2026-06-10 04:48:17'),(16,2,'day','2026-06-12',3,'2026-06-12 09:15:22','2026-06-12 09:17:22');
/*!40000 ALTER TABLE `synthesis_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translation_usage`
--

DROP TABLE IF EXISTS `translation_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `translation_usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translation_usage_user_id_period_type_period_key_unique` (`user_id`,`period_type`,`period_key`),
  CONSTRAINT `translation_usage_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translation_usage`
--

LOCK TABLES `translation_usage` WRITE;
/*!40000 ALTER TABLE `translation_usage` DISABLE KEYS */;
INSERT INTO `translation_usage` VALUES (1,1,'month','2026-06',5,'2026-06-10 04:27:51','2026-06-10 04:49:34');
/*!40000 ALTER TABLE `translation_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `plan_override` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_note` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_index` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Chathura','chathu.ad@gmail.com',NULL,'2026-06-06 06:59:54','super_admin',NULL,NULL,NULL,'$2y$12$PZhZrYH582onrcRyZOgLZeRLsbMVZvT.jq4nYfvlZVppE72uGU6Qm',NULL,'2026-05-24 07:43:19','2026-06-11 16:13:03'),(2,'Chathura','sriya@gmail.com',NULL,NULL,'user',NULL,NULL,NULL,'$2y$12$.SBlEUTK.1on0kILLVqW1Ox2EzWNF7xLROgmEC60RPz1srV0YUIhW',NULL,'2026-05-25 10:01:51','2026-05-25 10:01:51'),(3,'Kesara Bandaragoda','mbkesara@gmail.com',NULL,NULL,'user',NULL,NULL,NULL,'$2y$12$JYbp6FqMRZGMUUbQQ39jse3/lsYxHEd2wabGWMWvvncBv503cSTOC',NULL,'2026-06-24 08:37:28','2026-06-24 08:37:28'),(4,'YCU Sriya','csriyarathne@gmail.com',NULL,NULL,'user',NULL,NULL,NULL,'$2y$12$mBA1EJPr5MByGDKklRHZsOGEnSn76PcXNwonGwcDeXWf05UBjzJ9i',NULL,'2026-06-24 09:02:50','2026-06-24 09:02:50');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voice_profiles`
--

DROP TABLE IF EXISTS `voice_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voice_profiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `profile_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_key` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ready',
  `duration` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voice_profiles_user_id_profile_id_unique` (`user_id`,`profile_id`),
  UNIQUE KEY `voice_profiles_engine_key_unique` (`engine_key`),
  CONSTRAINT `voice_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voice_profiles`
--

LOCK TABLES `voice_profiles` WRITE;
/*!40000 ALTER TABLE `voice_profiles` DISABLE KEYS */;
INSERT INTO `voice_profiles` VALUES (6,1,'my-voice','fce9bfb6-9dfd-4e17-9ad4-10ea41712564','my-voice','ready',13.56,'2026-06-05 05:44:23','2026-06-05 05:44:23'),(7,1,'my-voice-2','c83ea104-f42a-413f-9c45-5a6097af5d53','my-voice-2','ready',13.78,'2026-06-10 03:47:29','2026-06-10 03:47:29'),(8,2,'my-voice','c8a8b2c4-4f67-4642-97fc-0ea7072de116','my-voice','ready',12.37,'2026-06-12 09:14:19','2026-06-12 09:14:19'),(9,3,'my-voice','9812c959-5f03-498d-9035-30bc514ea191','my-voice','ready',6.75,'2026-06-24 08:38:55','2026-06-24 08:38:55');
/*!40000 ALTER TABLE `voice_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'voice_saas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-26  3:15:02
